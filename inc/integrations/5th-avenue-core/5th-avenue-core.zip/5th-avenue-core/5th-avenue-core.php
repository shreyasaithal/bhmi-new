<?php
/**
 * 5th-Avenue Plugin Core.
 * Plugin Name:       5th-Avenue Plugin Core
 * Description:       Create unforgettable shopping experience for your customers with our powerful eCommerce WordPress theme - Fifth Avenue.
 * Version:           1.0.1
 * Requires at least: 4.5
 * Tested up to: 4.9
 * WC requires at least: 4.5
 * WC tested up to: 4.9
 * Author:            Life is Design
 * Author URI:        http://lifeis.design
 * License:           GNU General Public License version 3.0
 * License URI:       http://www.gnu.org/licenses/gpl-3.0.html
 * Text Domain:       5th-avenue
 * Domain Path:       /languages
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author LifeisDesign
 */

defined( 'ABSPATH' ) || exit;

// Define default path.
if ( ! defined( 'AV5C_URL' ) ) {
	define( 'AV5C_URL', plugins_url( '/', __FILE__ ) );
}
if ( ! defined( 'AV5C_PATH' ) ) {
	define( 'AV5C_PATH', plugin_dir_path( __FILE__ ) );
}

require_once AV5C_PATH . '5th-avenue-core-functions.php';

if ( apply_filters( 'av5_core_allow_run_plugin', av5c_check_current_theme( '5th-Avenue' ) || av5c_check_current_theme( '5th-Avenue Child' ) || defined( 'AV5C_ALLOWED' ) ) ) {
	require_once AV5C_PATH . 'inc/init.php';
}
