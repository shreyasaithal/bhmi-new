( function ( $ ) {
    if ( !Array.isArray ) {
        Array.isArray = function ( arg ) {
            return Object.prototype.toString.call( arg ) === '[object Array]';
        };
    }
    vc.atts.hotspot_point = {
        init: function ( param, $field ) {
            var $fieldprev = $field.prev( ),
                $field_container = $field.find( '.hotspot-point-param-container' ),
                max_points = parseInt( param.max_points || 0 ),
                $input = $field_container.find( 'input.wpb_vc_param_value[type=hidden]' );
            $field_container.on( 'addpoint.hotspot_point', function ( e ) {
                var point = [ ],
                    index = $( this ).find( '.hotspot' ).length + 1,
                    parse_Position = function ( position ) {
                        if ( 'number' === typeof position ) {
                            return parseInt( position );
                        } else if ( 'string' === typeof position ) {
                            switch ( position ) {
                                case 'left':
                                case 'top':
                                    return 0;
                                case 'middle':
                                case 'center':
                                    return 50;
                                case 'right':
                                case 'bottom':
                                    return 100;
                                default:
                                    return parseInt( arguments[1] );
                            }
                        }
                        return 0;
                    };
                if ( 0 < max_points && index > max_points ) {
                    return;
                }
                switch ( arguments.length ) {
                    case 2:
                        point[0] = parse_Position( arguments[1] );
                        break;
                    case 3:
                        point[0] = parse_Position( arguments[1] );
                        point[1] = parse_Position( arguments[2] );
                        break;
                    default:
                        return;
                }
                point[1] = 'undefined' === typeof point[1] ? point[0] : point[1];
                $( this ).append( $( '<div>' ).attr( {
                    class: 'hotspot',
                    'data-index': index,
                    'data-position': point.map( Math.floor ).join( '-' )
                } ).text( 1 == max_points ? '' : index ) );
                $field_container.find( '.hotspot:not(.ui-draggable)' ).draggable( {
                    stop: function ( event, ui ) {
                        var $elm = $( this );
                        var pos = $elm.position( ),
                            size = [ $elm.outerWidth( ), $elm.outerHeight( ) ],
                            $field_container_size = [ $field_container.width( ), $field_container.height( ) ],
                            point = [ pos.left * 100 / ( $field_container_size[0] - size[0] ), pos.top * 100 / ( $field_container_size[1] - size[1] ) ].map( Math.floor );
                        ;
                        if ( 105 < point[0] || -5 > point[0] || 105 < point[1] || -5 > point[1] ) {
                            $field_container.trigger( 'removepoint.hotspot_point', $elm );
                        }
                        if ( 100 < point[0] ) {
                            point[0] = 100;
                        } else if ( 0 > point[0] ) {
                            point[0] = 0;
                        }
                        if ( 100 < point[1] ) {
                            point[1] = 100;
                        } else if ( 0 > point[1] ) {
                            point[1] = 0;
                        }
                        $elm.data( 'position', point.join( '-' ) );
                        $field_container.trigger( 'updateposition.hotspot_point' ).trigger( 'savepoint.hotspot_point' );
                    }
                } );
                $( this ).trigger( 'updateposition.hotspot_point' ).trigger( 'savepoint.hotspot_point' );
            } ).on( 'removepoint.hotspot_point', function ( e, index ) {
                if ( 'number' === typeof index ) {
                    $( this ).find( '.hotspot[data-index=' + index + ']' ).remove();
                } else {
                    $( index ).remove();
                }
                $( this ).find( '.hotspot' ).each( function ( index ) {
                    $( this ).attr( 'data-index', index ).html( 1 == max_points ? '' : index );
                } );
                $( this ).trigger( 'savepoint.hotspot_point' );
            } ).on( 'updateposition.hotspot_point', function ( ) {
                var $this = $( this ),
                    $field_container_size = [ $field_container.width( ), $field_container.height( ) ];
                $this.find( '.hotspot' ).each( function ( ) {
                    var $elm = $( this ),
                        size = [ $elm.outerWidth( ), $elm.outerHeight( ) ],
                        pos = $elm.data( 'position' ).split( '-' );
                    $elm.css( {
                        left: ( $field_container_size[0] - size[0] ) * pos[0] / 100,
                        top: ( $field_container_size[1] - size[1] ) * pos[1] / 100,
                    } );
                } );
            } ).on( 'loadpoint.hotspot_point', function ( ) {
                var value = $input.val( ) || '';
                value = value.split( ',' );
                if ( 0 < max_points && value.length > max_points ) {
                    value = value.slice( 0, max_points - 1 );
                }
                value = value.filter( function ( a ) {
                    return a;
                } ).map( function ( a ) {
                    return a.split( '-' ).map( Math.floor );
                } );
                $field_container.find( '.hotspot' ).remove();
                $.each( value, function ( i, k ) {
                    $field_container.trigger( 'addpoint.hotspot_point', k );
                } )
            } ).on( 'savepoint.hotspot_point', function () {
                var points = [ ];
                $( this ).find( '.hotspot' ).each( function () {
                    points.push( $( this ).data( 'position' ) );
                } );
                $input.val( points.join( ',' ) );

            } ).trigger( 'loadpoint.hotspot_point' );
            var id = $field_container.attr( 'id' );
            $( '#' + id + ':not(#' + id + ' .hotspot)' ).on( 'click', function ( e ) {
                e.preventDefault;
                var $field_container_pos = [ $field_container.offset( ).left, $field_container.offset( ).top ]
                    ,
                    $field_container_size = [ $field_container.width( ), $field_container.height( ) ],
                    point = [ ( e.pageX - $field_container_pos[0] ) * 100 / $field_container_size[0], ( e.pageY - $field_container_pos[1] ) * 100 / $field_container_size[1] ].map( Math.floor );
                $field_container.trigger( 'addpoint.hotspot_point', point );
            } );
            if ( 'attach_image' == $fieldprev.data( 'param_type' ) ) {
                $fieldprev.find( 'input.wpb_vc_param_value.attach_image[type="hidden"]' ).on( 'change', function ( ) {
                    if ( $fieldprev.find( 'img' ).length ) {
                        var imgsrc = $fieldprev.find( 'img' ).eq( 0 ).attr( 'src' ).replace( '-150x150', '' );
                        if ( !$field_container.children( 'img' ).length ) {
                            $field_container.removeClass( 'no-img' ).append( $( '<img>' ).attr( {
                                'alt': 'Preview image',
                                'class': 'hotspot-point-image'
                            } ) );
                        }
                        $field_container.children( 'img' ).attr( 'src', imgsrc );
                    } else {
                        $field_container.addClass( 'no-img' );
                    }
                    $field_container.children( 'img' ).on( 'load', function () {
                        $field_container.trigger( 'updateposition.hotspot_point' );
                    } )
                    $field_container.trigger( 'loadpoint.hotspot_point' ).trigger( 'updateposition.hotspot_point' );
                } ).trigger( 'change' );
            }
            $( window ).on( 'resize', function () {
                $field_container.trigger( 'updateposition.hotspot_point' );
            } );


        },
    };
} )( jQuery );