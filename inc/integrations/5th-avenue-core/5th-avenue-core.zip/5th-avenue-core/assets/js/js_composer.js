"use strict";
if ( !window.vc )
    var vc = { };
( function ( $ ) {
    var Shortcodes = vc.shortcodes;
    window.AV5BackendCarouselView = window.VcBackendTtaTabsView.extend({
			defaultSectionTitle: window.i18nLocale.slide,
			addSection: function (prepend) {
				var newTabTitle,
				params;
				return newTabTitle = this.defaultSectionTitle,
				params = {
					shortcode: "slide",
					params: {
						title: newTabTitle
					},
					parent_id: this.model.get("id"),
					order: _.isBoolean(prepend) && prepend ? vc.add_element_block_view.getFirstPositionIndex() : vc.shortcodes.getNextOrder(),
					prepend: prepend
				},
				vc.shortcodes.create(params)
			}
	});
    window.AV5BackendBlockHotspotView = window.VcBackendTtaTabsView.extend({
			defaultSectionTitle: window.i18nLocale.section,
			addSection: function (prepend) {
				var newTabTitle,
				params;
				return newTabTitle = this.defaultSectionTitle,
				params = {
					shortcode: "hotspot",
					params: {
						title: newTabTitle
					},
					parent_id: this.model.get("id"),
					order: _.isBoolean(prepend) && prepend ? vc.add_element_block_view.getFirstPositionIndex() : vc.shortcodes.getNextOrder(),
					prepend: prepend
				},
				vc.shortcodes.create(params)
			}
	});
} )( window.jQuery );