jQuery( function ( $ ) {
    jQuery( function () {
        // Product loop gallery file uploads.
        var product_loop_gallery_frame;
        var $image_loop_gallery_ids = $( '#product_loop_image_gallery' );
        var $product_loop_images = $( '#product_loop_images_container' ).find( 'ul.product_loop_images' );
        $( '.add_product_loop_images' ).on( 'click', 'a', function ( event ) {
            var $el = $( this );

            event.preventDefault();

            // If the media frame already exists, reopen it.
            if ( product_loop_gallery_frame ) {
                product_loop_gallery_frame.open();
                return;
            }

            // Create the media frame.
            product_loop_gallery_frame = wp.media.frames.product_loop_gallery = wp.media( {
                // Set the title of the modal.
                title: $el.data( 'choose' ),
                button: {
                    text: $el.data( 'update' )
                },
                states: [
                    new wp.media.controller.Library( {
                        title: $el.data( 'choose' ),
                        filterable: 'all',
                        multiple: true
                    } )
                ]
            } );

            // When an image is selected, run a callback.
            product_loop_gallery_frame.on( 'select', function () {
                var selection = product_loop_gallery_frame.state().get( 'selection' );
                var attachment_ids = $image_loop_gallery_ids.val();

                selection.map( function ( attachment ) {
                    attachment = attachment.toJSON();

                    if ( attachment.id ) {
                        attachment_ids = attachment_ids ? attachment_ids + ',' + attachment.id : attachment.id;
                        var attachment_image = attachment.sizes && attachment.sizes.thumbnail ? attachment.sizes.thumbnail.url : attachment.url;

                        $product_loop_images.append( '<li class="image" data-attachment_id="' + attachment.id + '"><img src="' + attachment_image + '" /><ul class="actions"><li><a href="#" class="delete" title="' + $el.data( 'delete' ) + '">' + $el.data( 'text' ) + '</a></li></ul></li>' );
                    }
                } );

                $image_loop_gallery_ids.val( attachment_ids );
            } );

            // Finally, open the modal.
            product_loop_gallery_frame.open();
        } );

        // Image ordering.
        $product_loop_images.sortable( {
            items: 'li.image',
            cursor: 'move',
            scrollSensitivity: 40,
            forcePlaceholderSize: true,
            forceHelperSize: false,
            helper: 'clone',
            opacity: 0.65,
            placeholder: 'wc-metabox-sortable-placeholder',
            start: function ( event, ui ) {
                ui.item.css( 'background-color', '#f6f6f6' );
            },
            stop: function ( event, ui ) {
                ui.item.removeAttr( 'style' );
            },
            update: function () {
                var attachment_ids = '';

                $( '#product_loop_images_container' ).find( 'ul li.image' ).css( 'cursor', 'default' ).each( function () {
                    var attachment_id = $( this ).attr( 'data-attachment_id' );
                    attachment_ids = attachment_ids + attachment_id + ',';
                } );

                $image_loop_gallery_ids.val( attachment_ids );
            }
        } );

        // Remove images.
        $( '#product_loop_images_container' ).on( 'click', 'a.delete', function () {
            $( this ).closest( 'li.image' ).remove();

            var attachment_ids = '';

            $( '#product_loop_images_container' ).find( 'ul li.image' ).css( 'cursor', 'default' ).each( function () {
                var attachment_id = $( this ).attr( 'data-attachment_id' );
                attachment_ids = attachment_ids + attachment_id + ',';
            } );

            $image_loop_gallery_ids.val( attachment_ids );

            // Remove any lingering tooltips.
            $( '#tiptip_holder' ).removeAttr( 'style' );
            $( '#tiptip_arrow' ).removeAttr( 'style' );

            return false;
        } );

        // Product loop gallery file uploads.
        var product_thumb_gallery_frame;
        var $image_thumb_gallery_ids = $( '#product_thumb_image_gallery' );
        var $product_thumb_images = $( '#product_thumb_images_container' ).find( 'ul.product_thumb_images' );
        $( '.add_product_thumb_images' ).on( 'click', 'a', function ( event ) {
            var $el = $( this );

            event.preventDefault();

            // If the media frame already exists, reopen it.
            if ( product_thumb_gallery_frame ) {
                product_thumb_gallery_frame.open();
                return;
            }

            // Create the media frame.
            product_thumb_gallery_frame = wp.media.frames.product_thumb_gallery = wp.media( {
                // Set the title of the modal.
                title: $el.data( 'choose' ),
                button: {
                    text: $el.data( 'update' )
                },
                states: [
                    new wp.media.controller.Library( {
                        title: $el.data( 'choose' ),
                        filterable: 'all',
                        multiple: true
                    } )
                ]
            } );

            // When an image is selected, run a callback.
            product_thumb_gallery_frame.on( 'select', function () {
                var selection = product_thumb_gallery_frame.state().get( 'selection' );
                var attachment_ids = $image_thumb_gallery_ids.val();

                selection.map( function ( attachment ) {
                    attachment = attachment.toJSON();

                    if ( attachment.id ) {
                        attachment_ids = attachment_ids ? attachment_ids + ',' + attachment.id : attachment.id;
                        var attachment_image = attachment.sizes && attachment.sizes.thumbnail ? attachment.sizes.thumbnail.url : attachment.url;

                        $product_thumb_images.append( '<li class="image" data-attachment_id="' + attachment.id + '"><img src="' + attachment_image + '" /><ul class="actions"><li><a href="#" class="delete" title="' + $el.data( 'delete' ) + '">' + $el.data( 'text' ) + '</a></li></ul></li>' );
                    }
                } );

                $image_thumb_gallery_ids.val( attachment_ids );
            } );

            // Finally, open the modal.
            product_thumb_gallery_frame.open();
        } );

        // Image ordering.
        $product_thumb_images.sortable( {
            items: 'li.image',
            cursor: 'move',
            scrollSensitivity: 40,
            forcePlaceholderSize: true,
            forceHelperSize: false,
            helper: 'clone',
            opacity: 0.65,
            placeholder: 'wc-metabox-sortable-placeholder',
            start: function ( event, ui ) {
                ui.item.css( 'background-color', '#f6f6f6' );
            },
            stop: function ( event, ui ) {
                ui.item.removeAttr( 'style' );
            },
            update: function () {
                var attachment_ids = '';

                $( '#product_thumb_images_container' ).find( 'ul li.image' ).css( 'cursor', 'default' ).each( function () {
                    var attachment_id = $( this ).attr( 'data-attachment_id' );
                    attachment_ids = attachment_ids + attachment_id + ',';
                } );

                $image_thumb_gallery_ids.val( attachment_ids );
            }
        } );

        // Remove images.
        $( '#product_thumb_images_container' ).on( 'click', 'a.delete', function () {
            $( this ).closest( 'li.image' ).remove();

            var attachment_ids = '';

            $( '#product_thumb_images_container' ).find( 'ul li.image' ).css( 'cursor', 'default' ).each( function () {
                var attachment_id = $( this ).attr( 'data-attachment_id' );
                attachment_ids = attachment_ids + attachment_id + ',';
            } );

            $image_thumb_gallery_ids.val( attachment_ids );

            // Remove any lingering tooltips.
            $( '#tiptip_holder' ).removeAttr( 'style' );
            $( '#tiptip_arrow' ).removeAttr( 'style' );

            return false;
        } );
    } );
} );
