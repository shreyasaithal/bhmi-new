<?php
/**
 * 5th-Avenue funcitons for shortcode.
 *
 * @package           5th-Avenue\Shortcode
 * @version 1.0.0
 * @author lifeis.design
 */

if ( ! function_exists( 'av5c_check_current_theme' ) ) {
	/**
	 * Check validate current theme
	 *
	 * @param string $valid_theme Name theme valid for condition.
	 * @return string|bool
	 */
	function av5c_check_current_theme( $valid_theme = '' ) {
		$theme = wp_get_theme();
		$theme_name = $theme->display( 'Name' );
		if ( empty( $valid_theme ) ) {
			return $theme_name;
		}
		return $theme_name == $valid_theme;
	}
}

if ( ! function_exists( 'av5c_get_template_part' ) ) {
	/**
	 * Get template part (for templates like the shop-loop).
	 *
	 * AV5P_TEMPLATE_DEBUG_MODE will prevent overrides in themes from taking priority.
	 *
	 * @access public
	 * @param mixed  $slug Template slug.
	 * @param string $name Template name (default: '').
	 */
	function av5c_get_template_part( $slug, $name = '' ) {
		$template = av5c_locate_template_part( $slug, $name );

		// Allow 3rd party plugins to filter template file from their plugin.
		$template = apply_filters( 'av5c_get_template_part', $template, $slug, $name );

		if ( $template ) {
			load_template( $template, false );
		}
	}
} // End if().
if ( ! function_exists( 'av5c_locate_template_part' ) ) {

	/**
	 * Get template part (for templates like the shop-loop).
	 *
	 * AV5P_TEMPLATE_DEBUG_MODE will prevent overrides in themes from taking priority.
	 *
	 * @access public
	 * @param mixed  $slug Template slug.
	 * @param string $name Template name (default: '').
	 * return string
	 */
	function av5c_locate_template_part( $slug, $name = '' ) {
		$template = '';

		// Look in yourtheme/slug-name.php and yourtheme/woocommerce/slug-name.php.
		if ( $name && ! defined( 'AV5C_TEMPLATE_DEBUG_MODE' ) ) {
			$template = locate_template( array( "{$slug}-{$name}.php" ) );
		}
		

		// Get default slug-name.php.
		if ( ! $template && $name && file_exists( AV5C_PATH . "templates/{$slug}-{$name}.php" ) ) {
			$template = AV5C_PATH . "templates/{$slug}-{$name}.php";
		}

		// If template file doesn't exist, look in yourtheme/slug.php and yourtheme/woocommerce/slug.php.
		if ( ! $template && ! defined( 'AV5C_TEMPLATE_DEBUG_MODE' ) ) {
			$template = locate_template( array( "{$slug}.php" ) );
		}

		if ( ! $template && file_exists( AV5C_PATH . "templates/{$slug}.php" ) ) {
			$template = AV5C_PATH . "templates/{$slug}.php";
		}

		return $template;
	}
} // End if().
if ( ! function_exists( 'av5c_get_template' ) ) {
	/**
	 * Get other templates (e.g. product attributes) passing attributes and including the file.
	 *
	 * @access public
	 * @param string $template_name Template name.
	 * @param array  $args          Arguments. (default: array).
	 * @param string $template_path Template path. (default: '').
	 * @param string $default_path  Default path. (default: '').
	 */
	function av5c_get_template( $template_name, $args = array(), $template_path = '', $default_path = '' ) {
		if ( ! empty( $args ) && is_array( $args ) ) {
			extract( $args ); // @codingStandardsIgnoreLine
		}

		$located = av5c_locate_template( $template_name, $template_path, $default_path );

		if ( ! file_exists( $located ) ) {
			/* translators: %s template */
			error_log( sprintf( __( '%1$s was called incorrectly. "%2$s" does not exist.', '5th-avenue' ), __FUNCTION__, $located ) ); // @codingStandardsIgnoreLine WordPress.VIP.RestrictedFunctions.error_log
			return;
		}

		// Allow 3rd party plugin filter template file from their plugin.
		$located = apply_filters( 'av5c_get_template', $located, $template_name, $args, $template_path, $default_path );

		do_action( 'av5c_before_template_part', $template_name, $template_path, $located, $args );

		include $located;

		do_action( 'av5c_after_template_part', $template_name, $template_path, $located, $args );
	}
}

if ( ! function_exists( 'av5c_get_template_html' ) ) {
	/**
	 * Like wc_get_template, but returns the HTML instead of outputting.
	 *
	 * @see wc_get_template
	 * @param string $template_name Template name.
	 * @param array  $args          Arguments. (default: array).
	 * @param string $template_path Template path. (default: '').
	 * @param string $default_path  Default path. (default: '').
	 *
	 * @return string
	 */
	function av5c_get_template_html( $template_name, $args = array(), $template_path = '', $default_path = '' ) {
		ob_start();
		av5c_get_template( $template_name, $args, $template_path, $default_path );
		return ob_get_clean();
	}
}

if ( ! function_exists( 'av5c_locate_template' ) ) {
	/**
	 * Locate a template and return the path for inclusion.
	 *
	 * This is the load order:
	 *
	 * yourtheme/$template_path/$template_name
	 * yourtheme/$template_name
	 * $default_path/$template_name
	 *
	 * @access public
	 * @param string $template_name Template name.
	 * @param string $default_path  Default path. (default: '').
	 * @return string
	 */
	function av5c_locate_template( $template_name, $default_path = '' ) {

		if ( ! $default_path ) {
			$default_path = AV5C_PATH . 'templates/';
		}

		// Look within passed path within the theme - this is priority.
		$template = locate_template( array( $template_name ) );

		// Get default template/.
		if ( ! $template || defined( 'AV5C_TEMPLATE_DEBUG_MODE' ) ) {
			$template = $default_path . $template_name;
		}

		// Return what we found.
		return apply_filters( 'av5c_locate_template', $template, $template_name );
	}
} // End if().

if ( ! function_exists( 'av5_is_woocommerce_activated' ) ) {

	/**
	 * Query WooCommerce activation
	 */
	function av5_is_woocommerce_activated() {
		return class_exists( 'WooCommerce' ) ? true : false;
	}
}

if ( ! function_exists( 'av5_get_option' ) ) {

	/**
	 * Get value settings theme
	 *
	 * @global array $$opt_name Global variable settings.
	 *
	 * @param string $name Name options.
	 * @param mixed  $default Default value.
	 *
	 * @return mixed
	 */
	function av5_get_option( $name, $default = '' ) {
		global $lid_av5;
		if ( empty( $lid_av5 ) ) {
			$opt_name	 = apply_filters( 'av5_redux_name', 'lid_av5' );
			$lid_av5	 = get_option( $opt_name, array() );
		}
		if ( is_array( $lid_av5 ) && array_key_exists( $name, $lid_av5 ) ) {
			$value = $lid_av5[ $name ];
		} else {
			$value = apply_filters( 'av5_get_option_fail', $default, $name );
		}

		$value = apply_filters( 'av5_option_' . $name, $value, $name, $default );
		return apply_filters( 'av5_get_option', $value, $name, $default );
	}
}
