<?php
/**
 * Shortcode 'Slide'
 *
 * @package           5th-Avenue\Shortcode
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'init_slide_class' ) ) {

	/**
	 * Add new backend class for carousel item
	 */
	function init_slide_class() {
		VcShortcodeAutoloader::getInstance()->includeClass( 'WPBakeryShortCode_VC_Tta_Section' );

		/**
		 * Extend class for slide elements
		 */
		class WPBakeryShortCode_slide extends WPBakeryShortCode_VC_Tta_Section { // @codingStandardsIgnoreLine EAR.NamingConventions.ValidClassName.Invalid
		};
	}

	add_action( 'vc_before_init', 'init_slide_class' );
}

/**
 * Shortcode 'Slide'
 */
class AV5_Shortcode_Slide extends AV5_Shortcode {

	/**
	 * This class
	 *
	 * @var \AV5_Shortcode_Slide
	 */
	protected static $_instance = null;

	/**
	 * Get this class object
	 *
	 * @return \AV5_Shortcode_Slide
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->name						 = esc_html__( 'Carousel Item', '5th-avenue' );
		$this->base						 = 'slide';
		$this->html_template			 = 'slide.php';
		$this->allowed_container_element = 'vc_row';
		$this->show_settings_on_create	 = false;
		$this->icon						 = 'av5_vc_carousel-icon';
		$this->is_container				 = true;
		$this->as_child					 = array(
			'only' => 'carousel',
		);
		$this->params					 = array(
			array(
				'type'			 => 'textfield',
				'param_name'	 => 'title',
				'heading'		 => esc_html__( 'Title', 'js_composer' ),
				'description'	 => esc_html__( 'Enter section title (Note: you can leave it empty).', 'js_composer' ),
			),
			array(
				'type'			 => 'el_id',
				'param_name'	 => 'tab_id',
				'settings'		 => array(
					'auto_generate' => true,
				),
				'heading'		 => esc_html__( 'Section ID', 'js_composer' ),
				'description'	 => __( 'Enter section ID (Note: make sure it is unique and valid according to <a href="%s" target="_blank">w3c specification</a>).', 'js_composer' ),
			),
		);
		$this->js_view					 = 'VcBackendTtaSectionView';
		$this->custom_markup			 = '
		<div class="vc_tta-panel-heading">
		    <h4 class="vc_tta-panel-title vc_tta-controls-icon-position-left"><a href="javascript:;" data-vc-target="[data-model-id=\'{{ model_id }}\']" data-vc-accordion data-vc-container=".vc_tta-container"><span class="vc_tta-title-text">{{ section_title }}</span><i class="vc_tta-controls-icon vc_tta-controls-icon-plus"></i></a></h4>
		</div>
		<div class="vc_tta-panel-body">
			{{ editor_controls }}
			<div class="{{ container-class }}">
			{{ content }}
			</div>
		</div>';
		parent::__construct();
	}

}
