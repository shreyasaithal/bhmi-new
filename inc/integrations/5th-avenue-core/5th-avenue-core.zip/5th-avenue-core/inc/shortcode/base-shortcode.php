<?php
/**
 * Shortcode helper class
 *
 * @package           5th-Avenue\Shortcode
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;


/**
 * Shortcode helper class
 */
class AV5_Shortcode {

	/**
	 * Name shortcode
	 *
	 * @var string
	 */
	public $name = '';

	/**
	 * Slug shortcode
	 *
	 * @var string
	 */
	public $base = '';

	/**
	 * Parameters for visual composer
	 *
	 * @var array
	 */
	public $params = array();

	/**
	 * Default value for attributes
	 *
	 * @var array
	 */
	public $default = array();

	/**
	 * Validation arguments
	 *
	 * @var array
	 */
	public $validation = array();

	/**
	 * Template for shortcode
	 *
	 * @var string
	 */
	public $html_template = 'index.php';

	/**
	 * Constructor
	 */
	function __construct() {
		if ( ! is_array( $this->params ) ) {
			$this->params = array();
		}
		if ( empty( $this->default ) ) {
			$this->default = array();
			$this->set_default();
		}
		if ( ! is_array( $this->validation ) ) {
			$this->validation = array();
		}
		if ( ! empty( $this->base ) ) {
			add_shortcode( $this->base, array( $this, 'shortcode' ) );
		}

		add_action( 'vc_before_init', array( $this, 'vc_init' ) );
		if ( ! empty( $this->validation ) ) {
			add_filter( 'av5_shortcode_validate_atts_' . $this->base, array( $this, 'valdation' ), 100 );
		}
	}

	/**
	 * Set default for shortcode
	 *
	 * @return array
	 */
	function set_default() {
		foreach ( $this->params as $param ) {
			if ( array_key_exists( 'param_name', (array) $param ) ) {
				if ( array_key_exists( 'std', (array) $param ) ) {
					$this->default[ $param['param_name'] ] = $param['std'];
				} elseif ( array_key_exists( 'value', (array) $param ) ) {
					if ( is_array( $param['value'] ) && in_array( $param['type'], array( 'dropdown' ) ) ) {
						$this->default[ $param['param_name'] ] = array_shift( $param['value'] );
					} else {
						$this->default[ $param['param_name'] ] = $param['value'];
					}
				} else {
					$this->default[ $param['param_name'] ] = '';
				}
			}
		}
		$this->default = apply_filters( 'av5_shortcode_default_' . $this->base, $this->default );
		return $this->default;
	}

	/**
	 * Generate visual composer array for shortcode
	 *
	 * @return array
	 */
	function vc_data() {
		$new_data	 = apply_filters( 'av5_shortcode_vc_fields', array(
			'as_child',
			'allowed_container_element',
			'custom_markup',
			'default_content',
			'is_container',
			'show_settings_on_create',
			'js_view',
			'as_parent',
			'admin_enqueue_js',
			'content_element',
		) );
		$data		 = array(
			'base'			 => '',
			'category'		 => 'Theme',
			'class'			 => '',
			'description'	 => '',
			'html_template'	 => '',
			'icon'			 => '',
			'name'			 => '',
			'params'		 => array(),
		);
		foreach ( $data as $key => $value ) {
			if ( isset( $this->$key ) ) {
				$data[ $key ] = $this->$key;
			}
		}

		foreach ( $new_data as $key ) {
			if ( isset( $this->$key ) ) {
				$data[ $key ] = $this->$key;
			}
		}

		return apply_filters( 'av5_shortcode_vc_' . $this->base, $data );
	}

	/**
	 * Add shortcode in visual composer
	 */
	function vc_init() {
		if ( function_exists( 'vc_map' ) ) {
			$data = $this->vc_data();
			vc_map( $data );
		}
	}

	/**
	 * Prepare attributes for shortcode
	 *
	 * @param array $atts Attributes for shorcode.
	 * @return array
	 */
	function prepare_atts( $atts = array() ) {
		return $atts;
	}

	/**
	 * Prepare style for shortcode
	 *
	 * @param array $atts Attributes for shorcode.
	 * @return array
	 */
	function prepare_style( $atts = array() ) {
		$atts['custom_class']	 = '';
		$atts['custom_css']	 = '';
		if ( isset( $atts['custom_style'] ) && ! empty( $atts['custom_style'] ) ) {
			if ( isset( $atts['css'] ) && ! empty( $atts['css'] ) ) {
				if ( function_exists( 'vc_shortcode_custom_css_class' ) ) {
					$atts['custom_class'] = vc_shortcode_custom_css_class( $atts['css'], ' ' );
				}
			}
			if ( empty( $atts['custom_class'] ) ) {
				$atts['custom_class'] = sprintf( 'vc_custom_%s_%s', time(), mt_rand( 0, time() ) );
			}
			$atts['custom_css'] = sprintf( '<style> .%s{%s} </style>', $atts['custom_class'], $atts['custom_style'] );
		} else {
			$atts['custom_style'] = '';
			if ( isset( $atts['css'] ) && ! empty( $atts['css'] ) ) {
				if ( function_exists( 'vc_shortcode_custom_css_class' ) ) {
					$atts['custom_class'] = vc_shortcode_custom_css_class( $atts['css'], ' ' );
				}
			}
		}

		return $atts;
	}

	/**
	 * Output shortcode
	 *
	 * @param array  $atts Attributes for shorcode.
	 * @param string $content Content shortcode.
	 * @param array  $raw_atts Original atributes without validations for shortcode.
	 */
	function htmloutput( $atts = array(), $content = '', $raw_atts = array() ) {
		$atts['content']	 = do_shortcode( $content );
		$atts['_raw_atts']	 = $raw_atts;
		$atts				 = $this->prepare_atts( $atts );
		$atts				 = $this->prepare_style( $atts );
		$atts				 = apply_filters( 'av5_shortcode_atts_' . $this->base, $atts );
		$template			 = apply_filters( 'av5_shortcode_template_' . $this->base, 'shortcode' . DIRECTORY_SEPARATOR . $this->html_template );

		$located = av5c_locate_template( $template );

		if ( ! file_exists( $located ) || empty( $atts ) ) {
			return;
		}

		if ( is_array( $atts ) ) {
			extract( $atts ); // @codingStandardsIgnoreLine WordPress.Functions.DontExtract.extract
		}

		do_action( 'av5_shortcode_before_template_' . $this->base, $atts, $template );
		include $located;
		do_action( 'av5_shortcode_after_template_' . $this->base, $atts, $template );
	}

	/**
	 * Apply validation for attributes.
	 *
	 * @param array $atts Atributes for shortcode.
	 * @return array
	 */
	function valdation( $atts ) {
		if ( ! empty( $this->validation ) ) {
			$atts = filter_var_array( $atts, $this->validation, true );
		}
		return $atts;
	}

	/**
	 * Apply function for shortcode
	 *
	 * @param array  $atts Attributes for shorcode.
	 * @param string $content Content shortcode.
	 * @return string
	 */
	public function shortcode( $atts = array(), $content = '' ) {
		$default = $this->default;
		if ( function_exists( 'vc_map_get_attributes' ) ) {
			$default = wp_parse_args( vc_map_get_attributes( $this->base, $this->default ), $default );
		}
		$valid_atts	 = $atts		 = shortcode_atts( $default, $atts );
		if ( ! empty( $this->validation ) ) {
			$valid_atts = filter_var_array( $valid_atts, $this->validation, true );
		}
		$valid_atts = apply_filters( 'av5_shortcode_validate_atts_' . $this->base, $atts );

		ob_start();
		$this->htmloutput( $valid_atts, $content, $atts );
		$data = ob_get_clean();

		return $data;
	}

	/**
	 * Add class for cusmot css animation
	 *
	 * @see \WPBakeryVisualComposerAbstract::getCSSAnimation
	 * @param string $css_animation Selected css animation.
	 * @return string
	 */
	public function getCSSAnimation( $css_animation ) { // @codingStandardsIgnoreLine WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		$output = '';
		if ( '' !== $css_animation && 'none' !== $css_animation ) {
			wp_enqueue_script( 'waypoints' );
			wp_enqueue_style( 'animate-css' );
			$output = ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
		}

		return $output;
	}

}
