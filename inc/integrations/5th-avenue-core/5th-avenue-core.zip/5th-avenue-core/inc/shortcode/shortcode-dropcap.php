<?php
/**
 * Shortcode "Dropcap"
 *
 * @package           5th-Avenue\Shortcode
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;


/**
 * Shortcode "Dropcap"
 */
class AV5_Shortcode_Dropcap extends AV5_Shortcode {

	/**
	 * This class
	 *
	 * @var \AV5_Shortcode_Dropcap
	 */
	protected static $_instance = null;

	/**
	 * Get this class object
	 *
	 * @return \AV5_Shortcode_Dropcap
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->name			 = esc_html__( 'AV5 Dropcap', '5th-avenue' );
		$this->base			 = 'av5_dropcap';
		$this->html_template = 'dropcap.php';
		$this->icon			 = 'av5_vc_dropcap-icon';
		$this->params		 = array(
			array(
				'type'			 => 'textfield',
				'heading'		 => esc_html__( 'Content', '5th-avenue' ),
				'description'	 => esc_html__( 'Add your Letter here', '5th-avenue' ),
				'param_name'	 => 'content',
				'value'			 => '',
			),
			array(
				'type'			 => 'dropdown',
				'heading'		 => esc_html__( 'Font', '5th-avenue' ),
				'description'	 => esc_html__( 'Choose what font to use for dropcap', '5th-avenue' ),
				'param_name'	 => 'font',
				'value'			 => array(
					esc_html__( 'H1', '5th-avenue' )			 => 'h1-dropcap',
					esc_html__( 'H2', '5th-avenue' )			 => 'h2-dropcap',
					esc_html__( 'H3', '5th-avenue' )			 => 'h3-dropcap',
					esc_html__( 'Content Text', '5th-avenue' )	 => '',
				),
				'std'			 => '',
			),
			array(
				'type'		 => 'dropdown',
				'heading'	 => esc_html__( 'Dropcap Size', '5th-avenue' ),
				'param_name' => 'size',
				'value'		 => array(
					esc_html__( 'Big', '5th-avenue' )	 => 'big-dropcap',
					esc_html__( 'Small', '5th-avenue' ) => 'small-dropcap',
				),
				'std'		 => 'big-dropcap',
			),
			array(
				'type'		 => 'colorpicker',
				'heading'	 => esc_html__( 'Dropcap Color', '5th-avenue' ),
				'param_name' => 'custom_color',
			),
			array(
				'type'		 => 'css_editor',
				'heading'	 => esc_html__( 'CSS box', 'js_composer' ),
				'param_name' => 'css',
				'group'		 => esc_html__( 'Design Options', 'js_composer' ),
			),
		);
		parent::__construct();
	}
}
