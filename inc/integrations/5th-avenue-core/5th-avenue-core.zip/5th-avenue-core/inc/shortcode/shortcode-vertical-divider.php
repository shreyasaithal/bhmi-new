<?php
/**
 * Shortcode "Vertical Divider"
 *
 * @package           5th-Avenue\Shortcode
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

/**
 * Shortcode "Vertical Divider"
 */
class AV5_Shortcode_Vertical_Divider extends AV5_Shortcode {

	/**
	 * This class
	 *
	 * @var \AV5_Shortcode_Vertical Divider
	 */
	protected static $_instance = null;

	/**
	 * Get this class object
	 *
	 * @return \AV5_Shortcode_Vertical Divider
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->name			 = esc_html__( 'AV5 Vertical Divider', '5th-avenue' );
		$this->base			 = 'av5_vertical_divider';
		$this->html_template = 'vertical-divider.php';
		$this->icon			 = 'av5_vc_vertical-icon';
		$this->params		 = array(
			array(
				'type'			 => 'dropdown',
				'heading'		 => esc_html__( 'Style', '5th-avenue' ),
				'description'	 => esc_html__( 'Select button display style.', '5th-avenue' ),
				'param_name'	 => 'style',
				'value'			 => array(
					esc_html__( 'Simple', '5th-avenue' )	 => 'simple',
					esc_html__( 'Animated', '5th-avenue' )	 => 'animated',
				),
				'std'			 => 'flat',
			),
			array(
				'type'			 => 'colorpicker',
				'heading'		 => esc_html__( 'Divider Color', '5th-avenue' ),
				'param_name'	 => 'custom_color',
				'description'	 => esc_html__( 'Select custom color divider color.', '5th-avenue' ),
			),
			array(
				'type'			 => 'textfield',
				'heading'		 => esc_html__( 'Height', '5th-avenue' ),
				'description'	 => esc_html__( 'Set height for vertical divider', '5th-avenue' ),
				'param_name'	 => 'height',
				'value'			 => '',
				'dependency'	 => array(
					'element'	 => 'style',
					'value'		 => 'simple',
				),
			),
		);
		parent::__construct();
	}
}
