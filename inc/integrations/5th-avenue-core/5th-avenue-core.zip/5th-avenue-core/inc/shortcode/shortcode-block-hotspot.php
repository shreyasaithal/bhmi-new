<?php
/**
 * Shortcode 'Block Hotspot'
 *
 * @package           5th-Avenue\Shortcode
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'init_block_hotspot_class' ) ) {

	/**
	 * Add new backend class for block_hotspot
	 */
	function init_block_hotspot_class() {
		VcShortcodeAutoloader::getInstance()->includeClass( 'WPBakeryShortCode_VC_Tta_Tabs' );

		/**
		 * Extend class for block hot spots
		 */
		class WPBakeryShortCode_block_hotspot extends WPBakeryShortCode_VC_Tta_Tabs { // @codingStandardsIgnoreLine PEAR.NamingConventions.ValidClassName.Invalid
		};
	}

	add_action( 'vc_before_init', 'init_block_hotspot_class' );
}

/**
 * Shortcode 'Block Hotspot'
 */
class AV5_Shortcode_Block_Hotspot extends AV5_Shortcode {

	/**
	 * This class
	 *
	 * @var \AV5_Shortcode_Block_Hotspot
	 */
	protected static $_instance = null;

	/**
	 * Get this class object
	 *
	 * @return \AV5_Shortcode_Block_Hotspot
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->name						 = esc_html__( 'Block with Hotspot', '5th-avenue' );
		$this->description				 = esc_html__( 'Add Hotspot on your Element', '5th-avenue' );
		$this->base						 = 'block_hotspot';
		$this->html_template			 = 'block-hotspot.php';
		$this->icon						 = 'av5_vc_parallax-icon';
		$this->show_settings_on_create	 = false;
		$this->is_container				 = true;
		$this->params					 = array(
			array(
				'type'				 => 'attach_image',
				'param_name'		 => 'image',
				'heading'			 => esc_html__( 'Image', '5th-avenue' ),
				'edit_field_class'	 => 'vc_column vc_col-sm-12',
			),
			array(
				'type'			 => 'hotspot_point',
				'heading'		 => esc_html__( 'Point of motion', '5th-avenue' ),
				'param_name'	 => 'point',
				'max_points'	 => 1,
			),
			array(
				'type'		 => 'dropdown',
				'heading'	 => esc_html__( 'Motion type', '5th-avenue' ),
				'param_name' => 'motiontype',
				'value'		 => array(
					esc_html__( 'Object', '5th-avenue' )	 => 'object',
					esc_html__( 'Path', '5th-avenue' )		 => 'path',
				),
				'std'		 => 'object',
			),
			array(
				'type'		 => 'checkbox',
				'heading'	 => esc_html__( 'Stopping the movement when the end point', '5th-avenue' ),
				'param_name' => 'stoponpoint',
				'value'		 => array(
					esc_html__( 'Yes', '5th-avenue' ) => 'true',
				),
			),
			array(
				'type'			 => 'textfield',
				'heading'		 => esc_html__( 'Padding Top', '5th-avenue' ),
				'param_name'	 => 'padding_top',
				'value'			 => 0,
			),
			array(
				'type'			 => 'textfield',
				'heading'		 => esc_html__( 'Padding Bottom', '5th-avenue' ),
				'param_name'	 => 'padding_bottom',
				'value'			 => 0,
			),
			array(
				'type'		 => 'css_editor',
				'heading'	 => esc_html__( 'CSS box', 'js_composer' ),
				'param_name' => 'css',
				'group'		 => esc_html__( 'Design Options', 'js_composer' ),
			),
		);
		$this->js_view					 = 'AV5BackendBlockHotspotView';
		$this->custom_markup			 = '
<div class="vc_tta-container" data-vc-action="collapse">
	<div class="vc_general vc_tta vc_tta-tabs vc_tta-color-backend-tabs-white vc_tta-style-flat vc_tta-shape-rounded vc_tta-spacing-1 vc_tta-tabs-position-top vc_tta-controls-align-left">
		<div class="vc_tta-tabs-container">
			<ul class="vc_tta-tabs-list">
				<li class="vc_tta-tab" data-vc-tab data-vc-target-model-id="{{ model_id }}" data-element_type="vc_tta_section"><a href="javascript:;" data-vc-tabs data-vc-container=".vc_tta" data-vc-target="[data-model-id=\'{{ model_id }}\']" data-vc-target-model-id="{{ model_id }}"><span class="vc_tta-title-text">{{ section_title }}</span></a></li>
			</ul>
		</div>
		<div class="vc_tta-panels vc_clearfix {{container-class}}">
		  {{ content }}
		</div>
	</div>
</div>';
		$this->default_content			 = '[hotspot title="' . esc_html__( 'Section', '5th-avenue' ) . '"][/hotspot]';
		$this->admin_enqueue_js			 = array(
			AV5C_URL . '/assets/js/js_composer.js',
		);
		if ( function_exists( 'vc_asset_url' ) ) {
			$this->admin_enqueue_js[] = vc_asset_url( 'lib/vc_tabs/vc-tabs.min.js' );
		}
		$this->validation	 = array(
			'image'			 => array(
				'filter'	 => FILTER_VALIDATE_INT,
				'options'	 => array(
					'default'	 => 0,
					'min_range'	 => 0,
				),
			),
			'padding_top'	 => FILTER_VALIDATE_INT,
			'padding_bottom' => FILTER_VALIDATE_INT,
			'point'			 => FILTER_DEFAULT,
			'motiontype'	 => FILTER_DEFAULT,
			'stoponpoint'	 => FILTER_VALIDATE_BOOLEAN,
			'css'			 => FILTER_DEFAULT,
		);
		$this->default		 = array(
			'image'			 => 0,
			'padding_top'	 => 0,
			'padding_bottom' => 0,
			'point'			 => '',
			'motiontype'	 => 'object',
			'stoponpoint'	 => false,
			'css'			 => '',
		);

		parent::__construct();
	}

	/**
	 * Prepare attributes for shortcode
	 *
	 * @param array $atts Attributes for shorcode.
	 * @return array
	 */
	function prepare_atts( $atts = array() ) {
		if ( ! empty( $atts['image'] ) ) {
			$atts['content'] .= wp_get_attachment_image( $atts['image'], 'full' );
		}
		$atts['attr'] = '';
		if ( ! empty( $atts['point'] ) ) {
			$atts['attr'] .= sprintf( ' data-point="%s"', esc_attr( $atts['point'] ) );
		}
		if ( ! empty( $atts['motiontype'] ) ) {
			$atts['attr'] .= sprintf( ' data-motiontype="%s"', esc_attr( $atts['motiontype'] ) );
		}
		if ( ! empty( $atts['stoponpoint'] ) ) {
			$atts['attr'] .= ' data-stoponpoint="on"';
		}
		if ( ! empty( $atts['padding_top'] ) || ! empty( $atts['padding_bottom'] ) ) {
			$atts['attr'] .= sprintf( ' style="%s"', sprintf( 'padding-top: %spx; padding-bottom: %spx;', $atts['padding_top'], $atts['padding_bottom'] ) );
		}

		return $atts;
	}

}
