<?php
/**
 * Shortcode "Text with Icon"
 *
 * @package           5th-Avenue\Shortcode
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

/**
 * Shortcode "Text with Icon"
 */
class AV5_Shortcode_Text_with_Icon extends AV5_Shortcode { // @codingStandardsIgnoreLine PEAR.NamingConventions.ValidClassName.Invalid

	/**
	 * This class
	 *
	 * @var \AV5_Shortcode_Text_With_Icon
	 */
	protected static $_instance = null;

	/**
	 * Get this class object
	 *
	 * @return \AV5_Shortcode_Text_With_Icon
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->name			 = esc_html__( 'AV5 Text with Icon', '5th-avenue' );
		$this->base			 = 'av5_text_with_icon';
		$this->html_template = 'text-with-icon.php';
		$this->icon			 = 'av5_vc_banner-icon';
		$this->params		 = array(
			array(
				'type'			 => 'dropdown',
				'heading'		 => esc_html__( 'Icon library', '5th-avenue' ),
				'value'			 => array(
					esc_html__( 'Font Awesome', '5th-avenue' )	 => 'fontawesome',
					esc_html__( 'Open Iconic', '5th-avenue' )	 => 'openiconic',
					esc_html__( 'Typicons', '5th-avenue' )		 => 'typicons',
					esc_html__( 'Entypo', '5th-avenue' )		 => 'entypo',
					esc_html__( 'Linecons', '5th-avenue' )		 => 'linecons',
					esc_html__( 'Mono Social', '5th-avenue' )	 => 'monosocial',
					esc_html__( 'Material', '5th-avenue' )		 => 'material',
					esc_html__( 'Image icon', '5th-avenue' )	 => 'image-icon',
				),
				'admin_label'	 => true,
				'param_name'	 => 'type',
				'description'	 => esc_html__( 'Select icon library.', '5th-avenue' ),
			),
			array(
				'type'			 => 'iconpicker',
				'heading'		 => esc_html__( 'Icon', '5th-avenue' ),
				'param_name'	 => 'icon_fontawesome',
				'value'			 => 'fa fa-adjust',
				'settings'		 => array(
					'emptyIcon'		 => false,
					'iconsPerPage'	 => 4000,
				),
				'dependency'	 => array(
					'element'	 => 'type',
					'value'		 => 'fontawesome',
				),
				'description'	 => esc_html__( 'Select icon from library.', '5th-avenue' ),
			),
			array(
				'type'			 => 'iconpicker',
				'heading'		 => esc_html__( 'Icon', '5th-avenue' ),
				'param_name'	 => 'icon_openiconic',
				'value'			 => 'vc-oi vc-oi-dial',
				'settings'		 => array(
					'emptyIcon'		 => false,
					'type'			 => 'openiconic',
					'iconsPerPage'	 => 4000,
				),
				'dependency'	 => array(
					'element'	 => 'type',
					'value'		 => 'openiconic',
				),
				'description'	 => esc_html__( 'Select icon from library.', '5th-avenue' ),
			),
			array(
				'type'			 => 'iconpicker',
				'heading'		 => esc_html__( 'Icon', '5th-avenue' ),
				'param_name'	 => 'icon_typicons',
				'value'			 => 'typcn typcn-adjust-brightness',
				'settings'		 => array(
					'emptyIcon'		 => false,
					'type'			 => 'typicons',
					'iconsPerPage'	 => 4000,
				),
				'dependency'	 => array(
					'element'	 => 'type',
					'value'		 => 'typicons',
				),
				'description'	 => esc_html__( 'Select icon from library.', '5th-avenue' ),
			),
			array(
				'type'		 => 'iconpicker',
				'heading'	 => esc_html__( 'Icon', '5th-avenue' ),
				'param_name' => 'icon_entypo',
				'value'		 => 'entypo-icon entypo-icon-note',
				'settings'	 => array(
					'emptyIcon'		 => false,
					'type'			 => 'entypo',
					'iconsPerPage'	 => 4000,
				),
				'dependency' => array(
					'element'	 => 'type',
					'value'		 => 'entypo',
				),
			),
			array(
				'type'			 => 'iconpicker',
				'heading'		 => esc_html__( 'Icon', '5th-avenue' ),
				'param_name'	 => 'icon_linecons',
				'value'			 => 'vc_li vc_li-heart',
				'settings'		 => array(
					'emptyIcon'		 => false,
					'type'			 => 'linecons',
					'iconsPerPage'	 => 4000,
				),
				'dependency'	 => array(
					'element'	 => 'type',
					'value'		 => 'linecons',
				),
				'description'	 => esc_html__( 'Select icon from library.', '5th-avenue' ),
			),
			array(
				'type'			 => 'iconpicker',
				'heading'		 => esc_html__( 'Icon', '5th-avenue' ),
				'param_name'	 => 'icon_monosocial',
				'value'			 => 'vc-mono vc-mono-fivehundredpx',
				'settings'		 => array(
					'emptyIcon'		 => false,
					'type'			 => 'monosocial',
					'iconsPerPage'	 => 4000,
				),
				'dependency'	 => array(
					'element'	 => 'type',
					'value'		 => 'monosocial',
				),
				'description'	 => esc_html__( 'Select icon from library.', '5th-avenue' ),
			),
			array(
				'type'			 => 'iconpicker',
				'heading'		 => esc_html__( 'Icon', '5th-avenue' ),
				'param_name'	 => 'icon_material',
				'value'			 => 'vc-material vc-material-cake',
				'settings'		 => array(
					'emptyIcon'		 => false,
					'type'			 => 'material',
					'iconsPerPage'	 => 4000,
				),
				'dependency'	 => array(
					'element'	 => 'type',
					'value'		 => 'material',
				),
				'description'	 => esc_html__( 'Select icon from library.', '5th-avenue' ),
			),
			array(
				'type'			 => 'attach_image',
				'heading'		 => esc_html__( 'Image', '5th-avenue' ),
				'param_name'	 => 'image',
				'value'			 => '',
				'description'	 => esc_html__( 'Select image from media library.', '5th-avenue' ),
				'dependency'	 => array(
					'element'	 => 'type',
					'value'		 => 'image-icon',
				),
				'admin_label'	 => true,
			),
			array(
				'type'		 => 'colorpicker',
				'heading'	 => esc_html__( 'Icon color', '5th-avenue' ),
				'param_name' => 'icon_color',
				'std'		 => '',
			),
			array(
				'type'		 => 'textarea_html',
				'heading'	 => esc_html__( 'Text content', '5th-avenue' ),
				'param_name' => 'content',
				'value'		 => '',
			),
			array(
				'type'		 => 'textfield',
				'heading'	 => esc_html__( 'Custom icon font size (px)', '5th-avenue' ),
				'param_name' => 'font_size',
				'value'		 => '',
			),
			array(
				'type'		 => 'textfield',
				'heading'	 => esc_html__( 'Extra class name', '5th-avenue' ),
				'param_name' => 'extra_class',
				'value'		 => '',
			),
			array(
				'type'		 => 'textfield',
				'heading'	 => esc_html__( 'Animation Delay', '5th-avenue' ),
				'param_name' => 'anim_delay',
				'value'		 => '',
			),
			array(
				'type'		 => 'css_editor',
				'heading'	 => esc_html__( 'CSS box', 'js_composer' ),
				'param_name' => 'css',
				'group'		 => esc_html__( 'Design Options', 'js_composer' ),
			),
		);
		if ( function_exists( 'vc_map_add_css_animation' ) ) {
			$this->params[] = vc_map_add_css_animation( true );
		}
		$this->default = array(
			'css_animation' => '',
		);

		parent::__construct();
	}
}
