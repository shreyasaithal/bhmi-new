<?php
/**
 * 5th-Avenue register shortcode.
 *
 * @package           5th-Avenue\Shortcode
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'AV5_Shortcode' ) ) {
	require_once AV5C_PATH . 'inc/shortcode/base-shortcode.php';
}

if ( ! function_exists( 'av5c_register_shortcode' ) ) {
	/**
	 * Register shortcode
	 */
	function av5c_register_shortcode() {
		$paths = glob( AV5C_PATH . 'inc' . DIRECTORY_SEPARATOR . 'shortcode' . DIRECTORY_SEPARATOR . 'shortcode-*.php' );
		foreach ( $paths as $path ) {
			$class_name = 'AV5_Shortcode_' . str_replace( ' ', '_', ucwords( str_replace( array( 'shortcode-', '.php', '-' ), array( '', '', ' ' ), basename( $path ) ) ) );
			require_once $path;
			if ( method_exists( $class_name, 'shortcode' ) ) {
				$class_name::instance();
			}
		}
	}
}
av5c_register_shortcode();
