<?php
/**
 * Shortcode 'Best Selling Products Carousel'
 *
 * @package           5th-Avenue\Shortcode
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;


/**
 * Shortcode 'Best Selling Products Carousel'
 */
class AV5_Shortcode_Best_Selling_Products_Carousel extends AV5_Shortcode {

	/**
	 * This class
	 *
	 * @var \AV5_Shortcode_Best_Selling_Products_Carousel
	 */
	protected static $_instance = null;

	/**
	 * Get this class object
	 *
	 * @return \AV5_Shortcode_Best_Selling_Products_Carousel
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		add_action( 'woocommerce_loaded', array( $this, 'init' ) );
	}

	/**
	 * Init shortcode
	 */
	function init() {
		if ( ! av5_is_woocommerce_activated() ) {
			return;
		}
		$this->name						 = esc_html__( 'Best Selling Products Carousel', '5th-avenue' );
		$this->description				 = esc_html__( 'List best selling products on sale in a carousel slider', '5th-avenue' );
		$this->base						 = 'best_selling_products_carousel';
		$this->icon						 = 'av5_vc_carousel-icon';
		$this->html_template			 = 'product-carousel.php';
		$this->show_settings_on_create	 = true;
		$this->params					 = array(
			array(
				'type'			 => 'textfield',
				'heading'		 => esc_html__( 'Max Products', '5th-avenue' ),
				'value'			 => 12,
				'save_always'	 => true,
				'param_name'	 => 'limit',
			),
			array(
				'type'				 => 'dropdown',
				'heading'			 => esc_html__( 'Columns <span>Desktop</span>', '5th-avenue' ),
				'save_always'		 => true,
				'param_name'		 => 'column_desktop',
				'group'				 => esc_html__( 'Carousel Options', '5th-avenue' ),
				'value'				 => array(
					1	 => 1,
					2	 => 2,
					3	 => 3,
					4	 => 4,
					5	 => 5,
					6	 => 6,
					7	 => 7,
					8	 => 8,
				),
				'std'				 => 4,
				'edit_field_class'	 => 'col-md-2 vc_column',
			),
			array(
				'type'				 => 'dropdown',
				'heading'			 => __( '<span>Desktop Small</span>', '5th-avenue' ),
				'save_always'		 => true,
				'param_name'		 => 'column_desktop_small',
				'group'				 => esc_html__( 'Carousel Options', '5th-avenue' ),
				'value'				 => array(
					1	 => 1,
					2	 => 2,
					3	 => 3,
					4	 => 4,
					5	 => 5,
					6	 => 6,
					7	 => 7,
					8	 => 8,
				),
				'std'				 => 3,
				'edit_field_class'	 => 'col-md-2 vc_column',
			),
			array(
				'type'				 => 'dropdown',
				'heading'			 => __( '<span>Table</span>', '5th-avenue' ),
				'save_always'		 => true,
				'param_name'		 => 'column_table',
				'group'				 => esc_html__( 'Carousel Options', '5th-avenue' ),
				'value'				 => array(
					1	 => 1,
					2	 => 2,
					3	 => 3,
					4	 => 4,
					5	 => 5,
					6	 => 6,
					7	 => 7,
					8	 => 8,
				),
				'std'				 => 2,
				'edit_field_class'	 => 'col-md-2 vc_column',
			),
			array(
				'type'				 => 'dropdown',
				'heading'			 => __( '<span>Mobile</span>', '5th-avenue' ),
				'save_always'		 => true,
				'param_name'		 => 'column_mobile',
				'group'				 => esc_html__( 'Carousel Options', '5th-avenue' ),
				'value'				 => array(
					1	 => 1,
					2	 => 2,
					3	 => 3,
					4	 => 4,
					5	 => 5,
					6	 => 6,
					7	 => 7,
					8	 => 8,
				),
				'std'				 => 1,
				'edit_field_class'	 => 'col-md-2 vc_column',
			),
			array(
				'type'			 => 'dropdown',
				'heading'		 => esc_html__( 'Column Margin', '5th-avenue' ),
				'save_always'	 => true,
				'param_name'	 => 'column_margin',
				'group'			 => esc_html__( 'Carousel Options', '5th-avenue' ),
				'value'			 => array(
					'None'	 => 0,
					'5px'	 => 5,
					'10px'	 => 10,
					'15px'	 => 15,
					'20px'	 => 20,
					'30px'	 => 30,
					'40px'	 => 40,
					'50px'	 => 50,
				),
				'description'	 => esc_html__( 'Please select your desired column margin', '5th-avenue' ),
			),
			array(
				'type'			 => 'checkbox',
				'heading'		 => esc_html__( 'Autorotate?', '5th-avenue' ),
				'param_name'	 => 'autoplay',
				'group'			 => esc_html__( 'Carousel Options', '5th-avenue' ),
				'value'			 => array(
					esc_html__( 'Yes', '5th-avenue' ) => 'true',
				),
			),
			array(
				'type'			 => 'textfield',
				'heading'		 => esc_html__( 'Autorotation Speed', '5th-avenue' ),
				'param_name'	 => 'autoplay_timeout',
				'group'			 => esc_html__( 'Carousel Options', '5th-avenue' ),
				'dependency'	 => array(
					'element'	 => 'autoplay',
					'value'		 => array( 'true' ),
				),
				'description'	 => esc_html__( 'Enter in milliseconds (default is 5000)', '5th-avenue' ),
			),
			array(
				'type'		 => 'css_editor',
				'heading'	 => esc_html__( 'CSS box', 'js_composer' ),
				'param_name' => 'css',
				'group'		 => esc_html__( 'Design Options', 'js_composer' ),
			),
		);
		$valide_int_min					 = array(
			'filter'	 => FILTER_VALIDATE_INT,
			'options'	 => array(
				'default'	 => 1,
				'min_range'	 => 1,
			),
		);
		$this->validation				 = array(
			'limit'					 => $valide_int_min,
			'column_desktop'		 => $valide_int_min,
			'column_desktop_small'	 => $valide_int_min,
			'column_table'			 => $valide_int_min,
			'column_mobile'			 => $valide_int_min,
			'column_margin'			 => array(
				'filter'	 => FILTER_VALIDATE_INT,
				'options'	 => array(
					'default'	 => 0,
					'min_range'	 => 0,
				),
			),
			'autoplay_timeout'		 => $valide_int_min,
			'autoplay'				 => FILTER_VALIDATE_BOOLEAN,
			'enable_animation'		 => FILTER_VALIDATE_BOOLEAN,
			'css'					 => FILTER_DEFAULT,
		);
		$this->default					 = array(
			'limit'					 => 12,
			'column_desktop'		 => 4,
			'column_desktop_small'	 => 3,
			'column_table'			 => 2,
			'column_mobile'			 => 1,
			'column_margin'			 => 0,
			'autoplay'				 => false,
			'autoplay_timeout'		 => 5000,
			'enable_animation'		 => false,
			'css'					 => '',
		);

		parent::__construct();
	}

	/**
	 * Prepare attributes for shortcode
	 *
	 * @param array $atts Attributes for shorcode.
	 * @return array
	 */
	function prepare_atts( $atts = array() ) {
		if ( ! class_exists( 'WC_Shortcodes' ) ) {
			return false;
		}
		$atts['options'] = array(
			'data-column-desktop'		 => $atts['column_desktop'],
			'data-column-desktop-small'	 => $atts['column_desktop_small'],
			'data-column-table'			 => $atts['column_table'],
			'data-column-mobile'		 => $atts['column_mobile'],
			'data-margin'				 => $atts['column_margin'],
		);
		if ( $atts['autoplay'] ) {
			$atts['options']['data-autoplay']			 = true;
			$atts['options']['data-autoplay-timeout']	 = $atts['autoplay_timeout'];
		}
		foreach ( $atts['options'] as $key => $value ) {
			$atts['options'][ $key ] = sprintf( '%s="%s"', $key, esc_attr( $value ) );
		}
		$atts['options'] = implode( ' ', $atts['options'] );

		$atts['animation'] = $atts['enable_animation'] ? ' owl-carousel-animated' : '';

		$atts['content'] = WC_Shortcodes::best_selling_products( array(
			'limit'		 => absint( $atts['limit'] ),
			'columns'	 => absint( $atts['limit'] ),
		) );

		return $atts;
	}

}
