<?php
/**
 * Shortcode 'Products Carousel'
 *
 * @package           5th-Avenue\Shortcode
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

/**
 * Shortcode 'Products Carousel'
 */
class AV5_Shortcode_Products_Carousel extends AV5_Shortcode {

	/**
	 * This class
	 *
	 * @var \AV5_Shortcode_Products_Carousel
	 */
	protected static $_instance = null;

	/**
	 * Get this class object
	 *
	 * @return \AV5_Shortcode_Products_Carousel
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		add_action( 'woocommerce_loaded', array( $this, 'init' ) );
	}

	/**
	 * Init shortcode
	 */
	function init() {
		if ( ! av5_is_woocommerce_activated() ) {
			return;
		}
		$this->name						 = esc_html__( 'Products Carousel', '5th-avenue' );
		$this->description				 = esc_html__( 'Show multiple products by ID or SKU in a carousel slider', '5th-avenue' );
		$this->base						 = 'products_carousel';
		$this->html_template			 = 'product-carousel.php';
		$this->icon						 = 'av5_vc_carousel-icon';
		$this->show_settings_on_create	 = true;
		$this->params					 = array(
			array(
				'type'			 => 'autocomplete',
				'heading'		 => esc_html__( 'Products', 'js_composer' ),
				'param_name'	 => 'ids',
				'settings'		 => array(
					'multiple'		 => true,
					'sortable'		 => true,
					'unique_values'	 => true,
				// In UI show results except selected. NB! You should manually check values in backend.
				),
				'save_always'	 => true,
				'description'	 => esc_html__( 'Enter List of Products', 'js_composer' ),
			),
			array(
				'type'		 => 'hidden',
				'param_name' => 'skus',
			),
			array(
				'type'			 => 'dropdown',
				'heading'		 => esc_html__( 'Order by', 'js_composer' ),
				'param_name'	 => 'orderby',
				'value'			 => array(
					'',
					esc_html__( 'Date', 'js_composer' )			 => 'date',
					esc_html__( 'ID', 'js_composer' )			 => 'ID',
					esc_html__( 'Author', 'js_composer' )		 => 'author',
					esc_html__( 'Title', 'js_composer' )		 => 'title',
					esc_html__( 'Modified', 'js_composer' )		 => 'modified',
					esc_html__( 'Random', 'js_composer' )		 => 'rand',
					esc_html__( 'Comment count', 'js_composer' ) => 'comment_count',
					esc_html__( 'Menu order', 'js_composer' )	 => 'menu_order',
				),
				'description'	 => sprintf( __( 'Select how to sort retrieved products. More at %s.', 'js_composer' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' ),
			),
			array(
				'type'			 => 'dropdown',
				'heading'		 => esc_html__( 'Sort order', 'js_composer' ),
				'param_name'	 => 'order',
				'value'			 => array(
					'',
					esc_html__( 'Descending', 'js_composer' )	 => 'DESC',
					esc_html__( 'Ascending', 'js_composer' )	 => 'ASC',
				),
				'description'	 => sprintf( __( 'Designates the ascending or descending order. More at %s.', 'js_composer' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' ),
			),
			array(
				'type'				 => 'dropdown',
				'heading'			 => __( 'Columns <span>Desktop</span>', '5th-avenue' ),
				'save_always'		 => true,
				'param_name'		 => 'column_desktop',
				'group'				 => esc_html__( 'Carousel Options', '5th-avenue' ),
				'value'				 => array(
					1	 => 1,
					2	 => 2,
					3	 => 3,
					4	 => 4,
					5	 => 5,
					6	 => 6,
					7	 => 7,
					8	 => 8,
				),
				'std'				 => 4,
				'edit_field_class'	 => 'col-md-2 vc_column',
			),
			array(
				'type'				 => 'dropdown',
				'heading'			 => __( '<span>Desktop Small</span>', '5th-avenue' ),
				'save_always'		 => true,
				'param_name'		 => 'column_desktop_small',
				'group'				 => esc_html__( 'Carousel Options', '5th-avenue' ),
				'value'				 => array(
					1	 => 1,
					2	 => 2,
					3	 => 3,
					4	 => 4,
					5	 => 5,
					6	 => 6,
					7	 => 7,
					8	 => 8,
				),
				'std'				 => 3,
				'edit_field_class'	 => 'col-md-2 vc_column',
			),
			array(
				'type'				 => 'dropdown',
				'heading'			 => __( '<span>Table</span>', '5th-avenue' ),
				'save_always'		 => true,
				'param_name'		 => 'column_table',
				'group'				 => esc_html__( 'Carousel Options', '5th-avenue' ),
				'value'				 => array(
					1	 => 1,
					2	 => 2,
					3	 => 3,
					4	 => 4,
					5	 => 5,
					6	 => 6,
					7	 => 7,
					8	 => 8,
				),
				'std'				 => 2,
				'edit_field_class'	 => 'col-md-2 vc_column',
			),
			array(
				'type'				 => 'dropdown',
				'heading'			 => __( '<span>Mobile</span>', '5th-avenue' ),
				'save_always'		 => true,
				'param_name'		 => 'column_mobile',
				'group'				 => esc_html__( 'Carousel Options', '5th-avenue' ),
				'value'				 => array(
					1	 => 1,
					2	 => 2,
					3	 => 3,
					4	 => 4,
					5	 => 5,
					6	 => 6,
					7	 => 7,
					8	 => 8,
				),
				'std'				 => 1,
				'edit_field_class'	 => 'col-md-2 vc_column',
			),
			array(
				'type'			 => 'dropdown',
				'heading'		 => esc_html__( 'Column Margin', '5th-avenue' ),
				'save_always'	 => true,
				'param_name'	 => 'column_margin',
				'group'			 => esc_html__( 'Carousel Options', '5th-avenue' ),
				'value'			 => array(
					'None'	 => 0,
					'5px'	 => 5,
					'10px'	 => 10,
					'15px'	 => 15,
					'20px'	 => 20,
					'30px'	 => 30,
					'40px'	 => 40,
					'50px'	 => 50,
				),
				'description'	 => esc_html__( 'Please select your desired column margin', '5th-avenue' ),
			),
			array(
				'type'			 => 'checkbox',
				'heading'		 => esc_html__( 'Autorotate?', '5th-avenue' ),
				'param_name'	 => 'autoplay',
				'group'			 => esc_html__( 'Carousel Options', '5th-avenue' ),
				'value'			 => array(
					esc_html__( 'Yes', '5th-avenue' ) => 'true',
				),
			),
			array(
				'type'			 => 'textfield',
				'heading'		 => esc_html__( 'Autorotation Speed', '5th-avenue' ),
				'param_name'	 => 'autoplay_timeout',
				'group'			 => esc_html__( 'Carousel Options', '5th-avenue' ),
				'dependency'	 => array(
					'element'	 => 'autoplay',
					'value'		 => array( 'true' ),
				),
				'description'	 => esc_html__( 'Enter in milliseconds (default is 5000)', '5th-avenue' ),
			),
			array(
				'type'		 => 'css_editor',
				'heading'	 => esc_html__( 'CSS box', 'js_composer' ),
				'param_name' => 'css',
				'group'		 => esc_html__( 'Design Options', 'js_composer' ),
			),
		);
		$valide_int_min					 = array(
			'filter'	 => FILTER_VALIDATE_INT,
			'options'	 => array(
				'default'	 => 1,
				'min_range'	 => 1,
			),
		);
		$this->validation				 = array(
			'ids'					 => FILTER_DEFAULT,
			'skus'					 => FILTER_DEFAULT,
			'orderby'				 => FILTER_DEFAULT,
			'order'					 => FILTER_DEFAULT,
			'column_desktop'		 => $valide_int_min,
			'column_desktop_small'	 => $valide_int_min,
			'column_table'			 => $valide_int_min,
			'column_mobile'			 => $valide_int_min,
			'column_margin'			 => array(
				'filter'	 => FILTER_VALIDATE_INT,
				'options'	 => array(
					'default'	 => 0,
					'min_range'	 => 0,
				),
			),
			'autoplay_timeout'		 => $valide_int_min,
			'autoplay'				 => FILTER_VALIDATE_BOOLEAN,
			'enable_animation'		 => FILTER_VALIDATE_BOOLEAN,
			'css'					 => FILTER_DEFAULT,
		);
		$this->default					 = array(
			'ids'					 => '',
			'skus'					 => '',
			'orderby'				 => 'rand', // @codingStandardsIgnoreLine WordPress.VIP.OrderByRand.orderby
			'order'					 => 'desc',
			'column_desktop'		 => 4,
			'column_desktop_small'	 => 3,
			'column_table'			 => 2,
			'column_mobile'			 => 1,
			'column_margin'			 => 0,
			'autoplay'				 => false,
			'autoplay_timeout'		 => 5000,
			'enable_animation'		 => false,
			'css'					 => '',
		);
		add_filter( 'vc_autocomplete_products_carousel_ids_callback', array( $this, 'productIdAutocompleteSuggester' ), 10, 1 ); // Get suggestion(find). Must return an array
		add_filter( 'vc_autocomplete_products_carousel_ids_render', array( $this, 'productIdAutocompleteRender' ), 10, 1 ); // Render exact product. Must return an array (label,value)
		add_filter( 'vc_form_fields_render_field_products_carousel_ids_param_value', array( $this, 'productsIdsDefaultValue' ), 10, 4 ); // Defines default value for param if not provided. Takes from other param value.
		parent::__construct();
	}

	/**
	 * Suggester for autocomplete by id/name/title/sku
	 *
	 * @todo auerserg Add description
	 * @since 4.4
	 * @see \Vc_Vendor_Woocommerce
	 *
	 * @param  int $query Product ID.
	 *
	 * @return array - id's from products with title/sku.
	 */
	public function productIdAutocompleteSuggester( $query ) {
		global $wpdb;
		$product_id		 = (int) $query;
		$post_meta_infos = $wpdb->get_results( $wpdb->prepare( "SELECT a.ID AS id, a.post_title AS title, b.meta_value AS sku FROM {$wpdb->posts} AS a LEFT JOIN ( SELECT meta_value, post_id  FROM {$wpdb->postmeta} WHERE `meta_key` = '_sku' ) AS b ON b.post_id = a.ID WHERE a.post_type = 'product' AND ( a.ID = '%d' OR b.meta_value LIKE '%%%s%%' OR a.post_title LIKE '%%%s%%' )", $product_id > 0 ? $product_id : - 1, stripslashes( $query ), stripslashes( $query ) ), ARRAY_A ); // @codingStandardsIgnoreLine WordPress.VIP.DirectDatabaseQuery.NoCaching

		$results = array();
		if ( is_array( $post_meta_infos ) && ! empty( $post_meta_infos ) ) {
			foreach ( $post_meta_infos as $value ) {
				$data			 = array();
				$data['value'] = $value['id'];
				$data['label'] = esc_html__( 'Id', 'js_composer' ) . ': ' . $value['id'] . ( ( strlen( $value['title'] ) > 0 ) ? ' - ' . esc_html__( 'Title', 'js_composer' ) . ': ' . $value['title'] : '' ) . ( ( strlen( $value['sku'] ) > 0 ) ? ' - ' . esc_html__( 'Sku', 'js_composer' ) . ': ' . $value['sku'] : '' );
				$results[]		 = $data;
			}
		}

		return $results;
	}

	/**
	 * Find product by id
	 *
	 * @todo auerserg Add description
	 * @since 4.4
	 * @see \Vc_Vendor_Woocommerce
	 *
	 * @param  int $query Product ID.
	 *
	 * @return bool|array
	 */
	public function productIdAutocompleteRender( $query ) {
		$query = trim( $query['value'] ); // Get value from requested.
		if ( ! empty( $query ) ) {
			$product_object = wc_get_product( (int) $query );
			if ( is_object( $product_object ) ) {
				$product_sku	 = $product_object->get_sku();
				$product_title	 = $product_object->get_title();
				$product_id		 = $product_object->get_id();

				$product_sku_display = '';
				if ( ! empty( $product_sku ) ) {
					$product_sku_display = ' - ' . esc_html__( 'Sku', 'js_composer' ) . ': ' . $product_sku;
				}

				$product_title_display = '';
				if ( ! empty( $product_title ) ) {
					$product_title_display = ' - ' . esc_html__( 'Title', 'js_composer' ) . ': ' . $product_title;
				}

				$product_id_display = esc_html__( 'Id', 'js_composer' ) . ': ' . $product_id;

				$data			 = array();
				$data['value'] = $product_id;
				$data['label'] = $product_id_display . $product_title_display . $product_sku_display;

				return ! empty( $data ) ? $data : false;
			}

			return false;
		}

		return false;
	}

	/**
	 * Replaces product skus to id's.
	 *
	 * @todo auerserg Add description
	 * @since 4.4
	 * @see \Vc_Vendor_Woocommerce
	 *
	 * @param string $current_value Value.
	 * @param array  $param_settings Param Settings.
	 * @param array  $map_settings Map Settings.
	 * @param array  $atts	Attributes for Settings.
	 *
	 * @return string
	 */
	public function productsIdsDefaultValue( $current_value, $param_settings, $map_settings, $atts ) {
		$value = trim( $current_value );
		if ( strlen( trim( $value ) ) === 0 && isset( $atts['skus'] ) && strlen( $atts['skus'] ) > 0 ) {
			$data		 = array();
			$skus		 = $atts['skus'];
			$skus_array	 = explode( ',', $skus );
			foreach ( $skus_array as $sku ) {
				$id = $this->productIdDefaultValueFromSkuToId( trim( $sku ) );
				if ( is_numeric( $id ) ) {
					$data[] = $id;
				}
			}
			if ( ! empty( $data ) ) {
				$values	 = explode( ',', $value );
				$values	 = array_merge( $values, $data );
				$value	 = implode( ',', $values );
			}
		}

		return $value;
	}

	/**
	 * Prepare attributes for shortcode
	 *
	 * @param array $atts Attributes for shorcode.
	 * @return array
	 */
	function prepare_atts( $atts = array() ) {
		if ( ! class_exists( 'WC_Shortcodes' ) ) {
			return false;
		}
		$atts['options'] = array(
			'data-column-desktop'		 => $atts['column_desktop'],
			'data-column-desktop-small'	 => $atts['column_desktop_small'],
			'data-column-table'			 => $atts['column_table'],
			'data-column-mobile'		 => $atts['column_mobile'],
			'data-margin'				 => $atts['column_margin'],
		);
		if ( $atts['autoplay'] ) {
			$atts['options']['data-autoplay']			 = true;
			$atts['options']['data-autoplay-timeout']	 = $atts['autoplay_timeout'];
		}
		foreach ( $atts['options'] as $key => $value ) {
			$atts['options'][ $key ] = sprintf( '%s="%s"', $key, esc_attr( $value ) );
		}
		$atts['options'] = implode( ' ', $atts['options'] );

		$atts['animation'] = $atts['enable_animation'] ? ' owl-carousel-animated' : '';

		$atts['content'] = WC_Shortcodes::products( array(
			'ids'		 => $atts['ids'],
			'skus'		 => $atts['skus'],
			'orderby'	 => $atts['orderby'],
			'order'		 => $atts['order'],
		) );

		return $atts;
	}

}
