<?php
/**
 * Shortcode "Video Lightbox"
 *
 * @package           5th-Avenue\Shortcode
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

/**
 * Shortcode "Video Lightbox"
 */
class AV5_Shortcode_Video_Lightbox extends AV5_Shortcode {

	/**
	 * This class
	 *
	 * @var \AV5_Shortcode_Video_Lightbox
	 */
	protected static $_instance = null;

	/**
	 * Get this class object
	 *
	 * @return \AV5_Shortcode_Video_Lightbox
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->name			 = esc_html__( 'AV5 Video Lightbox', '5th-avenue' );
		$this->base			 = 'av5_video_lightbox';
		$this->html_template = 'video-lightbox.php';
		$this->icon			 = 'av5_vc_video-icon';
		$this->params		 = array(
			array(
				'type'		 => 'dropdown',
				'heading'	 => esc_html__( 'Button Style', '5th-avenue' ),
				'param_name' => 'btn_style',
				'value'		 => array(
					esc_html__( 'Empty Circle', '5th-avenue' )						 => 'circle',
					esc_html__( 'Empty Circle with Pulse Animation', '5th-avenue' ) => 'circle_pulse',
					esc_html__( 'Filled', '5th-avenue' )							 => 'filled',
				),
				'std'		 => 'circle_pulse',
			),
			array(
				'type'		 => 'textfield',
				'heading'	 => esc_html__( 'Video URL', '5th-avenue' ),
				'param_name' => 'video_url',
			),
			array(
				'type'		 => 'colorpicker',
				'heading'	 => esc_html__( 'Icon Color', '5th-avenue' ),
				'param_name' => 'icon_color',
			),
			array(
				'type'			 => 'attach_image',
				'heading'		 => esc_html__( 'Image', '5th-avenue' ),
				'param_name'	 => 'image',
				'value'			 => '',
				'description'	 => esc_html__( 'Select image from media library.', '5th-avenue' ),
				'dependency'	 => array(
					'element'	 => 'source',
					'value'		 => 'media_library',
				),
				'admin_label'	 => true,
			),
			array(
				'type'		 => 'dropdown',
				'heading'	 => esc_html__( 'Image hover style', '5th-avenue' ),
				'param_name' => 'img_anim_style',
				'value'		 => array(
					esc_html__( 'No animation', '5th-avenue' )	 => 'none',
					esc_html__( 'Zoom on hover', '5th-avenue' ) => 'zoom_hover',
				),
				'std'		 => 'zoom_hover',
			),
			array(
				'type'		 => 'colorpicker',
				'heading'	 => esc_html__( 'Image overlay Color', '5th-avenue' ),
				'param_name' => 'overlay_color',
			),
			array(
				'type'		 => 'colorpicker',
				'heading'	 => esc_html__( 'Image hover overlay Color', '5th-avenue' ),
				'param_name' => 'overlay__hover_color',
			),
		);
		$this->validation	 = array();
		parent::__construct();
	}

}
