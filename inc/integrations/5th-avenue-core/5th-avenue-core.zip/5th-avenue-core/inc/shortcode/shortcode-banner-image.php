<?php
/**
 * Shortcode "Banner Image"
 *
 * @package           5th-Avenue\Shortcode
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;


/**
 * Shortcode "Banner Image"
 */
class AV5_Shortcode_Banner_Image extends AV5_Shortcode {

	/**
	 * This class
	 *
	 * @var \AV5_Shortcode_Banner_Image
	 */
	protected static $_instance = null;

	/**
	 * Get this class object
	 *
	 * @return \AV5_Shortcode_Banner_Image
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->name			 = esc_html__( 'AV5 Banner', '5th-avenue' );
		$this->base			 = 'av5_banner_image';
		$this->html_template = 'banner-image.php';
		$this->icon			 = 'av5_vc_banner-icon';
		$this->params		 = array(
			array(
				'type'			 => 'dropdown',
				'heading'		 => esc_html__( 'Style', '5th-avenue' ),
				'description'	 => esc_html__( 'Select banner style.', '5th-avenue' ),
				'param_name'	 => 'style',
				'value'			 => array(
					esc_html__( 'Left top, button bottom', '5th-avenue' )	 => 'style1',
					esc_html__( 'All Centered', '5th-avenue' )				 => 'style2',
					esc_html__( 'Centered, bottom', '5th-avenue' )			 => 'style3',
				),
				'std'			 => 'style1',
			),
			array(
				'type'			 => 'dropdown',
				'heading'		 => esc_html__( 'Image source', '5th-avenue' ),
				'param_name'	 => 'source',
				'value'			 => array(
					esc_html__( 'Media library', '5th-avenue' ) => 'media_library',
					esc_html__( 'External link', '5th-avenue' ) => 'external_link',
				),
				'std'			 => 'media_library',
				'description'	 => esc_html__( 'Select image source.', '5th-avenue' ),
			),
			array(
				'type'			 => 'attach_image',
				'heading'		 => esc_html__( 'Image', '5th-avenue' ),
				'param_name'	 => 'image',
				'value'			 => '',
				'description'	 => esc_html__( 'Select image from media library.', '5th-avenue' ),
				'dependency'	 => array(
					'element'	 => 'source',
					'value'		 => 'media_library',
				),
				'admin_label'	 => true,
			),
			array(
				'type'			 => 'textfield',
				'heading'		 => esc_html__( 'External link', '5th-avenue' ),
				'param_name'	 => 'custom_src',
				'description'	 => esc_html__( 'Select external link.', '5th-avenue' ),
				'dependency'	 => array(
					'element'	 => 'source',
					'value'		 => 'external_link',
				),
				'admin_label'	 => true,
			),
			array(
				'type'		 => 'textfield',
				'heading'	 => esc_html__( 'Banner minimal height', '5th-avenue' ),
				'param_name' => 'min_height',
				'value'		 => '450px',
				'std'		 => '450px',
			),
			array(
				'type'		 => 'textfield',
				'heading'	 => esc_html__( 'Subtitle', '5th-avenue' ),
				'param_name' => 'subtitle',
				'value'		 => '',
				'std'		 => '',
			),
			array(
				'type'		 => 'textfield',
				'heading'	 => esc_html__( 'Title', '5th-avenue' ),
				'param_name' => 'title',
				'value'		 => esc_html__( 'Text on the button', '5th-avenue' ),
				'std'		 => esc_html__( 'Text on the button', '5th-avenue' ),
			),
			array(
				'type'		 => 'textfield',
				'heading'	 => esc_html__( 'Title font size', '5th-avenue' ),
				'param_name' => 'title_size',
				'value'		 => '',
				'std'		 => '',
			),
			array(
				'type'		 => 'textarea_html',
				'heading'	 => esc_html__( 'Banner content', '5th-avenue' ),
				'param_name' => 'content',
				'value'		 => '',
			),
			array(
				'type'		 => 'textfield',
				'heading'	 => esc_html__( 'Button Text', '5th-avenue' ),
				'param_name' => 'button_text',
				'value'		 => esc_html__( 'Text on the button', '5th-avenue' ),
				'std'		 => esc_html__( 'Text on the button', '5th-avenue' ),
			),
			array(
				'type'			 => 'vc_link',
				'heading'		 => esc_html__( 'Banner URL (Link)', '5th-avenue' ),
				'param_name'	 => 'link',
				'description'	 => esc_html__( 'Add custom link.', '5th-avenue' ),
			),
			array(
				'type'		 => 'checkbox',
				'heading'	 => esc_html__( 'Enable background overlay', '5th-avenue' ),
				'param_name' => 'bg_overlay',
			),
			array(
				'type'			 => 'colorpicker',
				'heading'		 => esc_html__( 'Background', '5th-avenue' ),
				'param_name'	 => 'bg_overlay_color',
				'description'	 => esc_html__( 'Set image overlay color.', '5th-avenue' ),
				'dependency'	 => array(
					'element'	 => 'bg_overlay',
					'value'		 => 'true',
				),
				'std'			 => '#000000',
			),
			array(
				'type'			 => 'textfield',
				'heading'		 => esc_html__( 'Background Overlay Opacity', '5th-avenue' ),
				'description'	 => esc_html__( 'Set opacity for background overlay from 0 to 100', '5th-avenue' ),
				'param_name'	 => 'bg_overlay_opacity',
				'dependency'	 => array(
					'element'	 => 'bg_overlay',
					'value'		 => 'true',
				),
				'value'			 => 50,
				'std'			 => 50,
			),
			array(
				'type'			 => 'dropdown',
				'heading'		 => esc_html__( 'Colors', '5th-avenue' ),
				'description'	 => esc_html__( 'Choose colors for all elements', '5th-avenue' ),
				'param_name'	 => 'colorset',
				'value'			 => array(
					esc_html__( 'Default', '5th-avenue' )	 => '',
					esc_html__( 'White', '5th-avenue' )	 => 'white',
					esc_html__( 'Custom', '5th-avenue' )	 => 'custom',
				),
				'std'			 => '',
			),
			array(
				'type'				 => 'colorpicker',
				'heading'			 => esc_html__( 'Title Color', '5th-avenue' ),
				'param_name'		 => 'title_color',
				'description'		 => esc_html__( 'Select custom title color', '5th-avenue' ),
				'dependency'		 => array(
					'element'	 => 'colorset',
					'value'		 => 'custom',
				),
				'edit_field_class'	 => 'vc_col-sm-6',
			),
			array(
				'type'				 => 'colorpicker',
				'heading'			 => esc_html__( 'Background', '5th-avenue' ),
				'param_name'		 => 'background_color',
				'description'		 => esc_html__( 'Select custom banner background', '5th-avenue' ),
				'dependency'		 => array(
					'element'	 => 'colorset',
					'value'		 => 'custom',
				),
				'edit_field_class'	 => 'vc_col-sm-6',
				'std'				 => '#f4f4f4',
			),
			array(
				'type'				 => 'colorpicker',
				'heading'			 => esc_html__( 'Button Background', '5th-avenue' ),
				'param_name'		 => 'button_background',
				'description'		 => esc_html__( 'Select custom color for button background or border.', '5th-avenue' ),
				'dependency'		 => array(
					'element'	 => 'colorset',
					'value'		 => 'custom',
				),
				'edit_field_class'	 => 'vc_col-sm-6',
			),
			array(
				'type'				 => 'colorpicker',
				'heading'			 => esc_html__( 'Button Text', '5th-avenue' ),
				'param_name'		 => 'button_text_color',
				'description'		 => esc_html__( 'Select custom color for button text.', '5th-avenue' ),
				'dependency'		 => array(
					'element'	 => 'colorset',
					'value'		 => 'custom',
				),
				'edit_field_class'	 => 'vc_col-sm-6',
			),
			array(
				'type'				 => 'colorpicker',
				'heading'			 => esc_html__( 'Hover border color', '5th-avenue' ),
				'param_name'		 => 'hover_border_color',
				'description'		 => esc_html__( 'Border color for banner with border hover effect', '5th-avenue' ),
				'dependency'		 => array(
					'element'	 => 'colorset',
					'value'		 => 'custom',
				),
				'edit_field_class'	 => 'vc_col-sm-6',
			),
			array(
				'type'			 => 'dropdown',
				'heading'		 => esc_html__( 'Button Style', '5th-avenue' ),
				'description'	 => esc_html__( 'Select banner button style.', '5th-avenue' ),
				'param_name'	 => 'button_style',
				'value'			 => array(
					esc_html__( 'Single underline', '5th-avenue' )		 => 'single-underline',
					esc_html__( 'Single underline big', '5th-avenue' )	 => 'single-underline big',
					esc_html__( 'Double Underline', '5th-avenue' )		 => 'underlined',
				),
				'std'			 => 'underlined',
			),
			array(
				'type'		 => 'dropdown',
				'heading'	 => esc_html__( 'Banner Hover Effect', '5th-avenue' ),
				'param_name' => 'hover_effect',
				'value'		 => array(
					esc_html__( 'None', '5th-avenue' )					 => '',
					esc_html__( 'Zoom Background Image', '5th-avenue' ) => 'zoom',
					esc_html__( 'Overlay', '5th-avenue' )				 => 'overlay',
					esc_html__( 'Zoom with Overlay', '5th-avenue' )	 => 'zoom_overlay',
					esc_html__( 'Move Background', '5th-avenue' )		 => 'move',
					esc_html__( 'Border on hover', '5th-avenue' )		 => 'border',
				),
				'std'		 => '',
			),
			array(
				'type'		 => 'css_editor',
				'heading'	 => esc_html__( 'CSS box', 'js_composer' ),
				'param_name' => 'css',
				'group'		 => esc_html__( 'Design Options', 'js_composer' ),
			),
		);
		if ( function_exists( 'vc_map_add_css_animation' ) ) {
			$this->params[] = vc_map_add_css_animation( true );
		}
		$this->default = array(
			'css_animation' => '',
		);

		$this->validation = array();
		parent::__construct();
	}
}
