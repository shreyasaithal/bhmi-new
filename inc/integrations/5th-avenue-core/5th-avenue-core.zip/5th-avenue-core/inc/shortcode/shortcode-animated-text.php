<?php
/**
 * Shortcode "Animated Text"
 *
 * @package           5th-Avenue\Shortcode
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

/**
 * Shortcode "Animated Text"
 */
class AV5_Shortcode_Animated_Text extends AV5_Shortcode {

	/**
	 * This class
	 *
	 * @var \AV5_Shortcode_Animated_Text
	 */
	protected static $_instance = null;

	/**
	 * Get this class object
	 *
	 * @return \AV5_Shortcode_Animated_Text
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->name			 = esc_html__( 'AV5 Animated Text', '5th-avenue' );
		$this->base			 = 'av5_animated_text';
		$this->html_template = 'animated-text.php';
		$this->icon			 = 'av5_vc_animated-text-icon';
		$this->params		 = array(
			array(
				'type'		 => 'dropdown',
				'heading'	 => esc_html__( 'Animation Style', '5th-avenue' ),
				'param_name' => 'animation_style',
				'value'		 => array(
					esc_html__( 'Symbol Fade', '5th-avenue' )		 => 'fadeIn',
					esc_html__( 'Masked Background', '5th-avenue' )		 => 'masked',
				),
				'std'		 => 'fadeIn',
			),
			array(
				'type'			 => 'textfield',
				'heading'		 => esc_html__( 'Content', '5th-avenue' ),
				'description'	 => esc_html__( 'Add your text here', '5th-avenue' ),
				'param_name'	 => 'content',
				'value'			 => '',
			),
			array(
				'type'		 => 'colorpicker',
				'heading'	 => esc_html__( 'Text Color', '5th-avenue' ),
				'param_name' => 'text_color',
			),
			array(
				'type'		 => 'colorpicker',
				'heading'	 => esc_html__( 'Background Color', '5th-avenue' ),
				'param_name' => 'bg_color',
				'dependency'	 => array(
					'element'	 => 'animation_style',
					'value'		 => 'masked',
				),
			),
			array(
				'type'		 => 'dropdown',
				'heading'	 => esc_html__( 'Font Size', '5th-avenue' ),
				'param_name' => 'font_h',
				'value'		 => array(
					esc_html__( 'P', '5th-avenue' )		 => 'p',
					esc_html__( 'H1', '5th-avenue' )		 => 'h1',
					esc_html__( 'H2', '5th-avenue' )		 => 'h2',
					esc_html__( 'H3', '5th-avenue' )		 => 'h3',
					esc_html__( 'H4', '5th-avenue' )		 => 'h4',
					esc_html__( 'H5', '5th-avenue' )		 => 'h5',
					esc_html__( 'H6', '5th-avenue' )		 => 'h6',
					esc_html__( 'Custom', '5th-avenue' )	 => 'custom',
				),
				'std'		 => 'h1',
			),
			array(
				'type'			 => 'textfield',
				'heading'		 => esc_html__( 'Font Size', '5th-avenue' ),
				'param_name'	 => 'font_size',
				'dependency'	 => array(
					'element'	 => 'font_h',
					'value'		 => 'custom',
				),
				'admin_label'	 => true,
			),
			array(
				'type'			 => 'textfield',
				'heading'		 => esc_html__( 'Line Height', '5th-avenue' ),
				'param_name'	 => 'line_height',
				'dependency'	 => array(
					'element'	 => 'font_h',
					'value'		 => 'custom',
				),
				'admin_label'	 => true,
			),
			array(
				'type'			 => 'textfield',
				'heading'		 => esc_html__( 'Letter Spacing', '5th-avenue' ),
				'param_name'	 => 'letter_spacing',
				'dependency'	 => array(
					'element'	 => 'font_h',
					'value'		 => 'custom',
				),
				'admin_label'	 => true,
			),
			array(
				'type'		 => 'textfield',
				'heading'	 => esc_html__( 'Animation Delay', '5th-avenue' ),
				'param_name' => 'delay',
			),
			array(
				'type'		 => 'textfield',
				'heading'	 => esc_html__( 'Extra class', '5th-avenue' ),
				'param_name' => 'extra_class',
			),
			array(
				'type'		 => 'checkbox',
				'heading'	 => esc_html__( 'Center text', '5th-avenue' ),
				'param_name' => 'align_center',
			),
			array(
				'type'		 => 'css_editor',
				'heading'	 => esc_html__( 'CSS box', 'js_composer' ),
				'param_name' => 'css',
				'group'		 => esc_html__( 'Design Options', 'js_composer' ),
			),
		);
		$this->validation	 = array();
		parent::__construct();
	}

}
