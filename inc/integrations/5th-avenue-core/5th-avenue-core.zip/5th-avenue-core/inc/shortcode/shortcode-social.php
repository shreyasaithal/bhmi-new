<?php
/**
 * Shortcode "Banner"
 *
 * @package           5th-Avenue\Shortcode
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

/**
 * Shortcode "Banner"
 */
class AV5_Shortcode_Social extends AV5_Shortcode {

	/**
	 * This class
	 *
	 * @var \AV5_Shortcode_Banner
	 */
	protected static $_instance = null;

	/**
	 * Get this class object
	 *
	 * @return \AV5_Shortcode_Banner
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->name			 = esc_html__( 'AV5 Social', '5th-avenue' );
		$this->base			 = 'av5_social';
		$this->html_template = 'social.php';
		$this->icon			 = 'av5_vc_social-icon';
		$this->params		 = array(
			array(
				'heading'		 => esc_html__( 'Social Icons', '5th-avenue' ),
				'param_name'	 => 'info',
				'type'			 => 'empty',
				'description'	 => esc_html__( 'Set url to your social accounts in Theme Options -> Social Options', '5th-avenue' ),
			),
			array(
				'type'		 => 'colorpicker',
				'heading'	 => esc_html__( 'Social Icons Color', '5th-avenue' ),
				'param_name' => 'color',
			),
			array(
				'type'		 => 'colorpicker',
				'heading'	 => esc_html__( 'Social Icons Hover Color', '5th-avenue' ),
				'param_name' => 'color_hover',
			),
			array(
				'type'			 => 'dropdown',
				'heading'		 => esc_html__( 'Alignment', '5th-avenue' ),
				'param_name'	 => 'align',
				'description'	 => esc_html__( 'Select icons alignment.', '5th-avenue' ),
				'value'			 => array(
					esc_html__( 'Inline', '5th-avenue' )	 => 'inline',
					esc_html__( 'Center', '5th-avenue' )	 => 'center',
				),
				'std'			 => 'inline',
			),
			array(
				'type'			 => 'checkbox',
				'heading'		 => esc_html__( 'Instagram', '5th-avenue' ),
				'param_name'	 => 'instagram',
				'value'			 => 'true',
				'save_always'	 => true,
				'std'			 => true,
			),
			array(
				'type'			 => 'checkbox',
				'heading'		 => esc_html__( 'Facebook', '5th-avenue' ),
				'param_name'	 => 'facebook',
				'value'			 => 'true',
				'save_always'	 => true,
				'std'			 => true,
			),
			array(
				'type'			 => 'checkbox',
				'heading'		 => esc_html__( 'Twitter', '5th-avenue' ),
				'param_name'	 => 'twitter',
				'value'			 => 'true',
				'save_always'	 => true,
				'std'			 => true,
			),
			array(
				'type'			 => 'checkbox',
				'heading'		 => esc_html__( 'Google', '5th-avenue' ),
				'param_name'	 => 'google',
				'value'			 => 'true',
				'save_always'	 => true,
				'std'			 => true,
			),
			array(
				'type'			 => 'checkbox',
				'heading'		 => esc_html__( 'Pinterest', '5th-avenue' ),
				'param_name'	 => 'pinterest',
				'value'			 => 'true',
				'save_always'	 => true,
				'std'			 => true,
			),
			array(
				'type'			 => 'checkbox',
				'heading'		 => esc_html__( 'Vimeo', '5th-avenue' ),
				'param_name'	 => 'vimeo',
				'value'			 => 'true',
				'save_always'	 => true,
				'std'			 => true,
			),
			array(
				'type'			 => 'checkbox',
				'heading'		 => esc_html__( 'Youtube', '5th-avenue' ),
				'param_name'	 => 'youtube',
				'value'			 => 'true',
				'save_always'	 => true,
				'std'			 => true,
			),
			array(
				'type'			 => 'checkbox',
				'heading'		 => esc_html__( 'Vk', '5th-avenue' ),
				'param_name'	 => 'vk',
				'value'			 => 'true',
				'save_always'	 => true,
				'std'			 => true,
			),
			array(
				'type'		 => 'css_editor',
				'heading'	 => esc_html__( 'CSS box', 'js_composer' ),
				'param_name' => 'css',
				'group'		 => esc_html__( 'Design Options', 'js_composer' ),
			),
		);

		$this->validation = array();
		parent::__construct();
	}

}
