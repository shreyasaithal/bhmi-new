<?php
/**
 * Shortcode 'Hotspot'
 *
 * @package           5th-Avenue\Shortcode
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'init_hotspot_class' ) ) {

	/**
	 * Add new backend class for hotspot item
	 */
	function init_hotspot_class() {
		VcShortcodeAutoloader::getInstance()->includeClass( 'WPBakeryShortCode_VC_Tta_Section' );
		/**
		 * Extend class for hot spots
		 */
		class WPBakeryShortCode_hotspot extends WPBakeryShortCode_VC_Tta_Section { // @codingStandardsIgnoreLine PEAR.NamingConventions.ValidClassName.Invalid
		};
	}

	add_action( 'vc_before_init', 'init_hotspot_class' );
}

/**
 * Shortcode 'Hotspot'
 */
class AV5_Shortcode_Hotspot extends AV5_Shortcode {

	/**
	 * This class
	 *
	 * @var \AV5_Shortcode_Hotspot
	 */
	protected static $_instance = null;

	/**
	 * Get this class object
	 *
	 * @return \AV5_Shortcode_Hotspot
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->name						 = esc_html__( 'Hotspot Item', '5th-avenue' );
		$this->base						 = 'hotspot';
		$this->html_template			 = 'hotspot.php';
		$this->allowed_container_element = 'vc_row';
		$this->icon						 = 'av5_vc_parallax-icon';
		$this->show_settings_on_create	 = true;
		$this->is_container				 = true;
		$this->as_child					 = array(
			'only' => 'block_hotspot',
		);
		$this->params					 = array(
			array(
				'type'			 => 'textfield',
				'param_name'	 => 'title',
				'heading'		 => esc_html__( 'Title', 'js_composer' ),
				'description'	 => esc_html__( 'Enter section title (Note: you can leave it empty).', 'js_composer' ),
			),
			array(
				'type'			 => 'el_id',
				'param_name'	 => 'tab_id',
				'settings'		 => array(
					'auto_generate' => true,
				),
				'heading'		 => esc_html__( 'Section ID', 'js_composer' ),
				'description'	 => __( 'Enter section ID (Note: make sure it is unique and valid according to <a href="%s" target="_blank">w3c specification</a>).', 'js_composer' ),
			),
			array(
				'type'			 => 'textfield',
				'heading'		 => esc_html__( 'Width', '5th-avenue' ),
				'param_name'	 => 'width',
				'description'	 => esc_html__( 'Set width for this block in any units (i.e.: 300px, 25%)', '5th-avenue' ),
			),
			array(
				'type'			 => 'hotspot_point',
				'heading'		 => esc_html__( 'Position', '5th-avenue' ),
				'param_name'	 => 'position',
				'max_points'	 => 1,
			),
			array(
				'type'			 => 'dropdown',
				'heading'		 => esc_html__( 'Fixed Position', '5th-avenue' ),
				'param_name'	 => 'fixed',
				'value'			 => array(
					esc_html__( 'Not Fixed', '5th-avenue' ) => '',
					esc_html__( 'Fixed', '5th-avenue' )	 => 'true',
				),
			),
			array(
				'type'			 => 'checkbox',
				'heading'		 => esc_html__( 'Start moving only when the block shows up', '5th-avenue' ),
				'param_name'	 => 'afterdisplayed',
				'value'			 => array(
					esc_html__( 'Yes', '5th-avenue' ) => 'true',
				),
				'dependency'	 => array(
					'element'	 => 'fixed',
					'value'		 => array( '' ),
				),
			),
			array(
				'type'			 => 'dropdown',
				'heading'		 => esc_html__( 'Motion animation', '5th-avenue' ),
				'param_name'	 => 'easing',
				'value'			 => array(
					''					 => '',
					'swing'				 => 'swing',
					'easeInQuad'		 => 'easeInQuad',
					'easeOutQuad'		 => 'easeOutQuad',
					'easeInOutQuad'		 => 'easeInOutQuad',
					'easeInCubic'		 => 'easeInCubic',
					'easeOutCubic'		 => 'easeOutCubic',
					'easeInOutCubic'	 => 'easeInOutCubic',
					'easeInQuart'		 => 'easeInQuart',
					'easeOutQuart'		 => 'easeOutQuart',
					'easeInOutQuart'	 => 'easeInOutQuart',
					'easeInQuint'		 => 'easeInQuint',
					'easeOutQuint'		 => 'easeOutQuint',
					'easeInOutQuint'	 => 'easeInOutQuint',
					'easeInSine'		 => 'easeInSine',
					'easeOutSine'		 => 'easeOutSine',
					'easeInOutSine'		 => 'easeInOutSine',
					'easeInExpo'		 => 'easeInExpo',
					'easeOutExpo'		 => 'easeOutExpo',
					'easeInOutExpo'		 => 'easeInOutExpo',
					'easeInCirc'		 => 'easeInCirc',
					'easeOutCirc'		 => 'easeOutCirc',
					'easeInOutCirc'		 => 'easeInOutCirc',
					'easeInElastic'		 => 'easeInElastic',
					'easeOutElastic'	 => 'easeOutElastic',
					'easeInOutElastic'	 => 'easeInOutElastic',
					'easeInBack'		 => 'easeInBack',
					'easeOutBack'		 => 'easeOutBack',
					'easeInOutBack'		 => 'easeInOutBack',
					'easeInBounce'		 => 'easeInBounce',
					'easeOutBounce'		 => 'easeOutBounce',
					'easeInOutBounce'	 => 'easeInOutBounce',
				),
				'dependency'	 => array(
					'element'	 => 'fixed',
					'value'		 => array( '' ),
				),
			),
			array(
				'type'			 => 'hotspot_point',
				'heading'		 => esc_html__( 'Point of motion', '5th-avenue' ),
				'param_name'	 => 'point',
				'max_points'	 => 1,
				'dependency'	 => array(
					'element'	 => 'fixed',
					'value'		 => array( '' ),
				),
			),
			array(
				'type'			 => 'textfield',
				'heading'		 => esc_html__( 'Path', '5th-avenue' ),
				'param_name'	 => 'path',
				'value'			 => 100,
				'dependency'	 => array(
					'element'	 => 'fixed',
					'value'		 => array( '' ),
				),
			),
			array(
				'type'			 => 'checkbox',
				'heading'		 => esc_html__( 'Boxed Block', '5th-avenue' ),
				'param_name'	 => 'boxed_block',
				'value'			 => array(
					esc_html__( 'Yes', '5th-avenue' ) => 'true',
				),
			),
			array(
				'type'			 => 'checkbox',
				'heading'		 => esc_html__( 'Boxed Block Shadow', '5th-avenue' ),
				'param_name'	 => 'boxed_block_shadow',
				'value'			 => array(
					esc_html__( 'Yes', '5th-avenue' ) => 'true',
				),
				'dependency'	 => array(
					'element'	 => 'boxed_block',
					'value'		 => array( 'true' ),
				),
			),
			array(
				'type'		 => 'dropdown',
				'heading'	 => esc_html__( 'Responive Behavior', '5th-avenue' ),
				'param_name' => 'responsive',
				'value'		 => array(
					esc_html__( 'Always show', '5th-avenue' )				 => '',
					esc_html__( 'Hide on Mobile', '5th-avenue' )			 => 'hide-on-mobile',
					esc_html__( 'Hide on Mobile and Tablet', '5th-avenue' ) => 'hide-on-tablet hide-on-mobile',
				),
			),
		);
		$this->js_view					 = 'VcBackendTtaSectionView';
		$this->custom_markup			 = '
		<div class="vc_tta-panel-heading">
		    <h4 class="vc_tta-panel-title vc_tta-controls-icon-position-left"><a href="javascript:;" data-vc-target="[data-model-id=\'{{ model_id }}\']" data-vc-accordion data-vc-container=".vc_tta-container"><span class="vc_tta-title-text">{{ section_title }}</span><i class="vc_tta-controls-icon vc_tta-controls-icon-plus"></i></a></h4>
		</div>
		<div class="vc_tta-panel-body">
			{{ editor_controls }}
			<div class="{{ container-class }}">
			{{ content }}
			</div>
		</div>';
		$this->validation				 = array(
			'title'				 => FILTER_DEFAULT,
			'tab_id'			 => FILTER_DEFAULT,
			'position'			 => FILTER_DEFAULT,
			'responsive'		 => FILTER_DEFAULT,
			'width'				 => FILTER_DEFAULT,
			'fixed'				 => FILTER_VALIDATE_BOOLEAN,
			'boxed_block'		 => FILTER_VALIDATE_BOOLEAN,
			'boxed_block_shadow' => FILTER_VALIDATE_BOOLEAN,
			'afterdisplayed'	 => FILTER_VALIDATE_BOOLEAN,
			'point'				 => FILTER_DEFAULT,
			'path'				 => FILTER_VALIDATE_INT,
			'css'				 => FILTER_DEFAULT,
		);
		$this->default					 = array(
			'title'			 => '',
			'tab_id'		 => '',
			'position'		 => '',
			'fixed'			 => false,
			'afterdisplayed' => false,
			'point'			 => '',
			'path'			 => '',
			'css'			 => '',
			'width'			 => '',
		);
		parent::__construct();
	}

	/**
	 * Prepare attributes for shortcode
	 *
	 * @param array $atts Attributes for shorcode.
	 * @return array
	 */
	function prepare_atts( $atts = array() ) {
		$atts['class'] = '';
		if ( $atts['fixed'] ) {
			$atts['class'] .= ' hotspot-element-fixed';
		}
		if ( $atts['responsive'] ) {
			$atts['class'] .= ' ' . $atts['responsive'];
		}
		if ( $atts['boxed_block'] ) {
			$atts['class'] .= ' boxed-block';
		}
		if ( $atts['boxed_block_shadow'] ) {
			$atts['class'] .= ' boxed-block--with-shadow';
		}
		if ( $atts['afterdisplayed'] ) {
			$atts['class'] .= ' hotspot-element-after-displayed';
		}
		$atts['attr'] = '';
		if ( ! empty( $atts['width'] ) ) {
			$atts['attr'] .= sprintf( ' style="width:%s;"', $atts['width'] );
		}
		if ( ! $atts['fixed'] && ! empty( $atts['point'] ) ) {
			$atts['attr'] .= sprintf( ' data-point="%s"', esc_attr( $atts['point'] ) );
		}
		if ( ! $atts['fixed'] && ! empty( $atts['easing'] ) ) {
			$atts['attr'] .= sprintf( ' data-easing="%s"', esc_attr( $atts['easing'] ) );
		}
		if ( ! empty( $atts['position'] ) ) {
			$atts['attr'] .= sprintf( ' data-position="%s"', esc_attr( $atts['position'] ) );
		}
		if ( ! empty( $atts['path'] ) ) {
			$atts['attr'] .= sprintf( ' data-path="%s"', esc_attr( $atts['path'] ) );
		}
		return $atts;
	}

}
