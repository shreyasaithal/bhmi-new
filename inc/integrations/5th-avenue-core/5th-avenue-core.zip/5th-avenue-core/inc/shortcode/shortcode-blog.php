<?php
/**
 * Shortcode "Blog"
 *
 * @package           5th-Avenue\Shortcode
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

/**
 * Shortcode "Blog"
 */
class AV5_Shortcode_Blog extends AV5_Shortcode {

	/**
	 * This class
	 *
	 * @var \AV5_Shortcode_Blog
	 */
	protected static $_instance = null;

	/**
	 * Get this class object
	 *
	 * @return \AV5_Shortcode_Blog
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {

		$category_array	 = array(
			esc_html__( 'All', '5th-avenue' ) => '',
		);
		$cats			 = get_terms( array( 'taxonomy' => 'category' ) );
		foreach ( $cats as $cat ) {
			$category_array[ $cat->name ] = $cat->slug;
		}

		$this->name			 = esc_html__( 'AV5 Blog', '5th-avenue' );
		$this->icon			 = 'av5_vc_blog-icon';
		$this->base			 = 'blog';
		$this->html_template = 'blog.php';
		$this->params		 = array(
			array(
				'type'			 => 'multiselect',
				'heading'		 => esc_html__( 'Category of blog', '5th-avenue' ),
				'param_name'	 => 'category',
				'value'			 => $category_array,
				'admin_label'	 => true,
				'description'	 => esc_html__( 'Choose a category', '5th-avenue' ),
			),
			array(
				'type'			 => 'dropdown',
				'heading'		 => esc_html__( 'Blog layers', '5th-avenue' ),
				'param_name'	 => 'layout',
				'value'			 => apply_filters( 'av5_shortcode_blog_params_layout_' . $this->base, array(
					esc_html__( '3 Unequal', '5th-avenue' )		 => 'default',
					esc_html__( '3 Equal', '5th-avenue' )			 => 'equal',
					esc_html__( '2 Unequal Columns', '5th-avenue' ) => 'style-2',
				) ),
				'description'	 => esc_html__( 'Choose a category', '5th-avenue' ),
			),
			array(
				'type'			 => 'textfield',
				'heading'		 => esc_html__( 'Show per page', '5th-avenue' ),
				'param_name'	 => 'perpage',
				'value'			 => 1,
				'description'	 => esc_html__( 'Number to show', '5th-avenue' ),
			),
			array(
				'type'			 => 'checkbox',
				'heading'		 => esc_html__( 'Show description', '5th-avenue' ),
				'param_name'	 => 'show_desc',
				'value'			 => 'true',
				'save_always'	 => true,
				'description'	 => esc_html__( 'Show short description below title', '5th-avenue' ),
				'std'			 => true,
			),
			array(
				'type'		 => 'dropdown',
				'heading'	 => esc_html__( 'Descriptions Align', '5th-avenue' ),
				'param_name' => 'desc_align',
				'value'		 => apply_filters( 'av5_shortcode_blog_params_layout_' . $this->base, array(
					esc_html__( 'Left', '5th-avenue' )		 => 'left',
					esc_html__( 'Center', '5th-avenue' )	 => 'center',
				) ),
				'std'		 => 'left',
			),
			array(
				'type'		 => 'dropdown',
				'heading'	 => esc_html__( 'Read more style', '5th-avenue' ),
				'param_name' => 'readmore_style',
				'value'		 => apply_filters( 'av5_shortcode_blog_params_layout_' . $this->base, array(
					esc_html__( 'Underlined', '5th-avenue' )		 => 'underlined',
					esc_html__( 'Line on the left', '5th-avenue' )	 => 'line-left',
				) ),
				'std'		 => 'line-left',
			),
			array(
				'type'			 => 'dropdown',
				'heading'		 => esc_html__( 'Image Hover style', '5th-avenue' ),
				'param_name'	 => 'hover_style',
				'value'			 => apply_filters( 'av5_shortcode_blog_params_layout_' . $this->base, array(
					esc_html__( 'None', '5th-avenue' )			 => '',
					esc_html__( 'Move Up', '5th-avenue' )		 => 'move-up',
					esc_html__( 'Image Zoom', '5th-avenue' )	 => 'zoom-img',
					esc_html__( 'Zoom Masked', '5th-avenue' )	 => 'zoom-masked',
				) ),
				'save_always'	 => true,
				'std'			 => '',
			),
			array(
				'type'			 => 'checkbox',
				'heading'		 => esc_html__( 'Pagination', '5th-avenue' ),
				'param_name'	 => 'pagination',
				'value'			 => 'true',
				'save_always'	 => true,
				'description'	 => esc_html__( 'Check if you want show pagination', '5th-avenue' ),
			),
			array(
				'type'		 => 'css_editor',
				'heading'	 => esc_html__( 'CSS box', 'js_composer' ),
				'param_name' => 'css',
				'group'		 => esc_html__( 'Design Options', 'js_composer' ),
			),
		);
		$this->validation	 = array(
			'category'		 => FILTER_DEFAULT,
			'perpage'		 => array(
				'filter'	 => FILTER_VALIDATE_INT,
				'options'	 => array(
					'default'	 => 1,
					'min_range'	 => 1,
				),
			),
			'pagination'	 => FILTER_VALIDATE_BOOLEAN,
			'layout'		 => FILTER_DEFAULT,
			'desc_align'	 => FILTER_DEFAULT,
			'readmore_style' => FILTER_DEFAULT,
			'hover_style'	 => FILTER_DEFAULT,
			'show_desc'		 => FILTER_DEFAULT,
			'css'			 => FILTER_DEFAULT,
		);
		$this->default		 = array(
			'layout'	 => 'default',
			'category'	 => '',
			'css'		 => '',
			'perpage'	 => 1,
			'pagination' => true,
		);

		add_action( 'av5_shortcode_before_template_' . $this->base, array( $this, 'save_prefix' ) );
		add_action( 'av5_shortcode_after_template_' . $this->base, array( $this, 'reset_prefix' ) );
		add_action( 'av5_shortcode_after_template_' . $this->base, array( $this, 'reset_postdata' ) );

		parent::__construct();
	}

	/**
	 * Prepare attributes for shortcode
	 *
	 * @param array $atts Attributes for shorcode.
	 * @return array
	 */
	function prepare_atts( $atts = array() ) {
		if ( is_front_page() ) {
			$atts['current_page'] = get_query_var( 'page' ) ? get_query_var( 'page' ) : 1;
		} else {
			$atts['current_page'] = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;
		}

		$args = array(
			'posts_per_page'		 => $atts['perpage'],
			'post_status'			 => 'publish',
			'category_name'			 => $atts['category'],
			'post_type'				 => 'post',
			'paged'					 => $atts['current_page'],
			'ignore_sticky_posts'	 => true,
			'order'					 => 'DESC',
		);

		$atts['post_list'] = new WP_Query( apply_filters( 'av5_shortcode_blog_query_args', $args ) );

		if ( $atts['post_list'] && $atts['post_list']->have_posts() ) {
			return $atts;
		}

		return null;
	}

	/**
	 * Before looping, this function save prefix
	 */
	function save_prefix() {
		$this->prefix_current = get_query_var( 'av5_post_type', null );
		set_query_var( 'av5_post_type', 'posts' );
	}

	/**
	 * Before looping, this function save prefix
	 */
	function reset_prefix() {
		set_query_var( 'av5_post_type', $this->prefix_current );
	}

	/**
	 * After looping through a separate query, this function restores
	 * the $post global to the current post in the main query.
	 */
	function reset_postdata() {
		wp_reset_postdata();
	}

}
