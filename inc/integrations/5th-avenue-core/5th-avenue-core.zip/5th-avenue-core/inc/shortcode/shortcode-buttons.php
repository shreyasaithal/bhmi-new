<?php
/**
 * Shortcode "Buttons"
 *
 * @package           5th-Avenue\Shortcode
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

/**
 * Shortcode "Buttons"
 */
class AV5_Shortcode_Buttons extends AV5_Shortcode {

	/**
	 * This class
	 *
	 * @var \AV5_Shortcode_Buttons
	 */
	protected static $_instance = null;

	/**
	 * Get this class object
	 *
	 * @return \AV5_Shortcode_Buttons
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->name			 = esc_html__( 'AV5 Buttons', '5th-avenue' );
		$this->base			 = 'av5_buttons';
		$this->html_template = 'buttons.php';
		$this->icon			 = 'av5_vc_button-icon';
		$this->params		 = array(
			array(
				'type'		 => 'textfield',
				'heading'	 => esc_html__( 'Text', '5th-avenue' ),
				'param_name' => 'title',
				'value'		 => esc_html__( 'Text on the button', '5th-avenue' ),
				'std'		 => esc_html__( 'Text on the button', '5th-avenue' ),
			),
			array(
				'type'			 => 'vc_link',
				'heading'		 => esc_html__( 'URL (Link)', '5th-avenue' ),
				'param_name'	 => 'link',
				'description'	 => esc_html__( 'Add custom link.', '5th-avenue' ),
			),
			array(
				'type'			 => 'dropdown',
				'heading'		 => esc_html__( 'Style', '5th-avenue' ),
				'description'	 => esc_html__( 'Select button display style.', '5th-avenue' ),
				'param_name'	 => 'style',
				'value'			 => array(
					esc_html__( 'Flat', '5th-avenue' )						 => 'flat',
					esc_html__( 'Outline', '5th-avenue' )					 => 'outline',
					esc_html__( 'Outline Hover from Top', '5th-avenue' )	 => 'outline-top',
					esc_html__( 'Single underline', '5th-avenue' )			 => 'single-underline',
					esc_html__( 'Single underline big', '5th-avenue' )		 => 'single-underline big',
					esc_html__( 'Double Underline', '5th-avenue' )			 => 'underlined',
					esc_html__( 'Double Underline Long', '5th-avenue' )		 => 'underlined-long',
				),
				'std'			 => 'flat',
			),
			array(
				'type'		 => 'checkbox',
				'heading'	 => esc_html__( 'Shadow on hover', '5th-avenue' ),
				'param_name' => 'shadow_hover',
				'value'		 => 'false',
				'std'		 => false,
			),
			array(
				'type'			 => 'dropdown',
				'heading'		 => esc_html__( 'Colors', '5th-avenue' ),
				'description'	 => esc_html__( 'Choose from available colors preset. You can adjust them in Customizer.', '5th-avenue' ),
				'param_name'	 => 'colorset',
				'value'			 => array(
					esc_html__( 'Primary', '5th-avenue' )	 => 'primary',
					esc_html__( 'Secondary', '5th-avenue' ) => 'secondary',
					esc_html__( 'White', '5th-avenue' )	 => 'white-style',
					esc_html__( 'Custom', '5th-avenue' )	 => 'custom',
				),
				'std'			 => 'primary',
			),
			array(
				'type'			 => 'dropdown',
				'heading'		 => esc_html__( 'Alignment', '5th-avenue' ),
				'param_name'	 => 'align',
				'description'	 => esc_html__( 'Select button alignment.', '5th-avenue' ),
				'value'			 => array(
					esc_html__( 'Inline', '5th-avenue' )	 => 'inline',
					esc_html__( 'Left', '5th-avenue' )		 => 'left',
					esc_html__( 'Right', '5th-avenue' )	 => 'right',
					esc_html__( 'Center', '5th-avenue' )	 => 'center',
				),
				'std'			 => 'inline',
			),
			array(
				'type'			 => 'dropdown',
				'heading'		 => esc_html__( 'Size', '5th-avenue' ),
				'param_name'	 => 'size',
				'description'	 => esc_html__( 'Select button size.', '5th-avenue' ),
				'value'			 => array(
					esc_html__( 'Small', '5th-avenue' )		 => 'small',
					esc_html__( 'Small Wide', '5th-avenue' )	 => 'small-wide',
					esc_html__( 'Medium', '5th-avenue' )		 => 'medium',
					esc_html__( 'Medium Wide', '5th-avenue' )	 => 'medium-wide',
					esc_html__( 'Big', '5th-avenue' )			 => 'big',
					esc_html__( 'Big Wide', '5th-avenue' )		 => 'big-wide',
					esc_html__( 'Huge', '5th-avenue' )		 => 'huge',
				),
				'std'			 => 'big',
			),
			array(
				'type'				 => 'colorpicker',
				'heading'			 => esc_html__( 'Background', '5th-avenue' ),
				'param_name'		 => 'custom_background',
				'description'		 => esc_html__( 'Select custom color for button background or border.', '5th-avenue' ),
				'dependency'		 => array(
					'element'	 => 'colorset',
					'value'		 => 'custom',
				),
				'edit_field_class'	 => 'vc_col-sm-6',
			),
			array(
				'type'				 => 'colorpicker',
				'heading'			 => esc_html__( 'Text', '5th-avenue' ),
				'param_name'		 => 'custom_text',
				'description'		 => esc_html__( 'Select custom color for button text.', '5th-avenue' ),
				'dependency'		 => array(
					'element'	 => 'colorset',
					'value'		 => 'custom',
				),
				'edit_field_class'	 => 'vc_col-sm-6',
			),
			array(
				'type'				 => 'colorpicker',
				'heading'			 => esc_html__( 'Background Hover', '5th-avenue' ),
				'param_name'		 => 'custom_background_hover',
				'description'		 => esc_html__( 'Select custom hover color for button background or border.', '5th-avenue' ),
				'dependency'		 => array(
					'element'	 => 'colorset',
					'value'		 => 'custom',
				),
				'edit_field_class'	 => 'vc_col-sm-6',
			),
			array(
				'type'				 => 'colorpicker',
				'heading'			 => esc_html__( 'Text Hover', '5th-avenue' ),
				'param_name'		 => 'custom_text_hover',
				'description'		 => esc_html__( 'Select custom hover color for button text.', '5th-avenue' ),
				'dependency'		 => array(
					'element'	 => 'colorset',
					'value'		 => 'custom',
				),
				'edit_field_class'	 => 'vc_col-sm-6',
			),
			array(
				'type'				 => 'colorpicker',
				'heading'			 => esc_html__( 'Shadow on Hover', '5th-avenue' ),
				'param_name'		 => 'shadow_hover_color',
				'dependency'		 => array(
					'element'	 => 'colorset',
					'value'		 => 'custom',
				),
				'edit_field_class'	 => 'vc_col-sm-6',
			),
			array(
				'type'		 => 'textfield',
				'heading'	 => esc_html__( 'Animation Delay', '5th-avenue' ),
				'param_name' => 'anim_delay',
				'value'		 => '',
				'std'		 => '',
			),
		);
		if ( function_exists( 'vc_map_add_css_animation' ) ) {
			$this->params[] = vc_map_add_css_animation( true );
		}
		$this->params[] = array(
			'type'		 => 'css_editor',
			'heading'	 => esc_html__( 'CSS box', '5th-avenue' ),
			'param_name' => 'css',
			'group'		 => esc_html__( 'Design Options', '5th-avenue' ),
		);
		$this->default = array(
			'css_animation' => '',
		);
		parent::__construct();
	}
}
