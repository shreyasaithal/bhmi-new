<?php
/**
 * 5th-Avenue theme functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author LifeisDesign
 */

defined( 'ABSPATH' ) || exit;

// Assets enqueues.
require AV5C_PATH . 'inc/functions/plugin-assets.php';

// Sweet Custom Menu.
require AV5C_PATH . 'inc/integrations/sweet-custom-menu/sweet-custom-menu.php';
// Theme options.
require AV5C_PATH . 'inc/functions/redux-functions.php';

// Meta options.
require AV5C_PATH . 'inc/integrations/meta-box-extensions/loader.php';

// Plugin hooks
require_once AV5C_PATH . 'inc/functions/plugin-hooks.php';
/* WooCommerce size guide */
require_once AV5C_PATH . 'inc/functions/woocommerce-sizeguide.php';
/* WooCommerce products filter */
require_once AV5C_PATH . 'inc/functions/woocommerce-products-filter.php';
/* WooCommerce banners */
require_once AV5C_PATH . 'inc/functions/woocommerce-banners.php';
// Woocommerce hooks.
require AV5C_PATH . 'inc/functions/woocommerce-hooks.php';

// Extend Visual Composer.
require AV5C_PATH . '/inc/functions/js-composer-hooks.php';

// Theme widget.
require_once AV5C_PATH . 'inc/widget/widget.php';

// Theme shortcode.
require_once AV5C_PATH . 'inc/shortcode/shortcode.php';

require AV5C_PATH . '/inc/functions/mini-shortcodes.php';
