<?php
/**
 * Banners for woocommerce products loop
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

/**
 * Banners for woocommerce products loop
 */
class AV5_Woo_Banners {

	/**
	 * Banners list
	 *
	 * @var array
	 */
	public $banners;

	/**
	 * This class
	 *
	 * @var \AV5_Woo_Banners
	 */
	protected static $_instance = null;

	/**
	 * Get this class object
	 *
	 * @return \AV5_Woo_Banners
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Construct
	 */
	public function __construct() {
		$this->init();
	}

	/**
	 * Init hooks
	 */
	public function init() {
		add_filter( 'loop_shop_per_page', array( $this, 'per_page' ), 100 );
		add_action( 'woocommerce_shop_loop', array( $this, 'loop' ), 5 );
		add_filter( 'woocommerce_product_loop_end', array( $this, 'loop_end' ) );
	}

	/**
	 * Create new Banner
	 *
	 * @param int  $position Position banner.
	 * @param bool $repeatable Repeat after each product.
	 * @return \AV5_Woo_Banners_Banner
	 */
	public function create_banner( $position = 1, $repeatable = false ) {
		$banner = new AV5_Woo_Banners_Banner( $position, $repeatable );
		return $banner;
	}

	/**
	 * Get banners from theme
	 *
	 * @return array
	 */
	public function get_banners() {
		if ( empty( $this->banners ) && ! is_array( $this->banners ) ) {
			$this->banners = array();
			for ( $i = 1; $i <= 2; $i++ ) {
				if ( av5_get_option( 'shop-page-grid-banner-enabled' . $i ) ) {
					$classes = array(
						'grid-products-banner',
						'grid-products-banner-' . $i,
						'product-style--' . av5_get_option( 'shop-page-products-thumbnail-styles' ),
						'grid-banner__valign--' . av5_get_option( 'shop-page-grid-banner-valign' . $i ),
					);
					if ( ! av5_get_option( 'shop-page-products-thumbnail-carousel-arrows' ) ) {
						$classes[] = 'hide-product-carousel-arrows';
					}
					if ( ! av5_get_option( 'shop-page-products-thumbnail-carousel-dots' ) ) {
						$classes[] = 'hide-product-carousel-dots';
					}
					if ( av5_get_option( 'shop-page-product-boxed' ) ) {
						$classes[] = 'products-boxed-style';
					}
					$banner			 = $this->create_banner( av5_get_option( 'shop-page-grid-banner-position' . $i ), av5_get_option( 'shop-page-grid-banner-loop' . $i ) )
					->set_content( av5_get_option( 'shop-page-grid-banner' . $i ) )
					->set_attributes( 'classes', $classes );
					$this->banners[] = apply_filters( 'av5_woo_banners_banner', $banner, $i );
				}
			}
		}

		return apply_filters( 'av5_woo_banners_in_loop', $this->banners );
	}

	/**
	 * Change counts products per page
	 *
	 * @param int $cols Count products per page.
	 * @return int
	 */
	public function per_page( $cols ) {
		
		$banners	 = $this->get_banners();
		$new_cols	 = $cols;
		if ( ! empty( $banners ) && is_array( $banners ) ) {
			$banners_cols = 0;
			for ( $index = 0; $index < $cols; $index++ ) {
				foreach ( $banners as $banner ) {
					if ( $banner->is_show( $index ) ) {
						$banners_cols++;
					}
				}
			}
			$new_cols = $cols - $banners_cols;
		}

		return apply_filters( 'av5_woo_banners_per_page', $new_cols, $cols, $banners );
	}

	/**
	 * Add banner in loop products
	 */
	public function loop() {
		global $wp_query;
		$banners = $this->get_banners();
		if ( ! empty( $banners ) && is_array( $banners ) ) {
			$index = $wp_query->current_post;
			foreach ( $banners as $banner ) {
				if ( $banner->is_show( $index ) ) {
					$banner->show();
				}
			}
		}
	}

	/**
	 * Add banner after last product
	 *
	 * @global \wp_query $wp_query
	 * @param string $loop_end Loop end woo.
	 * @return string
	 */
	public function loop_end( $loop_end = '' ) {
		global $wp_query;
		$banners = $this->get_banners();
		if ( ! empty( $banners ) && is_array( $banners ) ) {
			$index = $wp_query->post_count;
			foreach ( $banners as $banner ) {
				if ( $banner->is_show( $index ) ) {
					$loop_end = $banner->html() . $loop_end;
				}
			}
		}
		return $loop_end;
	}

}

/**
 * Banner for woocommerce products loop
 */
class AV5_Woo_Banners_Banner {

	/**
	 * Position after product
	 *
	 * @var int
	 */
	private $position;

	/**
	 * Repeat after each product
	 *
	 * @var bool
	 */
	private $repeatable;

	/**
	 * Banner Content
	 *
	 * @var string
	 */
	public $content;

	/**
	 * Create new Banner
	 *
	 * @param int  $position Position banner.
	 * @param bool $repeatable Repeat after each product.
	 */
	public function __construct( $position = 1, $repeatable = false ) {
		$this->set_attributes( 'position', $position );
		$this->set_attributes( 'repeatable', $repeatable );
	}

	/**
	 * Set content for banner
	 *
	 * @param string $content Content.
	 * @return \AV5_Woo_Banners_Banner
	 */
	public function set_content( $content = '' ) {
		return $this->set_attributes( 'content', $content );
	}

	/**
	 * Set any attributes for banner
	 *
	 * @param string $name Name attribute.
	 * @param mixed  $value Value for attribute.
	 * @return \AV5_Woo_Banners_Banner
	 */
	public function set_attributes( $name, $value = null ) {
		if ( ! empty( $name ) && is_string( $name ) ) {
			switch ( $name ) {
				case 'position':
					$this->position		 = max( array( 1, absint( $value ) ) );
					break;
				case 'repeatable':
					$this->repeatable	 = (bool) $value;
					break;
				default:
					$this->$name		 = $value;
					break;
			}
			$this->$name = $value;
		}
		return $this;
	}

	/**
	 * Check if the banner is showing
	 *
	 * @param int $index Index current product.
	 * @return bool
	 */
	public function is_show( $index = 0 ) {
		$index = absint( $index );
		if ( $this->repeatable ) {
			return 0 < $index && 0 < $this->position && 0 === $index % $this->position;
		}
		return $index == $this->position;
	}

	/**
	 * Show banner
	 */
	public function show() {
		av5c_get_template( 'woocommerce/loop/products-banner.php', (array) $this );
	}

	/**
	 * Return banner
	 *
	 * @return string
	 */
	public function html() {
		return av5c_get_template_html( 'woocommerce/loop/products-banner.php', (array) $this );
	}

}


