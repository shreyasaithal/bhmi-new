<?php
/**
 * Hooks for plugin WPBakery Visual Composer
 *
 * @package 5th-Avenue
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

add_action( 'vc_base_register_admin_css', 'av5c_vc_styles' );
add_action( 'vc_base_register_admin_js', 'av5c_vc_js' );
add_action( 'vc_base_register_front_js', 'av5c_script_composer' );
add_action( 'vc_after_init', 'av5_vc_update_shortcode_param' );
add_filter( 'vc_param_animation_style_list', 'av5_animation_styles' );
add_filter( 'vc_shortcode_set_template_vc_column', 'av5c_set_template_vc_column' );
add_filter( 'vc_shortcode_set_template_vc_column_text', 'av5c_set_template_vc_column_text' );
add_filter( 'vc_shortcode_set_template_vc_row', 'av5c_set_template_vc_row' );

if ( ! function_exists( 'av5c_vc_js' ) ) {

	/**
	 * Get visual composer style
	 *
	 * @global array $avenue
	 */
	function av5c_vc_js() {
		$suffix_js = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG || ! av5_get_option( 'min-js' ) ? '' : '.min';
		wp_enqueue_script( 'av5_vc', AV5C_URL . '/assets/js/js_composer' . $suffix_js . '.js', array('jquery'), '', 'all' );
	}
}

if ( ! function_exists( 'av5c_vc_styles' ) ) {

	/**
	 * Get visual composer style
	 *
	 * @global array $avenue
	 */
	function av5c_vc_styles() {
		$suffix_style = defined( 'STYLE_DEBUG' ) && STYLE_DEBUG || ! av5_get_option( 'min-css' ) ? '' : '.min';
		wp_enqueue_style( 'av5_vc', AV5C_URL . '/assets/css/js_composer' . $suffix_style . '.css', array(), '', 'all' );
	}
}

if ( ! function_exists( 'av5c_script_composer' ) ) {

	/**
	 * Setup Styles and Scripts
	 */
	function av5c_script_composer() {
		wp_enqueue_script( 'av5-vc-front-js', AV5C_URL . '/assets/js/js_composer.front.js', array(
			'jquery',
			'wpb_composer_front_js',
		), '1.0.0', true );
	}
}


if ( ! function_exists( 'av5_multiselect_param_field' ) ) {

	/**
	 * Multi select element for WPBakery Visual Composer
	 *
	 * @param array $settings Array options for element.
	 * @param mixed $value Set value for this field.
	 * @return string
	 */
	function av5_multiselect_param_field( $settings, $value ) {
		$output		 = '';
		$css_option	 = str_replace( '#', 'hash-', vc_get_dropdown_option( $settings, $value ) );
		$output .= '<select multiple="multiple" name="'
		. $settings['param_name']
		. '" class="wpb_vc_param_value wpb-input wpb-select wpb-multiselect '
		. $settings['param_name']
		. ' ' . $settings['type']
		. ' ' . $css_option
		. '" data-option="' . $css_option . '">';
		if ( is_array( $value ) ) {
			$value = isset( $value['value'] ) ? $value['value'] : array_shift( $value );
		}
		if ( ! empty( $settings['value'] ) ) {
			foreach ( $settings['value'] as $index => $data ) {
				if ( is_numeric( $index ) && ( is_string( $data ) || is_numeric( $data ) ) ) {
					$option_label	 = $data;
					$option_value	 = $data;
				} elseif ( is_numeric( $index ) && is_array( $data ) ) {
					$option_label	 = isset( $data['label'] ) ? $data['label'] : array_pop( $data );
					$option_value	 = isset( $data['value'] ) ? $data['value'] : array_pop( $data );
				} else {
					$option_value	 = $data;
					$option_label	 = $index;
				}
				$selected			 = '';
				$option_value_string = (string) $option_value;
				$value_string		 = (string) $value;
				if ( '' !== $value && $option_value_string === $value_string ) {
					$selected = ' selected="selected"';
				}
				$option_class = str_replace( '#', 'hash-', $option_value );
				$output .= '<option class="' . esc_attr( $option_class ) . '" value="' . esc_attr( $option_value ) . '"' . $selected . '>'
				. htmlspecialchars( $option_label ) . '</option>';
			}
		}
		$output .= '</select>';

		return $output;
	}
} // End if().

if ( ! function_exists( 'hotspot_point_field' ) ) {

	/**
	 * Hotspot element for selection postion
	 *
	 * @param array $settings Arguments for field.
	 * @param mixed $value Current value.
	 * @return string
	 */
	function hotspot_point_field( $settings, $value ) {
		$param_name	 = isset( $settings['param_name'] ) ? $settings['param_name'] : '';
		$type		 = isset( $settings['type'] ) ? $settings['type'] : '';
		$class		 = isset( $settings['class'] ) ? $settings['class'] : '';
		$max_point	 = isset( $settings['max_points'] ) ? absint( $settings['max_points'] ) : 0;
		$uni		 = uniqid( 'hotspot-point-' . rand() );
		$output		 = '<div id="' . esc_attr( $uni ) . '" class="hotspot-point-param-container no-img">';
		$output .= '<input type="hidden" id="value-' . esc_attr( $uni ) . '" name="' . esc_attr( $param_name ) . '"data-max-points="' . esc_attr( $max_point ) . '" class="wpb_vc_param_value hotspot_point_var ' . esc_attr( $param_name ) . ' ' . esc_attr( $type ) . '_field" value="' . esc_attr( $value ) . '" />';
		$output .= '</div>';
		return $output;
	}
}

if ( ! function_exists( 'av5_vc_update_shortcode_param' ) ) {

	/**
	 * Update parametrs for visual composer shortcode
	 */
	function av5_vc_update_shortcode_param() {

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG || ! av5_get_option( 'min-js' ) ? '' : '.min';
		vc_add_shortcode_param( 'multiselect', 'av5_multiselect_param_field' );
		vc_add_shortcode_param( 'hotspot_point', 'hotspot_point_field', AV5C_URL . '/assets/js/js_composer.hotspot_point' . $suffix . '.js' );

		vc_add_param( 'vc_row', array(
			'type'		 => 'checkbox',
			'heading'	 => esc_html__( 'Enable Selfhosted Video background', '5th-avenue' ),
			'group'		 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name' => 'sh_bg_video',
		) );
		vc_add_param( 'vc_row', array(
			'type'			 => 'textfield',
			'heading'		 => esc_html__( 'MP4 video link', '5th-avenue' ),
			'group'			 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name'	 => 'video_mp4',
			'dependency'	 => array(
				'element'	 => 'sh_bg_video',
				'value'		 => 'true',
			),
			'value'			 => '',
			'std'			 => '',
		) );
		vc_add_param( 'vc_row', array(
			'type'			 => 'textfield',
			'heading'		 => esc_html__( 'Ogg video link', '5th-avenue' ),
			'group'			 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name'	 => 'video_ogv',
			'dependency'	 => array(
				'element'	 => 'sh_bg_video',
				'value'		 => 'true',
			),
			'value'			 => '',
			'std'			 => '',
		) );
		vc_add_param( 'vc_row', array(
			'type'			 => 'textfield',
			'heading'		 => esc_html__( 'Webm video link', '5th-avenue' ),
			'group'			 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name'	 => 'video_webm',
			'dependency'	 => array(
				'element'	 => 'sh_bg_video',
				'value'		 => 'true',
			),
			'value'			 => '',
			'std'			 => '',
		) );
		vc_add_param( 'vc_row', array(
			'type'		 => 'checkbox',
			'heading'	 => esc_html__( 'Enable background overlay', '5th-avenue' ),
			'group'		 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name' => 'bg_overlay',
		) );
		vc_add_param( 'vc_row', array(
			'type'			 => 'colorpicker',
			'heading'		 => esc_html__( 'Background', '5th-avenue' ),
			'param_name'	 => 'bg_overlay_color',
			'description'	 => esc_html__( 'Set image overlay color.', '5th-avenue' ),
			'group'			 => esc_html__( 'Theme Options', '5th-avenue' ),
			'dependency'	 => array(
				'element'	 => 'bg_overlay',
				'value'		 => 'true',
			),
			'std'			 => '#000000',
		) );
		vc_add_param( 'vc_row', array(
			'type'			 => 'textfield',
			'heading'		 => esc_html__( 'Background Overlay Opacity', '5th-avenue' ),
			'description'	 => esc_html__( 'Set opacity for background overlay from 0 to 100', '5th-avenue' ),
			'group'			 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name'	 => 'bg_overlay_opacity',
			'dependency'	 => array(
				'element'	 => 'bg_overlay',
				'value'		 => 'true',
			),
			'value'			 => 50,
			'std'			 => 50,
		) );
		vc_add_param( 'vc_column', array(
			'type'		 => 'dropdown',
			'heading'	 => esc_html__( 'Align Content', '5th-avenue' ),
			'group'		 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name' => 'align_content',
			'value'		 => array(
				'Unset'	 => '',
				'Left'	 => 'left',
				'Center' => 'center',
				'Right'	 => 'right',
			),
			'std'		 => '',
		) );
		vc_add_param( 'vc_column', array(
			'type'				 => 'dropdown',
			'heading'			 => esc_html__( 'Align Content Tablet', '5th-avenue' ),
			'group'				 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name'		 => 'align_content_tablet',
			'value'				 => array(
				'Unset'	 => '',
				'Left'	 => 'left',
				'Center' => 'center',
				'Right'	 => 'right',
			),
			'std'				 => '',
			'edit_field_class'	 => 'vc_col-sm-4',
		) );
		vc_add_param( 'vc_column', array(
			'type'				 => 'dropdown',
			'heading'			 => esc_html__( 'Align Content Mobile', '5th-avenue' ),
			'group'				 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name'		 => 'align_content_mobile',
			'value'				 => array(
				'Unset'	 => '',
				'Left'	 => 'left',
				'Center' => 'center',
				'Right'	 => 'right',
			),
			'std'				 => '',
			'edit_field_class'	 => 'vc_col-sm-4',
		) );
		vc_add_param( 'vc_column', array(
			'type'				 => 'dropdown',
			'heading'			 => esc_html__( 'Align Mobile Small', '5th-avenue' ),
			'group'				 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name'		 => 'align_content_small',
			'value'				 => array(
				'Unset'	 => '',
				'Left'	 => 'left',
				'Center' => 'center',
				'Right'	 => 'right',
			),
			'std'				 => '',
			'edit_field_class'	 => 'vc_col-sm-4',
		) );
		vc_add_param( 'vc_column', array(
			'type'		 => 'dropdown',
			'heading'	 => esc_html__( 'Block Overlap', '5th-avenue' ),
			'group'		 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name' => 'block_overlap',
			'value'		 => array(
				'Unset'			 => '',
				'Overlap Left'	 => 'overlap-left',
				'Overlap Right'	 => 'overlap-right',
			),
			'std'		 => '',
		) );
		vc_add_param( 'vc_column', array(
			'type'		 => 'checkbox',
			'heading'	 => esc_html__( 'Boxed block', '5th-avenue' ),
			'group'		 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name' => 'boxed_block',
		) );
		vc_add_param( 'vc_column', array(
			'type'		 => 'dropdown',
			'heading'	 => esc_html__( 'Boxed block padding size', '5th-avenue' ),
			'group'		 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name' => 'boxed_size',
			'dependency' => array(
				'element'	 => 'boxed_block',
				'value'		 => 'true',
			),
			'value'		 => array(
				'Small'	 => 'small',
				'Normal' => 'normal',
				'Big'	 => 'big',
				'Huge'	 => 'huge',
			),
		) );
		vc_add_param( 'vc_column', array(
			'type'		 => 'checkbox',
			'heading'	 => esc_html__( 'Boxed Block with Shadow', '5th-avenue' ),
			'group'		 => esc_html__( 'Theme Options', '5th-avenue' ),
			'dependency' => array(
				'element'	 => 'boxed_block',
				'value'		 => 'true',
			),
			'param_name' => 'boxed_shadow',
		) );
		vc_add_param( 'vc_column', array(
			'type'				 => 'textfield',
			'heading'			 => esc_html__( 'Max width', '5th-avenue' ),
			'description'		 => esc_html__( 'Set block max width', '5th-avenue' ),
			'group'				 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name'		 => 'max_width',
			'edit_field_class'	 => 'vc_col-sm-6',
		) );
		vc_add_param( 'vc_column', array(
			'type'				 => 'dropdown',
			'heading'			 => esc_html__( 'Max width Align', '5th-avenue' ),
			'group'				 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name'		 => 'max_width_align',
			'value'				 => array(
				'Left'	 => 'left',
				'Right'	 => 'right',
				'Center' => 'centered',
			),
			'edit_field_class'	 => 'vc_col-sm-6',
		) );
		vc_add_param( 'vc_column', array(
			'type'				 => 'dropdown',
			'heading'			 => esc_html__( 'Max width Align Tablet', '5th-avenue' ),
			'group'				 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name'		 => 'max_width_align_tablet',
			'value'				 => array(
				'Left'	 => 'left',
				'Right'	 => 'right',
				'Center' => 'centered',
			),
			'edit_field_class'	 => 'vc_col-sm-4',
		) );
		vc_add_param( 'vc_column', array(
			'type'				 => 'dropdown',
			'heading'			 => esc_html__( 'Max width Align Mobile', '5th-avenue' ),
			'group'				 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name'		 => 'max_width_align_mobile',
			'value'				 => array(
				'Left'	 => 'left',
				'Right'	 => 'right',
				'Center' => 'centered',
			),
			'edit_field_class'	 => 'vc_col-sm-4',
		) );
		vc_add_param( 'vc_column', array(
			'type'				 => 'dropdown',
			'heading'			 => esc_html__( 'Max width Align Small', '5th-avenue' ),
			'group'				 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name'		 => 'max_width_align_small',
			'value'				 => array(
				'Left'	 => 'left',
				'Right'	 => 'right',
				'Center' => 'centered',
			),
			'edit_field_class'	 => 'vc_col-sm-4',
		) );
		vc_add_param( 'vc_column', array(
			'type'		 => 'checkbox',
			'heading'	 => esc_html__( 'Enable background overlay', '5th-avenue' ),
			'group'		 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name' => 'bg_overlay',
		) );
		vc_add_param( 'vc_column', array(
			'type'			 => 'colorpicker',
			'heading'		 => esc_html__( 'Background', '5th-avenue' ),
			'param_name'	 => 'bg_overlay_color',
			'description'	 => esc_html__( 'Set image overlay color.', '5th-avenue' ),
			'group'			 => esc_html__( 'Theme Options', '5th-avenue' ),
			'dependency'	 => array(
				'element'	 => 'bg_overlay',
				'value'		 => 'true',
			),
			'std'			 => '#000000',
		) );
		vc_add_param( 'vc_column', array(
			'type'			 => 'textfield',
			'heading'		 => esc_html__( 'Background Overlay Opacity', '5th-avenue' ),
			'description'	 => esc_html__( 'Set opacity for background overlay from 0 to 100', '5th-avenue' ),
			'group'			 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name'	 => 'bg_overlay_opacity',
			'dependency'	 => array(
				'element'	 => 'bg_overlay',
				'value'		 => 'true',
			),
			'value'			 => 50,
			'std'			 => 50,
		) );
		vc_add_param( 'vc_column', array(
			'type'			 => 'textfield',
			'heading'		 => esc_html__( 'Animation Delay', '5th-avenue' ),
			'description'	 => esc_html__( 'Set the delay for element animation when it "enters" the browsers viewport in milliseconds (1000ms = 1 second)', '5th-avenue' ),
			'group'			 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name'	 => 'anim_delay',
		) );
		vc_add_param( 'vc_column_text', array(
			'type'		 => 'dropdown',
			'heading'	 => esc_html__( 'Indent Side', '5th-avenue' ),
			'group'		 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name' => 'indent_position',
			'value'		 => array(
				'Left'	 => 'left',
				'Right'	 => 'right',
				'Top'	 => 'top',
				'Bottom' => 'bottom',
			),
		) );
		vc_add_param( 'vc_column_text', array(
			'type'			 => 'textfield',
			'heading'		 => esc_html__( 'Indent Desktop value', '5th-avenue' ),
			'description'	 => esc_html__( 'Set spacing value in % or px', '5th-avenue' ),
			'group'			 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name'	 => 'indent',
			'value'			 => '',
			'std'			 => '',
		) );
		vc_add_param( 'vc_column_text', array(
			'type'				 => 'textfield',
			'heading'			 => esc_html__( 'Indent Table value', '5th-avenue' ),
			'description'		 => esc_html__( 'Set spacing value in % or px for tablet. If not set will inherit from desktop.', '5th-avenue' ),
			'group'				 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name'		 => 'indent_tablet',
			'value'				 => '',
			'std'				 => '',
			'edit_field_class'	 => 'vc_col-sm-4',
		) );
		vc_add_param( 'vc_column_text', array(
			'type'				 => 'textfield',
			'heading'			 => esc_html__( 'Indent Mobile value', '5th-avenue' ),
			'description'		 => esc_html__( 'Set spacing value in % or px for mobile. If not set will inherit from desktop.', '5th-avenue' ),
			'group'				 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name'		 => 'indent_mobile',
			'value'				 => '',
			'std'				 => '',
			'edit_field_class'	 => 'vc_col-sm-4',
		) );
		vc_add_param( 'vc_column_text', array(
			'type'				 => 'textfield',
			'heading'			 => esc_html__( 'Indent Small Mobile value', '5th-avenue' ),
			'description'		 => esc_html__( 'Set spacing value in % or px for small mobile screens. If not set will inherit from desktop.', '5th-avenue' ),
			'group'				 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name'		 => 'indent_mobile_small',
			'value'				 => '',
			'std'				 => '',
			'edit_field_class'	 => 'vc_col-sm-4',
		) );
		vc_add_param( 'vc_column_text', array(
			'type'				 => 'textfield',
			'heading'			 => esc_html__( 'Max width', '5th-avenue' ),
			'description'		 => esc_html__( 'Set block max width', '5th-avenue' ),
			'group'				 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name'		 => 'max_width',
			'edit_field_class'	 => 'vc_col-sm-6',
		) );
		vc_add_param( 'vc_column_text', array(
			'type'				 => 'dropdown',
			'heading'			 => esc_html__( 'Max width Align', '5th-avenue' ),
			'group'				 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name'		 => 'max_width_align',
			'value'				 => array(
				'Left'	 => 'left',
				'Right'	 => 'right',
				'Center' => 'centered',
			),
			'edit_field_class'	 => 'vc_col-sm-6',
		) );
		vc_add_param( 'vc_column_text', array(
			'type'			 => 'textfield',
			'heading'		 => esc_html__( 'Animation Delay', '5th-avenue' ),
			'description'	 => esc_html__( 'Set the delay for element animation when it "enters" the browsers viewport in milliseconds (1000ms = 1 second)', '5th-avenue' ),
			'group'			 => esc_html__( 'Theme Options', '5th-avenue' ),
			'param_name'	 => 'anim_delay',
		) );
	}
} // End if().

if ( ! function_exists( 'av5_animation_styles' ) ) {

	/**
	 * Adds custom anoation for visual composer elements
	 *
	 * @param array $styles Current animation.
	 * @return array
	 */
	function av5_animation_styles( $styles ) {
		$default		 = array_shift( $styles );
		$theme_animation = array(
			array(
				'label'	 => esc_html__( 'Theme animation', '5th-avenue' ),
				'values' => array(
					esc_html__( 'fadeInUp', '5th-avenue' )			 => array(
						'value'	 => 'av5-fadeInUp',
						'type'	 => 'in', // 'in', 'other', 'out'
					),
					esc_html__( 'fadeInUp Long', '5th-avenue' )	 => array(
						'value'	 => 'av5-fadeInUp-long',
						'type'	 => 'in', // 'in', 'other', 'out'
					),
					esc_html__( 'fadeInLeft', '5th-avenue' )		 => array(
						'value'	 => 'av5-fadeInLeft',
						'type'	 => 'in', // 'in', 'other', 'out'
					),
					esc_html__( 'fadeInLeft Long', '5th-avenue' )	 => array(
						'value'	 => 'av5-fadeInLeft-long',
						'type'	 => 'in', // 'in', 'other', 'out'
					),
					esc_html__( 'fadeInRight', '5th-avenue' )		 => array(
						'value'	 => 'av5-fadeInRight',
						'type'	 => 'in', // 'in', 'other', 'out'
					),
					esc_html__( 'fadeInRight Long', '5th-avenue' )	 => array(
						'value'	 => 'av5-fadeInRight-long',
						'type'	 => 'in', // 'in', 'other', 'out'
					),
				),
			),
		);
		$styles			 = array_merge( array( $default ), $theme_animation, $styles );

		return $styles;
	}
} // End if().

if ( ! function_exists( 'av5c_set_template_vc_column' ) ) {

	/**
	 * Set template for vc_column
	 */
	function av5c_set_template_vc_column() {
		return av5c_locate_template( 'vc_templates/vc_column.php' );
	}
}

if ( ! function_exists( 'av5c_set_template_vc_column_text' ) ) {

	/**
	 * Set template for vc_column_text
	 */
	function av5c_set_template_vc_column_text() {
		return av5c_locate_template( 'vc_templates/vc_column_text.php' );
	}
}

if ( ! function_exists( 'av5c_set_template_vc_row' ) ) {

	/**
	 * Set template for vc_row
	 */
	function av5c_set_template_vc_row() {
		return av5c_locate_template( 'vc_templates/vc_row.php' );
	}

}