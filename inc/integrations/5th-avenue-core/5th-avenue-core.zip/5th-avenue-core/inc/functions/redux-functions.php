<?php
/**
 * 5th-Avenue redux theme options
 *
 * @package 5th-Avenue
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Redux' ) ) {
	return;
}

if ( ! function_exists( 'av5_custom_fonts' ) ) {
	/**
	 * Add theme custom fonts
	 *
	 * @param array $custom_fonts Exist custom fonts.
	 * @return array
	 */
	function av5_custom_fonts( $custom_fonts ) {
		if ( ! is_array( $custom_fonts ) || empty( $custom_fonts ) ) {
			$custom_fonts = array();
		}

		$av5_custom_fonts = array(
			'butler_black-webfont'		 => array( 'woff' ),
			'butler_bold-webfont'		 => array( 'woff' ),
			'butler_extrabold-webfont'	 => array( 'woff' ),
			'butler_light-webfont'		 => array( 'woff' ),
			'butler_medium-webfont'		 => array( 'woff' ),
			'butler_regular-webfont'	 => array( 'woff' ),
			'butler_ultra_light-webfont' => array( 'woff' ),
		);
		if ( ! empty( $custom_fonts ) ) {
			foreach ( $custom_fonts as $section => $fonts ) {
				foreach ( $av5_custom_fonts as $font => $pieces ) {
					if ( array_key_exists( $font, $fonts ) ) {
						$custom_fonts[ $section ][ $font ] = array_unique( array_merge( $fonts[ $font ], $pieces ) );
					} else {
						$custom_fonts[ $section ][ $font ] = $pieces;
					}
				}
				break;
			}
		} else {
			$custom_fonts = wp_parse_args( $custom_fonts, array( 'Custom Fonts' => $av5_custom_fonts ) );
		}

		return $custom_fonts;
	}
} // End if().

if ( ! function_exists( 'av5_tinymce_custom_fonts' ) ) {
	/**
	 * Add theme custom fonts for tinymce
	 *
	 * @param array $opt Options for TinyMCE.
	 * @return array
	 */
	function av5_tinymce_custom_fonts( $opt ) {
		global $avenue;

		if ( ! is_admin() ) {
			return $opt;
		}

		$av5_custom_fonts = array(
			'Custom Fonts' => array(
				'butler_black-webfont'		 => array( 'woff' ),
				'butler_bold-webfont'		 => array( 'woff' ),
				'butler_extrabold-webfont'	 => array( 'woff' ),
				'butler_light-webfont'		 => array( 'woff' ),
				'butler_medium-webfont'		 => array( 'woff' ),
				'butler_regular-webfont'	 => array( 'woff' ),
				'butler_ultra_light-webfont' => array( 'woff' ),
			),
		);

		$stylesheet = $avenue->uri . '/assets/css/redux-fonts.css';

		if ( empty( $opt['content_css'] ) ) {
			$opt['content_css'] = $stylesheet;
		} else {
			$opt['content_css'] = $opt['content_css'] . ',' . $stylesheet;
		}

		$theme_advanced_fonts	 = isset( $opt['font_formats'] ) ? isset( $opt['font_formats'] ) : 'Andale Mono=andale mono,times;Arial=arial,helvetica,sans-serif;Arial Black=arial black,avant garde;Book Antiqua=book antiqua,palatino;Comic Sans MS=comic sans ms,sans-serif;Courier New=courier new,courier;Georgia=georgia,palatino;Helvetica=helvetica;Impact=impact,chicago;Symbol=symbol;Tahoma=tahoma,arial,helvetica,sans-serif;Terminal=terminal,monaco;Times New Roman=times new roman,times;Trebuchet MS=trebuchet ms,geneva;Verdana=verdana,geneva;Webdings=webdings;Wingdings=wingdings,zapf dingbats';
		$custom_fonts			 = '';

		foreach ( $av5_custom_fonts as $title => $arr ) {
			foreach ( $arr as $font => $pieces ) {
				$custom_fonts .= ';' . $font . '=' . $font;
			}

			continue;
		}

		$opt['font_formats'] = $theme_advanced_fonts . $custom_fonts;

		return $opt;
	}
} // End if().


if ( ! function_exists( 'av5_remove_demo_mode_link' ) ) {

	/**
	 * Remove demo links from Redux
	 */
	function av5_remove_demo_mode_link() {
		if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
			remove_filter( 'plugin_row_meta', array(
				ReduxFrameworkPlugin::get_instance(),
				'plugin_metalinks',
			), null, 2 );
			remove_action( 'admin_notices', array( ReduxFrameworkPlugin::get_instance(), 'admin_notices' ) );
		}
	}
}

if ( ! function_exists( 'av5_theme_core_options_extension_loader' ) ) {

	/**
	 * Loading extetions
	 *
	 * @param \ReduxFramework $redux_framework Redux Framework main class.
	 */
	function av5_theme_core_options_extension_loader( $redux_framework ) {
		$path	 = AV5C_PATH . 'inc/integrations/redux-extensions/';
		$folders = scandir( $path, 1 );
		foreach ( $folders as $folder ) {
			if ( '.' === $folder || '..' === $folder || ! is_dir( $path . $folder ) ) {
				continue;
			}
			$extension_class = 'ReduxFramework_Extension_' . $folder;
			if ( ! class_exists( $extension_class ) ) {
				// In case you wanted override your override, hah.
				$class_file	 = $path . $folder . '/extension_' . $folder . '.php';
				$class_file	 = apply_filters( 'redux/extension/' . $redux_framework->args['opt_name'] . '/' . $folder, $class_file );
				if ( $class_file ) {
					require_once( $class_file );
					$extension = new $extension_class( $redux_framework );
				}
			}
		}
	}
}

if ( ! function_exists( 'av5_admin_template_options' ) ) {

	/**
	 * Change template folder for theme
	 *
	 * @param string $template_path Path for template.
	 * @return string
	 */
	function av5_admin_template_options( $template_path ) {
		return AV5C_PATH . 'inc/integrations/redux-templates/panel';
	}
}

if ( ! function_exists( 'av5_wbc_importer_dir_path' ) ) {

	/**
	 * Change demo directiory
	 *
	 * @return string
	 */
	function av5_wbc_importer_dir_path() {
		return AV5C_PATH . 'inc/demo-data/';
	}
}

// This is your option name where all the Redux data is stored.
$opt_name = apply_filters( 'av5_redux_name', 'lid_av5' );

add_filter( 'wbc_importer_dir_path', 'av5_wbc_importer_dir_path' );
add_action( 'init', 'av5_remove_demo_mode_link' );
add_action( 'redux/extensions/before', 'av5_theme_core_options_extension_loader', 0 );
add_filter( "redux/{$opt_name}/panel/templates_path", 'av5_admin_template_options' );
add_filter( "redux/{$opt_name}/field/typography/custom_fonts", 'av5_custom_fonts', 20 );
add_filter( 'tiny_mce_before_init', 'av5_tinymce_custom_fonts' );
