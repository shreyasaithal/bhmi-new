<?php
/**
 * Woocommerce hooks.
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'av5c_init_hooks' ) ) {

	/**
	 * Modifies default woocommerce hooks
	 */
	function av5c_init_hooks() {
		if ( ! av5_is_woocommerce_activated() ) {
			return;
		}
		add_action( 'add_meta_boxes', 'av5_add_woo_thumb_gallery', 40 );
		add_action( 'admin_enqueue_scripts', 'av5_woo_image_gallery' );
		add_action( 'woocommerce_process_product_meta', 'av5_woo_loop_gallery_save', 30 );
		add_filter( 'template_include', 'av5c_template_include', 20 );
		add_filter( 'comments_template', 'av5c_template_include', 20 );
		add_filter( 'wc_get_template_part', 'av5c_wc_get_template_part', 10, 3 );
		add_filter( 'woocommerce_locate_template', 'av5c_woocommerce_locate_template', 20, 3 );
		
		add_action( 'after_setup_theme', 'av5_image_size_init' );
		add_action( 'av5-woocommerce_before_single_product', 'av5_woocommerce_product_navigation', 1 );
		add_action( 'av5-woocommerce_before_single_product', 'av5_woocommerce_product_share', 1 );
		add_action( 'av5-woocommerce_single_product_summary-left', 'av5_woocommerce_product_page_second_description', 20 );
		add_action( 'av5_after_cart_is_empty', 'av5_empty_cart_content' );
		add_action( 'av5_title_area_after_title', 'av5_title_area_catmeta', 40 );
		add_action( 'av5_title_area_after_title', 'av5_title_area_product_catmeta', 40 );
		add_action( 'av5_title_area_hero_after_title', 'av5_title_area_catmeta', 40 );
		add_action( 'av5_title_area_hero_after_title', 'av5_title_area_product_catmeta', 40 );
		add_action( 'init', 'av5_modify_woocommerce_hooks' );
		add_action( 'init', 'av5_woocommerce_cross_sell_display' );
		add_action( 'init', 'override_wishlist_button' );
		add_action( 'init', 'product_page_breadcrumbs_show' );
		add_action( 'init', 'remove_cart_breadcrumbs' );
		add_action( 'init', 'reposition_woo_messages' );
		add_action( 'init', 'reposition_woo_meta' );
		add_action( 'wc_ajax_av5_add_to_cart', 'av5_ajax_add_to_cart' );
		add_action( 'wc_ajax_login', 'av5_woocommerce_login' );
		add_action( 'wc_ajax_register', 'av5_woocommerce_register' );
		add_action( 'woocommerce_after_single_product', 'av5_woocommerce_product_bar', 1 );
		add_action( 'woocommerce_after_single_product_summary', 'av5_product_page_content', 12 );
		add_action( 'woocommerce_after_subcategory', 'woocommerce_template_loop_category_button', 5 );
		add_action( 'woocommerce_cart_collaterals', 'av5_woocommerce_continue_shopping_cart', 100 );
		add_action( 'woocommerce_single_product_summary', 'after_add_to_cart_link', 32 );
		add_action( 'wp_ajax_login', 'av5_woocommerce_login' );
		add_action( 'wp_ajax_nopriv_login', 'av5_woocommerce_login' );
		add_action( 'wp_ajax_nopriv_register', 'av5_woocommerce_register' );
		add_action( 'wp_ajax_nopriv_woocommerce_av5_add_to_cart', 'av5_ajax_add_to_cart' );
		add_action( 'wp_ajax_nopriv_woocommerce_login', 'av5_woocommerce_login' );
		add_action( 'wp_ajax_nopriv_woocommerce_register', 'av5_woocommerce_register' );
		add_action( 'wp_ajax_register', 'av5_woocommerce_register' );
		add_action( 'wp_ajax_woocommerce_av5_add_to_cart', 'av5_ajax_add_to_cart' );
		add_action( 'wp_ajax_woocommerce_login', 'av5_woocommerce_login' );
		add_action( 'wp_ajax_woocommerce_register', 'av5_woocommerce_register' );
		add_filter( 'loop_shop_per_page', 'av5_loop_shop_per_page', 20 );
		add_filter( 'woocommerce_breadcrumb_defaults', 'change_breadcrumb_delimiter' );
		add_filter( 'woocommerce_output_related_products_args', 'av5_related_products_args' );
		add_filter( 'woocommerce_product_tabs', 'av5_remove_description_product_tab_meta', 98 );
		if ( av5_get_option( 'shop-page-product-filters-position' ) === 'title-area' ) {
			add_action( 'init', 'av5_woocommerce_filter_move_to_title' );
		}
		if ( av5_get_option( 'shop-page-quickview' ) ) {
			add_action( 'wp_ajax_woocommerce_quickview', 'av5_quick_view' );
			add_action( 'wp_ajax_nopriv_woocommerce_quickview', 'av5_quick_view' );
			add_action( 'wp_ajax_quickview', 'av5_quick_view' );
			add_action( 'wp_ajax_nopriv_quickview', 'av5_quick_view' );
			add_action( 'wc_ajax_quickview', 'av5_quick_view' );
		}
		if ( av5_get_option( 'header-cart-counter-show' ) ) {
			add_filter( 'woocommerce_add_to_cart_fragments', 'av5_woocommerce_shopping_cart_counter', 20 );
		}
		if ( av5_get_option( 'product-pages-product-thumbnails-position' ) == 'thumbs-left' && ( av5_get_option( 'product-pages-layout' ) == '1' || av5_get_option( 'product-pages-layout' ) == '6' || av5_get_option( 'product-pages-layout' ) == '2' || av5_get_option( 'product-pages-layout' ) == '3') ) { // WPCS: loose comparison ok.
			add_action( 'woocommerce_product_vertical_thumbnails', 'av5_woocommerce_show_vertical_product_thumbnails', 20 );
		}
		if ( ! av5_get_option( 'product-pages-info-tab-enable' ) ) {
			add_filter( 'woocommerce_product_tabs', 'remove_additional_information_product_tab', 98 );
		}

		if ( !av5_get_option( 'product-pages-desc-tab-enable' ) ) {
			add_filter( 'woocommerce_product_tabs', 'remove_description_product_tab', 98 );
		}

		AV5_Woo_Banners::instance();
		AV5_Products_Filter::init();
		AV5_SizeGuide::init();
	}

	add_action( 'woocommerce_loaded', 'av5c_init_hooks' );
} // End if().
/**
 * Uploader image for loop carousel
 */
if ( ! function_exists( 'av5_woo_loop_gallery' ) ) {

	/**
	 * Get gallery for loop
	 *
	 * @param \WP_Post $post Post element.
	 */
	function av5_woo_loop_gallery( $post ) {
		?>
		<div id="product_loop_images_container">
			<ul class="product_loop_images">
				<?php
				if ( metadata_exists( 'post', $post->ID, '_product_loop_image_gallery' ) ) {
					$product_loop_image_gallery = get_post_meta( $post->ID, '_product_loop_image_gallery', true );
				} else {
					// Backwards compat.
					$attachment_ids				 = get_posts( 'post_parent=' . $post->ID . '&numberposts=-1&post_type=attachment&orderby=menu_order&order=ASC&post_mime_type=image&fields=ids&meta_key=_woocommerce_exclude_image&meta_value=0' ); // @codingStandardsIgnoreLine WordPress.VIP.RestrictedFunctions.get_posts
					$attachment_ids				 = array_diff( $attachment_ids, array( get_post_thumbnail_id() ) );
					$product_loop_image_gallery	 = implode( ',', $attachment_ids );
				}

				$attachments		 = array_filter( explode( ',', $product_loop_image_gallery ) );
				$update_meta		 = false;
				$updated_gallery_ids = array();

				if ( ! empty( $attachments ) ) {
					foreach ( $attachments as $attachment_id ) {
						$attachment = wp_get_attachment_image( $attachment_id, 'thumbnail' );

						// If attachment is empty skip.
						if ( empty( $attachment ) ) {
							$update_meta = true;
							continue;
						}

						echo '<li class="image" data-attachment_id="' . esc_attr( $attachment_id ) . '">' . $attachment . '<ul class="actions"><li><a href="#" class="delete tips" data-tip="' . esc_attr__( 'Delete image', 'woocommerce' ) . '">' . esc_html__( 'Delete', 'woocommerce' ) . '</a></li></ul></li>'; // WPCS: xss ok.

						// Rebuild ids to be saved.
						$updated_gallery_ids[] = $attachment_id;
					}

					// Need to update product meta to set new gallery ids.
					if ( $update_meta ) {
						update_post_meta( $post->ID, '_product_loop_image_gallery', implode( ',', $updated_gallery_ids ) );
					}
				}
				?>
			</ul>

			<input type="hidden" id="product_loop_image_gallery" name="product_loop_image_gallery" value="<?php echo esc_attr( $product_loop_image_gallery ); ?>" />

		</div>
		<p class="add_product_loop_images hide-if-no-js">
			<a href="#" data-choose="<?php esc_attr_e( 'Add Images to Product Gallery', 'woocommerce' ); ?>" data-update="<?php esc_attr_e( 'Add to gallery', 'woocommerce' ); ?>" data-delete="<?php esc_attr_e( 'Delete image', 'woocommerce' ); ?>" data-text="<?php esc_attr_e( 'Delete', 'woocommerce' ); ?>"><?php esc_html_e( 'Add product gallery images', 'woocommerce' ); ?></a>
		</p>
		<?php
	}
} // End if().
if ( ! function_exists( 'av5_woo_loop_gallery_save' ) ) {

	/**
	 * Save gallery loop for Products
	 *
	 * @param int $post_id Post ID.
	 */
	function av5_woo_loop_gallery_save( $post_id ) {
		$attachment_ids = isset( $_POST['product_loop_image_gallery'] ) ? array_filter( explode( ',', wc_clean( $_POST['product_loop_image_gallery'] ) ) ) : array(); // @codingStandardsIgnoreLine WordPress.VIP.SuperGlobalInputUsage.AccessDetected

		if ( empty( $attachment_ids ) ) {
			delete_post_meta( $post_id, '_product_loop_image_gallery' );
		} else {
			update_post_meta( $post_id, '_product_loop_image_gallery', implode( ',', $attachment_ids ) );
		}
	}
}
if ( ! function_exists( 'av5_add_woo_thumb_gallery' ) ) {

	/**
	 * Add metabox for gallery image for loop
	 *
	 * @param string $post_type Post type for elements.
	 */
	function av5_add_woo_thumb_gallery( $post_type ) {
		if ( ! in_array( $post_type, array( 'product' ) ) ) {
			return;
		}
		add_meta_box( 'woocommerce-product-loop-images', esc_html__( 'Product Loop Gallery', '5th-avenue' ), 'av5_woo_loop_gallery', $post_type, 'side', 'low' );
	}
}
if ( ! function_exists( 'av5_woo_image_gallery' ) ) {

	/**
	 * Add gallery image for loop script
	 *
	 * @global array $avenue
	 */
	function av5_woo_image_gallery() {
		global $avenue;
		$screen		 = get_current_screen();
		$screen_id	 = $screen ? $screen->id : '';
		if ( in_array( $screen_id, array( 'product', 'edit-product' ) ) ) {
			wp_enqueue_media();
			$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG || ! av5_get_option( 'min-js' ) ? '' : '.min';
			wp_enqueue_script( 'av5-meta-boxes-gallery', AV5C_URL . 'assets/js/meta-boxes-product' . $suffix . '.js', array( 'media-models' ) );
		}
	}
}
if ( ! function_exists( 'av5c_woocommerce_locate_template' ) ) {

	/**
	 * Relocate woocommerce templates
	 *
	 * @param string $template Located template.
	 * @param string $template_name Selected template.
	 * @param string $template_path Template path.
	 * @return string
	 */
	function av5c_woocommerce_locate_template( $template, $template_name, $template_path ) {
		$_template = av5c_locate_template( 'woocommerce/' . $template_name );
		if ( ! empty( $_template ) && file_exists( $_template ) ) {
			$template = $_template;
		}

		return $template;
	}
}
if ( ! function_exists( 'av5c_wc_get_template_part' ) ) {

	/**
	 * Relocate woocommerce templates
	 *
	 * @param string $template Located template.
	 * @param string $template_name Selected template.
	 * @param string $template_path Template path.
	 * @return string
	 */
	function av5c_wc_get_template_part( $template, $slug, $name ) {
		$_template = av5c_locate_template_part( 'woocommerce/' . $slug, $name );
		if ( ! empty( $_template ) && file_exists( $_template ) ) {
			$template = $_template;
		}

		return $template;
	}
}
if ( ! function_exists( 'av5c_template_include' ) ) {

	/**
	 * Relocate woocommerce templates
	 *
	 * @param string $template Located template.
	 * @param string $template_name Selected template.
	 * @param string $template_path Template path.
	 * @return string
	 */
	function av5c_template_include( $template ) {
		if ( false !== strpos( $template, WC()->plugin_path() . '/templates/' ) ) {
			$original_template = str_replace( WC()->plugin_path() . '/templates/', '', $template );
			$_template = av5c_locate_template( 'woocommerce/' . $original_template );
			if ( ! empty( $_template ) && file_exists( $_template ) ) {
				$template = $_template;
			}
		}

		return $template;
	}
}
if ( ! function_exists( 'av5_loop_shop_per_page' ) ) {

	/**
	 * Change the number of products on the page
	 *
	 * @return integer
	 */
	function av5_loop_shop_per_page() {
		return av5_get_option( 'shop-page-products-per-page' );
	}
}
if ( ! function_exists( 'av5_remove_woocommerce_hooks' ) ) {

	/**
	 * Modifies default woocommerce hooks
	 */
	function av5_modify_woocommerce_hooks() {
		remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );
		remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10 );
		if ( av5_get_option( 'product-pages-layout' ) === '3' && get_theme_mod( 'product_labels_style' ) !== 'rounded' ) {
			add_action( 'av5-woocommerce_before_single_product', 'woocommerce_show_product_sale_flash', 2 );
		} elseif ( av5_get_option( 'product-pages-layout' ) === '5' && get_theme_mod( 'product_labels_style' ) !== 'rounded' ) {
			add_action( 'woocommerce_single_product_summary', 'woocommerce_show_product_sale_flash', 2 );
		} else {
			add_action( 'av5_woocommerce_product_before_product_image', 'woocommerce_show_product_sale_flash', 2 );
		}
		// Product Thumbnail Type.
		if ( av5_get_option( 'shop-page-products-carousel-thumbnail-type', 1 ) ) {
			remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );
			add_action( 'woocommerce_before_shop_loop_item_title', 'av5_template_loop_product_carousel_thumbnails', 10 );
			switch ( av5_get_option( 'shop-page-products-thumbnail-type', '2' ) ) {
				case '2':
					add_action( 'av5_product_carousel_replacement_image', 'av5_template_loop_product_hover_thumbnails' );
					add_action( 'av5_product_hover_replacement_image', 'woocommerce_template_loop_product_link_open', 5 );
					add_action( 'av5_product_hover_replacement_image', 'woocommerce_template_loop_product_thumbnail' );
					add_action( 'av5_product_hover_replacement_image', 'woocommerce_template_loop_product_link_close', 15 );
					break;
				default:
					add_action( 'av5_product_carousel_replacement_image', 'woocommerce_template_loop_product_link_open', 5 );
					add_action( 'av5_product_carousel_replacement_image', 'woocommerce_template_loop_product_thumbnail' );
					add_action( 'av5_product_carousel_replacement_image', 'woocommerce_template_loop_product_link_close', 15 );
			}
		} elseif ( '2' === av5_get_option( 'shop-page-products-thumbnail-type', '2' ) ) {
			remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );
			add_action( 'av5_product_hover_replacement_image', 'woocommerce_template_loop_product_link_open', 5 );
			add_action( 'av5_product_hover_replacement_image', 'woocommerce_template_loop_product_thumbnail' );
			add_action( 'av5_product_hover_replacement_image', 'woocommerce_template_loop_product_link_close', 15 );
			add_action( 'woocommerce_before_shop_loop_item_title', 'av5_template_loop_product_hover_thumbnails', 10 );
		}

		if ( av5_get_option( 'shop-page-product-filters', 1 ) || av5_get_option( 'shop-page-hide-default-order', 0 ) ) {
			remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );
			remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );
		}
		switch ( av5_get_option( 'product-pages-reviews-position', '1' ) ) {
			case '2':
				add_filter( 'woocommerce_product_tabs', 'remove_woo_reviews_tab', 98 );
				add_action( 'woocommerce_after_single_product_summary', 'comments_template', 14 );
				break;
			case '3':
				add_filter( 'woocommerce_product_tabs', 'remove_woo_reviews_tab', 98 );
				add_action( 'woocommerce_after_single_product_summary', 'comments_template', 14 );
				break;
		}

		if ( av5_get_option( 'product-pages-upsell-products-carousel', false ) ) {
			remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );
			add_action( 'woocommerce_after_single_product_summary', 'av5_woocommerce_upsell_products_carousel', 20 );
		}

		if ( av5_get_option( 'product-pages-related-products-carousel', false ) ) {
			remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );
			add_action( 'woocommerce_after_single_product_summary', 'av5_woocommerce_output_related_products_carousel', 20 );
		}
	}
} // End if().
if ( ! function_exists( 'av5_get_product_hover_thumbnails' ) ) {

	/**
	 * Get the product thumbnail and first image in gallery.
	 *
	 * @global \WC_Product_Simple $product
	 * @param string|array $size Size for image.
	 * @return string
	 */
	function av5_get_product_hover_thumbnails( $size = 'woocommerce_thumbnail' ) {
		global $product;

		$image_size	 = apply_filters( 'single_product_archive_thumbnail_size', $size );
		$images		 = array();
		if ( $product ) {
			$images[]		 = $product->get_image( $image_size );
			$images			 = array_filter( $images );
			$attachment_ids	 = $product->get_gallery_image_ids();
			if ( is_array( $attachment_ids ) && ! empty( $attachment_ids ) ) {
				foreach ( $attachment_ids as $attachment_id ) {
					$image_link = wp_get_attachment_url( $attachment_id );
					if ( ! $image_link ) {
						continue;
					}
					$images[] = wp_get_attachment_image( $attachment_id, $image_size, false, array(
						'class'	 => sprintf( 'attachment-%1$s size-%1$s av5-second-hover-image', esc_attr( $image_size ) ),
						'style'	 => 'display:none',
					) );
					if ( 2 === count( $images ) ) {
						break;
					}
				}
			}
		}
		if ( 1 >= count( $images ) ) {
			return '';
		}
		$carousel = '<a href="' . esc_url( get_the_permalink() ) . '" class="av5-hover-thumbnails-wrapper">' . implode( '', $images ) . '</a>';

		return apply_filters( 'av5_product_hover_thumbnails', $carousel, $product, $images, $image_size );
	}
} // End if().
if ( ! function_exists( 'av5_template_loop_product_hover_thumbnails' ) ) {

	/**
	 * Get the product thumbnail and first image in gallery for the loop.
	 */
	function av5_template_loop_product_hover_thumbnails() {
		$hover = av5_get_product_hover_thumbnails();
		if ( empty( $hover ) ) {
			do_action( 'av5_product_hover_replacement_image' );
		} else {
			echo apply_filters( 'av5_template_loop_product_hover_thumbnails', $hover ); // WPCS: xss ok.
		}
	}
}
if ( ! function_exists( 'av5_get_product_carousel_thumbnails' ) ) {

	/**
	 * Get the product thumbnail and images in gallery.
	 *
	 * @global \WC_Product_Simple $product
	 * @param string|array $size Size for image.
	 */
	function av5_get_product_carousel_thumbnails( $size = 'woocommerce_thumbnail' ) {
		global $product;

		$image_size		 = apply_filters( 'single_product_archive_thumbnail_size', $size );
		$image_size_2x	 = apply_filters( 'single_product_archive_thumbnail_size_2x', $image_size . '_2x' );
		$gallery_image	 = array();
		$first_image_id	 = 0;
		if ( $product ) {
			$attachment_ids	 = array();
			$product_id		 = $product->get_id();
			if ( metadata_exists( 'post', $product_id, '_product_loop_image_gallery' ) ) {
				$product_image_gallery	 = get_post_meta( $product_id, '_product_loop_image_gallery', true );
				$attachment_ids			 = array_filter( explode( ',', $product_image_gallery ) );
			}
			if ( empty( $attachment_ids ) && apply_filters( 'av5_product_carousel_donotuse_gallery_image', true, $product ) ) {
				return '';
			}
			if ( empty( $attachment_ids ) ) {
				$attachment_ids = $product->get_gallery_image_ids();
				if ( has_post_thumbnail() ) {
					array_unshift( $attachment_ids, $product->get_image_id() );
				}
			}
			if ( $attachment_ids ) {
				foreach ( $attachment_ids as $attachment_id ) {
					$attr		 = array(
						'class' => 'owl-lazy av5-product-gallery__image',
					);
					if ( $image_link	 = wp_get_attachment_image_src( $attachment_id, $image_size_2x ) ) {
						$attr['data-src-retina'] = $image_link[0];
					}
					$image_link = wp_get_lazy_attachment_image( $attachment_id, $image_size, false, $attr, false );
					if ( ! $image_link ) {
						continue;
					}
					$gallery_image[] = $image_link;
				}
			}
		}
		if ( 1 > count( $gallery_image ) ) {
			return '';
		}
		$gallery_image	 = apply_filters( 'av5_product_carousel_thumbnails', $gallery_image, $product, $size );
		$first_image_id	 = apply_filters( 'av5_product_carousel_first_image', $first_image_id, $product, $size );
		$carousel		 = wc_get_template_html( 'loop/thumbnails-carousel.php', compact( 'product', 'gallery_image', 'image_size' ) );
		return apply_filters( 'av5_product_carousel', $carousel, $product, $gallery_image, $image_size );
	}
} // End if().
if ( ! function_exists( 'av5_template_loop_product_carousel_thumbnails' ) ) {

	/**
	 * Get the product thumbnail and images in gallery for the loop.
	 */
	function av5_template_loop_product_carousel_thumbnails() {
		$carousel = av5_get_product_carousel_thumbnails();
		if ( empty( $carousel ) ) {
			do_action( 'av5_product_carousel_replacement_image' );
		} else {
			echo apply_filters( 'av5_template_loop_product_carousel_thumbnails', $carousel ); // WPCS: xss ok.
		}
	}
}
if ( ! function_exists( 'av5_image_size_init' ) ) {

	/**
	 * Add support image size shop_catalog_2x
	 */
	function av5_image_size_init() {
		$gallery_thumbnail	 = wc_get_image_size( 'gallery_thumbnail' );
		$cropping			 = get_option( 'woocommerce_thumbnail_cropping', '1:1' );

		add_image_size( 'woocommerce_gallery_thumbnail_not_crop', $gallery_thumbnail['width'], $gallery_thumbnail['height'], 'uncropped' !== $cropping );
	}
}
if ( ! function_exists( 'av5_ajax_add_to_cart' ) ) {

	/**
	 * AJAX add to cart.
	 *
	 * @see WC_AJAX::add_to_cart();
	 * @see WC_Form_Handler::add_to_cart_action();
	 * @throws Exception If post not exist.
	 */
	function av5_ajax_add_to_cart() {
		ob_start();

		$product_id			 = apply_filters( 'woocommerce_add_to_cart_product_id', absint( $_POST['product_id'] ) ); // @codingStandardsIgnoreLine WordPress.VIP.ValidatedSanitizedInput.InputNotValidated
		$was_added_to_cart	 = false;
		$adding_to_cart		 = wc_get_product( $product_id );

		if ( ! $adding_to_cart || empty( $_REQUEST['quantity'] ) ) { // WPCS: input var ok.
			return;
		}

		$add_to_cart_handler = apply_filters( 'woocommerce_add_to_cart_handler', $adding_to_cart->get_type(), $adding_to_cart );

		if ( 'variable' === $add_to_cart_handler || 'variation' === $add_to_cart_handler ) {
			$was_error_to_cart = false;
			try {
				$variation_id		 = empty( $_REQUEST['variation_id'] ) ? '' : absint( wp_unslash( $_REQUEST['variation_id'] ) ); // WPCS: input var ok.
				$quantity			 = empty( $_REQUEST['quantity'] ) ? 1 : wc_stock_amount( wp_unslash( $_REQUEST['quantity'] ) ); // WPCS: input var ok. sanitization ok.
				$missing_attributes	 = array();
				$variations			 = array();

				// If the $product_id was in fact a variation ID, update the variables.
				if ( $adding_to_cart->is_type( 'variation' ) ) {
					$variation_id	 = $product_id;
					$product_id		 = $adding_to_cart->get_parent_id();
					$adding_to_cart	 = wc_get_product( $product_id );

					if ( ! $adding_to_cart ) {
						$was_error_to_cart = true;
					}
				}

				// If no variation ID is set, attempt to get a variation ID from posted attributes.
				if ( empty( $variation_id ) ) {
					$data_store		 = WC_Data_Store::load( 'product' );
					$variation_id	 = $data_store->find_matching_product_variation( $adding_to_cart, array_map( 'sanitize_title', wp_unslash( $_REQUEST ) ) ); // WPCS: input var ok.
				}

				// Validate the attributes.
				if ( empty( $variation_id ) ) {
					throw new Exception( esc_html__( 'Please choose product options&hellip;', 'woocommerce' ) );
				}

				$variation_data = wc_get_product_variation_attributes( $variation_id );

				foreach ( $adding_to_cart->get_attributes() as $attribute ) {
					if ( ! $attribute['is_variation'] ) {
						continue;
					}

					// Get valid value from variation data.
					$taxonomy	 = 'attribute_' . sanitize_title( $attribute['name'] );
					$valid_value = isset( $variation_data[ $taxonomy ] ) ? $variation_data[ $taxonomy ] : '';

					/**
					 * If the attribute value was posted, check if it's valid.
					 *
					 * If no attribute was posted, only error if the variation has an 'any' attribute which requires a value.
					 */
					if ( isset( $_REQUEST[ $taxonomy ] ) ) { // WPCS: input var ok.
						if ( $attribute['is_taxonomy'] ) {
							// Don't use wc_clean as it destroys sanitized characters.
							$value = sanitize_title( wp_unslash( $_REQUEST[ $taxonomy ] ) ); // WPCS: input var ok.
						} else {
							$value = wc_clean( wp_unslash( $_REQUEST[ $taxonomy ] ) ); // WPCS: input var ok. sanitization ok.
						}

						// Allow if valid or show error.
						if ( $valid_value === $value ) {
							$variations[ $taxonomy ] = $value;
						} elseif ( '' === $valid_value && in_array( $value, $attribute->get_slugs() ) ) {
							// If valid values are empty, this is an 'any' variation so get all possible values.
							$variations[ $taxonomy ] = $value;
						} else {
							throw new Exception( sprintf( esc_html__( 'Invalid value posted for %s', 'woocommerce' ), wc_attribute_label( $attribute['name'] ) ) );
						}
					} elseif ( '' === $valid_value ) {
						$missing_attributes[] = wc_attribute_label( $attribute['name'] );
					}
				}
				if ( ! empty( $missing_attributes ) ) {
					throw new Exception( sprintf( _n( '%s is a required field', '%s are required fields', count( $missing_attributes ), 'woocommerce' ), wc_format_list_of_items( $missing_attributes ) ) );
				}
			} catch ( Exception $e ) {
				wc_add_notice( $e->getMessage(), 'error' );
				$was_error_to_cart = true;
			} // End try().
			if ( ! $was_error_to_cart ) {
				$passed_validation = apply_filters( 'woocommerce_add_to_cart_validation', true, $product_id, $quantity, $variation_id, $variations );

				if ( $passed_validation && false !== WC()->cart->add_to_cart( $product_id, $quantity, $variation_id, $variations ) ) {
					if ( 'yes' === get_option( 'woocommerce_cart_redirect_after_add' ) ) {
						wc_add_to_cart_message( array( $product_id => $quantity ), true );
					}
					$was_added_to_cart = true;
				}
			}
		} elseif ( 'grouped' === $add_to_cart_handler ) {
			if ( ! empty( $_REQUEST['quantity'] ) && is_array( $_REQUEST['quantity'] ) ) {  // @codingStandardsIgnoreLine WordPress.VIP.ValidatedSanitizedInput.InputNotValidated
				$added_to_cart	 = array();
				$quantity_set	 = false;

				foreach ( $_REQUEST['quantity'] as $item => $quantity ) {  // @codingStandardsIgnoreLine WordPress.VIP.ValidatedSanitizedInput.InputNotValidated
					if ( $quantity <= 0 ) {
						continue;
					}
					$quantity_set = true;

					// Add to cart validation.
					$passed_validation = apply_filters( 'woocommerce_add_to_cart_validation', true, $item, $quantity );

					// Suppress total recalculation until finished.
					remove_action( 'woocommerce_add_to_cart', array( WC()->cart, 'calculate_totals' ), 20, 0 );

					if ( $passed_validation && false !== WC()->cart->add_to_cart( $item, $quantity ) ) {
						$was_added_to_cart		 = true;
						$added_to_cart[ $item ]	 = $quantity;
					}

					add_action( 'woocommerce_add_to_cart', array( WC()->cart, 'calculate_totals' ), 20, 0 );
				}

				if ( ! $was_added_to_cart && ! $quantity_set ) {
					wc_add_notice( esc_html__( 'Please choose the quantity of items you wish to add to your cart&hellip;', 'woocommerce' ), 'error' );
				} elseif ( $was_added_to_cart ) {
					if ( 'yes' === get_option( 'woocommerce_cart_redirect_after_add' ) ) {
						wc_add_to_cart_message( $added_to_cart );
					}
					WC()->cart->calculate_totals();
					$was_added_to_cart = true;
				}
			}
		} elseif ( has_action( 'woocommerce_add_to_cart_handler_' . $add_to_cart_handler ) ) {
			do_action( 'woocommerce_add_to_cart_handler_' . $add_to_cart_handler ); // Custom handler.
		} else {
			$quantity			 = empty( $_REQUEST['quantity'] ) ? 1 : wc_stock_amount( $_REQUEST['quantity'] );  // @codingStandardsIgnoreLine WordPress.VIP.ValidatedSanitizedInput.InputNotValidated
			$passed_validation	 = apply_filters( 'woocommerce_add_to_cart_validation', true, $product_id, $quantity );
			if ( $passed_validation && false !== WC()->cart->add_to_cart( $product_id, $quantity ) ) {
				if ( 'yes' === get_option( 'woocommerce_cart_redirect_after_add' ) ) {
					wc_add_to_cart_message( array( $product_id => $quantity ), true );
				}
				$was_added_to_cart = true;
			}
		} // End if().
		// If we added the product to the cart we can now optionally do a redirect.
		if ( $was_added_to_cart && 0 === wc_notice_count( 'error' ) ) {

			do_action( 'woocommerce_ajax_added_to_cart', $product_id );

			// Return fragments.
			WC_AJAX::get_refreshed_fragments();
		} else {

			// If there was an error adding to the cart, redirect to the product page to show any errors.
			$data = array(
				'error'			 => true,
				'product_url'	 => apply_filters( 'woocommerce_cart_redirect_after_error', get_permalink( $product_id ), $product_id ),
			);

			wp_send_json( $data );
		}
	}
} // End if().
if ( ! function_exists( 'av5_title_area_catmeta' ) ) {

	/**
	 * Category meta for title area
	 *
	 * @global \WP_Post $post
	 * @param string $post_type Theme post type.
	 */
	function av5_title_area_catmeta( $post_type = 'posts' ) {
		if ( 'product' === $post_type ) {
			$product_meta	 = av5_get_option_titlearea( 'titlearea-product-meta', false );
			$product_meta	 = true;
			if ( $product_meta ) {
				remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
				global $post;
				$product = wc_get_product( $post );
				wc_get_template( 'single-product/meta-title-area.php', array( 'product' => $product ) );
			}
		}
	}
}
if ( ! function_exists( 'av5_title_area_product_catmeta' ) ) {

	/**
	 * Category product meta for title area
	 *
	 * @param string $post_type Theme post type.
	 */
	function av5_title_area_product_catmeta( $post_type = 'posts' ) {
		if ( (is_shop() || is_product_category()) && (bool) av5_get_option( 'products-titlearea-categories' ) ) {
			$product_meta = av5_get_option_titlearea( 'titlearea-meta', false );
			if ( $product_meta ) {
				wc_get_template( 'single-product/titlearea/categories.php' );
			}
		}
	}
}
if ( ! function_exists( 'override_wishlist_button' ) ) {

	/**
	 * Override Wishlist button
	 */
	function override_wishlist_button() {
		if ( av5_get_option( 'shop-page-override_ti_wishlist' ) ) {
			remove_action( 'woocommerce_after_shop_loop_item', 'tinvwl_view_addto_htmlloop', 10 );
			remove_action( 'woocommerce_after_shop_loop_item', 'tinvwl_view_addto_htmlloop', 9 );
			remove_action( 'woocommerce_before_shop_loop_item', 'tinvwl_view_addto_htmlloop', 9 );
		}
	}
}
if ( ! function_exists( 'av5_product_page_content' ) ) {

	/**
	 * Product page content
	 */
	function av5_product_page_content() {
		if ( av5_get_meta( 'product-page-content-after-tabs' ) ) {
			?>
			<div id="product-display-area" class="clearfix">
				<div class="container">
					<?php the_content(); ?>
				</div>		
			</div>                
			<?php
		}
	}
}
if ( ! function_exists( 'change_breadcrumb_delimiter' ) ) {

	/**
	 * Change the breadcrumb delimeter
	 *
	 * @param array $defaults Argumets for breadcrumb.
	 * @return string
	 */
	function change_breadcrumb_delimiter( $defaults ) {
		$defaults['delimiter'] = '<div class="h-divider"></div>';
		return $defaults;
	}
}
if ( ! function_exists( 'remove_cart_breadcrumbs' ) ) {

	/**
	 * Remove cart breadcrumbs
	 */
	function remove_cart_breadcrumbs() {
		if ( is_cart() || is_checkout() ) {
			remove_action( 'woo_main_before', 'woo_display_breadcrumbs', 10 );
		}
	}
}
if ( ! function_exists( 'remove_additional_information_product_tab' ) ) {

	/**
	 * Remove information tab
	 *
	 * @param array $tabs Current tabs.
	 * @return array
	 */
	function remove_additional_information_product_tab( $tabs ) {
		unset( $tabs['additional_information'] );
		return $tabs;
	}
}
if ( ! function_exists( 'remove_description_product_tab' ) ) {

	/**
	 * Remove description tab
	 *
	 * @param array $tabs Current tabs.
	 * @return array
	 */
	function remove_description_product_tab( $tabs ) {
		if ( isset( $tabs['description'] ) ) {
			unset( $tabs['description'] );
		}
		return $tabs;
	}
}
if ( ! function_exists( 'av5_remove_description_product_tab_meta' ) ) {

	/**
	 * Remove description tab
	 *
	 * @param array $tabs Current tabs.
	 * @return array
	 */
	function av5_remove_description_product_tab_meta( $tabs ) {
		if ( isset( $tabs['description'] ) && av5_get_meta( 'product-page-content-after-tabs' ) && ! av5_get_meta( 'product-page-description-content', '' ) ) {
			unset( $tabs['description'] );
		}
		return $tabs;
	}
}
if ( ! function_exists( 'av5_related_products_args' ) ) {

	/**
	 * Change reletad prudcts
	 *
	 * @param array $args Related products arguments.
	 * @return array
	 */
	function av5_related_products_args( $args ) {
		$posts_per_page	 = absint( av5_get_option( 'related-products-amount' ) );
		$columns	 = absint( av5_get_option( 'related-products-grid' ) );
		if ( $posts_per_page > 0 ) {
			$args['posts_per_page']	 = $posts_per_page; // 4 related products
			$args['columns']		 = $columns;
		} else {
			$args['posts_per_page']	 = 3;
			$args['columns']		 = 3;
		}
		return $args;
	}
}
if ( ! function_exists( 'av5_woocommerce_show_vertical_product_thumbnails' ) ) {

	/**
	 * Output the product thumbnails.
	 *
	 * @subpackage	Product
	 */
	function av5_woocommerce_show_vertical_product_thumbnails() {
		wc_get_template( 'single-product/product-thumbnails.php', array( 'position' => 'vertical' ) );
	}
}
if ( ! function_exists( 'av5_woocommerce_shopping_cart_counter' ) ) {

	/**
	 * Add counter for shopping cart.
	 *
	 * @param array $fragments AJAX fragments.
	 * @return array
	 */
	function av5_woocommerce_shopping_cart_counter( $fragments = array() ) {

		$fragments['span.widget_shopping_cart_counter'] = '<span class="widget_shopping_cart_counter cart-num text ' . ( WC()->cart->is_empty() ? 'woocommerce_shopping_cart_empty' : '' ) . '">' . WC()->cart->get_cart_contents_count() . '</span>';

		return $fragments;
	}
}
if ( ! function_exists( 'product_page_breadcrumbs_show' ) ) {

	/**
	 * Add breadcrubs for product page
	 */
	function product_page_breadcrumbs_show() {
		if ( av5_get_option( 'product-pages-breadcrumbs' ) ) {
			add_action( 'av5-woocommerce_before_single_product', 'woocommerce_breadcrumb' );
		}
	}
}
if ( ! function_exists( 'av5_woocommerce_product_bar' ) ) {

	/**
	 * Add product bar to the bottom of the product page
	 */
	function av5_woocommerce_product_bar() {
		wc_get_template_part( 'single-product/product-bar' );
	}
}
if ( ! function_exists( 'av5_woocommerce_product_page_content_after' ) ) {

	/**
	 * Add page content after tabs
	 */
	function av5_woocommerce_product_page_content_after() {
		if ( av5_get_meta( 'product-page-content-after-tabs' ) && ! $product_page_description ) {
			add_filter( 'woocommerce_product_tabs', 'remove_description_product_tab', 98 );
		}
	}
}
if ( ! function_exists( 'av5_woocommerce_product_page_second_description' ) ) {

	/**
	 * Show second short description for product page with centered layouts
	 *
	 * @global \WP_Post $post
	 */
	function av5_woocommerce_product_page_second_description() {
		global $post;

		echo av5_get_meta( 'product-page-second-description-content', null, $post->ID ); // WPCS: xss ok.
	}
}
if ( ! function_exists( 'reposition_woo_meta' ) ) {

	/**
	 * Product page meta
	 */
	function reposition_woo_meta() {
		if ( av5_get_option( 'product-pages-layout' ) && av5_get_option( 'product-pages-meta-information' ) ) {
			add_action( 'av5-woocommerce_single_product_summary-left', 'woocommerce_template_single_meta', 60 );
		}
	}
}
if ( ! function_exists( 'av5_woocommerce_product_navigation' ) ) {

	/**
	 * Product page navigation
	 *
	 * @global \WP_Post $post
	 */
	function av5_woocommerce_product_navigation() {
		global $post;
		$has_cat = get_the_terms( $post->ID, 'product_cat' );
		if ( 0 !== $has_cat ) {
			?>
			<div class="product-navigation">
				<div class="product-navigation-previous"><?php previous_post_link( '%link', '<i class="fa-chevron-left"></i>', true, '', 'product_cat' ); ?></div>
				<div class="product-navigation-next"><?php next_post_link( '%link', '<i class="fa-chevron-right"></i>', true, '', 'product_cat' ); ?></div>
			</div><?php
		}
	}
}
if ( ! function_exists( 'reposition_woo_messages' ) ) {

	/**
	 * Reposition woocommerce messages on product page
	 */
	function reposition_woo_messages() {
		/* Single Product */
		remove_action( 'woocommerce_before_single_product', 'wc_print_notices', 10 );
		add_action( 'av5-woocommerce_before_single_product', 'wc_print_notices', 1 );
	}
}
if ( ! function_exists( 'remove_woo_reviews_tab' ) ) {

	/**
	 * Remove Woo review tab
	 *
	 * @param array $tabs Current tabs.
	 * @return array
	 */
	function remove_woo_reviews_tab( $tabs ) {
		unset( $tabs['reviews'] );
		return $tabs;
	}
}
if ( ! function_exists( 'av5_quick_view' ) ) {

	/**
	 * Woocommerce Quickview
	 */
	function av5_quick_view() {
		$product_id = absint( $_REQUEST['product_id'] ); // @codingStandardsIgnoreLine WordPress.VIP.ValidatedSanitizedInput.InputNotValidated
		if ( $product_id ) {
			query_posts( array(
				'post_type'		 => 'product',
				'posts_per_page' => 1,
				'post__in'		 => array( $product_id ),
			) );
			while ( have_posts() ) {
				the_post();
				do_action( 'av5_woocommerce_before_quickview' );
				wc_get_template( 'quickview-content-single-product.php' );
				do_action( 'av5_woocommerce_after_quickview' );
			}
			wp_reset_query();
		}

		die();
	}
}
if ( ! function_exists( 'woocommerce_template_loop_category_button' ) ) {

	/**
	 * Add shop button after category title
	 */
	function woocommerce_template_loop_category_button() {
		?>
		<span class="button av5-btn--single-underline"><?php esc_html_e( 'Shop now', '5th-avenue' ) ?></span>
		<?php
	}
}
if ( ! function_exists( 'after_add_to_cart_link' ) ) {

	/**
	 * Custom popup links after add to cart button
	 */
	function after_add_to_cart_link() {
		$meta		 = av5_get_meta( 'popup-link' );
		$popup_links = array();
		if ( is_array( $meta ) ) {
			$index = 0;
			if ( ! empty( $meta ) ) {
				foreach ( $meta as $value ) {
					if ( ! isset( $value['label'] ) || empty( $value['label'] ) ) {
						continue;
					}
					$slug = '';
					if ( isset( $value['slug'] ) ) {
						$slug = $value['slug'];
					}
					$slug = preg_replace( '/[^a-zA-Z0-9-_]/', '', $slug );
					if ( empty( $slug ) ) {
						$index++;
						$slug = $index;
					}
					$slug			 = 'popup-link-' . $slug;
					$value['slug'] = $slug;

					$popup_links[ $slug ] = $value;
				}
			}
		}

		$popup_links = apply_filters( 'av5_popup_links', $popup_links );

		if ( is_array( $popup_links ) && ! empty( $popup_links ) ) {
			echo '<div class="av5-popup-links-wrapper">';
			foreach ( $popup_links as $popup_link ) {
				wc_get_template( 'single-product/popup-links.php', apply_filters( 'av5_popup_link_content', $popup_link ) );
			}
			echo '</div>';
		}
	}
} // End if().
if ( ! function_exists( 'av5_woocommerce_upsell_products_carousel' ) ) {

	/**
	 * Output the related products carousel.
	 *
	 * @see woocommerce_upsell_display
	 */
	function av5_woocommerce_upsell_products_carousel() {
		$related_amount			 = absint( av5_get_option( 'related-products-amount', 3 ) );
		$related_columns		 = absint( av5_get_option( 'related-products-grid', 3 ) );
		$related_columns_mobile	 = absint( av5_get_option( 'shop-page-products-grid-mobile', 2 ) );
		if ( $related_amount <= 0 ) {
			$related_amount = 3;
		}
		if ( $related_columns <= 0 ) {
			$related_columns = 3;
		}
		if ( $related_columns_mobile <= 0 ) {
			$related_columns_mobile = 2;
		}
		if ( $related_columns > 3 ) {
			$related_columns_tablet = 3;
		} elseif ( $related_columns > 4 ) {
			$related_columns_tablet = 4;
		} else {
			$related_columns_tablet = $related_columns;
		}
		printf( '<div class="av5-upsell-carousel" data-column-desktop-small="%1$s" data-column-desktop="%1$s" data-column-table="%2$s" data-column-mobile="%3$s">', $related_columns, $related_columns_tablet, $related_columns_mobile ); // WPCS: xss ok.
		woocommerce_upsell_display( $related_amount, $related_columns );
		echo '</div>';
	}
}
if ( ! function_exists( 'av5_woocommerce_output_related_products_carousel' ) ) {

	/**
	 * Output the related products carousel.
	 *
	 * @see woocommerce_output_related_products
	 */
	function av5_woocommerce_output_related_products_carousel() {
		$related_columns		 = absint( av5_get_option( 'related-products-grid', 3 ) );
		$related_columns_mobile	 = absint( av5_get_option( 'shop-page-products-grid-mobile', 2 ) );
		if ( $related_columns <= 0 ) {
			$related_columns = 3;
		}
		if ( $related_columns_mobile <= 0 ) {
			$related_columns_mobile = 2;
		}
		if ( $related_columns > 3 ) {
			$related_columns_tablet = 3;
		} elseif ( $related_columns > 4 ) {
			$related_columns_tablet = 4;
		} else {
			$related_columns_tablet = $related_columns;
		}
		printf( '<div class="av5-related-carousel" data-column-desktop-small="%1$s" data-column-desktop="%1$s" data-column-table="%2$s" data-column-mobile="%3$s">', $related_columns, $related_columns_tablet, $related_columns_mobile ); // WPCS: xss ok.
		woocommerce_output_related_products();
		echo '</div>';
	}
}
if ( ! function_exists( 'av5_woocommerce_filter_move_to_title' ) ) {

	/**
	 * Filters in title area
	 */
	function av5_woocommerce_filter_move_to_title() {
		remove_action( 'woocommerce_before_shop_loop', array( 'AV5_Products_Filter', 'output' ), 5 );
		add_action( 'av5_title_area_after_title', array( 'AV5_Products_Filter', 'output' ), 100 );
		add_action( 'av5_title_area_hero_after_title', array( 'AV5_Products_Filter', 'output' ), 100 );
	}
}
if ( ! function_exists( 'av5_woocommerce_continue_shopping_cart' ) ) {

	/**
	 * Continue shopping button on cart page
	 */
	function av5_woocommerce_continue_shopping_cart() {
		echo '<div class="continue-shopping"><p> <a href="' . esc_url( get_permalink( wc_get_page_id( 'shop' ) ) ) . '">' . esc_html__( 'Continue shopping', '5th-avenue' ) . '</a></p></div>'; // WPCS: xss ok.
	}
}
if ( ! function_exists( 'av5_woocommerce_cross_sell_display' ) ) {

	/**
	 * Show hide cross sells on cart page
	 */
	function av5_woocommerce_cross_sell_display() {
		remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_display' );
		if ( av5_get_option( 'cart-crossells-products' ) ) {
			add_action( 'woocommerce_after_cart', 'woocommerce_cross_sell_display', 50 );
		}
	}
}
if ( ! function_exists( 'av5_empty_cart_content' ) ) {

	/**
	 * Additional content after empty cart
	 */
	function av5_empty_cart_content() {
		if ( av5_get_option( 'empty-cart-content' ) ) {
			echo do_shortcode( av5_get_option( 'empty-cart-content' ) );
		}
	}
}
if ( ! function_exists( 'av5_woocommerce_login' ) ) {

	/**
	 * Process the login form.
	 *
	 * @see WC_Form_Handler::process_login
	 * @throws Exception If incorrected login or password.
	 */
	function av5_woocommerce_login() {
		$nonce_value = isset( $_POST['av5__wpnonce'] ) ? $_POST['av5__wpnonce'] : '';  // @codingStandardsIgnoreLine WordPress.VIP.ValidatedSanitizedInput.InputNotValidated
		$nonce_value = isset( $_POST['av5_woocommerce-login-nonce'] ) ? $_POST['av5_woocommerce-login-nonce'] : $nonce_value;  // @codingStandardsIgnoreLine WordPress.VIP.ValidatedSanitizedInput.InputNotValidated
		if ( ! empty( $_POST['login'] ) && wp_verify_nonce( $nonce_value, 'woocommerce-login' ) ) {
			try {
				$creds = array(
					'user_login'	 => trim( $_POST['username'] ),  // @codingStandardsIgnoreLine WordPress.VIP.ValidatedSanitizedInput.InputNotValidated
					'user_password'	 => $_POST['password'],  // @codingStandardsIgnoreLine WordPress.VIP.ValidatedSanitizedInput.InputNotValidated
					'remember'		 => isset( $_POST['rememberme'] ),
				);

				$validation_error	 = new WP_Error();
				$validation_error	 = apply_filters( 'woocommerce_process_login_errors', $validation_error, $_POST['username'], $_POST['password'] );  // @codingStandardsIgnoreLine WordPress.VIP.ValidatedSanitizedInput.InputNotValidated

				if ( $validation_error->get_error_code() ) {
					throw new Exception( '<strong>' . esc_html__( 'Error:', 'woocommerce' ) . '</strong> ' . $validation_error->get_error_message() );
				}

				if ( empty( $creds['user_login'] ) ) {
					throw new Exception( '<strong>' . esc_html__( 'Error:', 'woocommerce' ) . '</strong> ' . esc_html__( 'Username is required.', 'woocommerce' ) );
				}

				// On multisite, ensure user exists on current site, if not add them before allowing login.
				if ( is_multisite() ) {
					$user_data = get_user_by( is_email( $creds['user_login'] ) ? 'email' : 'login', $creds['user_login'] );

					if ( $user_data && ! is_user_member_of_blog( $user_data->ID, get_current_blog_id() ) ) {
						add_user_to_blog( get_current_blog_id(), $user_data->ID, 'customer' );
					}
				}

				// Perform the login.
				$user = wp_signon( apply_filters( 'woocommerce_login_credentials', $creds ), is_ssl() );

				if ( is_wp_error( $user ) ) {
					$message = $user->get_error_message();
					$message = str_replace( '<strong>' . esc_html( $creds['user_login'] ) . '</strong>', '<strong>' . esc_html( $creds['user_login'] ) . '</strong>', $message );
					throw new Exception( $message );
				} else {

					if ( ! empty( $_POST['redirect'] ) ) { // WPCS: input var ok.
						$redirect = $_POST['redirect'];  // @codingStandardsIgnoreLine WordPress.VIP.ValidatedSanitizedInput.InputNotValidated
					} elseif ( wc_get_raw_referer() ) {
						$redirect = wc_get_raw_referer();
					} else {
						$redirect = wc_get_page_permalink( 'myaccount' );
					}

					wp_send_json_success( wp_validate_redirect( apply_filters( 'woocommerce_login_redirect', remove_query_arg( 'wc_error', $redirect ), $user ), wc_get_page_permalink( 'myaccount' ) ) );
				}
			} catch ( Exception $e ) {
				wp_send_json_error( '<div class="woocommerce-error">' . $e->getMessage() . '</div>' );
			} // End try().
		} else {
			wp_send_json_error();
		} // End if().
	}
} // End if().
if ( ! function_exists( 'av5_woocommerce_register' ) ) {

	/**
	 * Process the registration form.
	 *
	 * @see WC_Form_Handler::process_registration
	 * @throws Exception If incorrected email or password.
	 */
	function av5_woocommerce_register() {
		$nonce_value = isset( $_POST['av5__wpnonce'] ) ? $_POST['av5__wpnonce'] : '';  // @codingStandardsIgnoreLine WordPress.VIP.ValidatedSanitizedInput.InputNotValidated
		$nonce_value = isset( $_POST['av5_woocommerce-register-nonce'] ) ? $_POST['av5_woocommerce-register-nonce'] : $nonce_value;  // @codingStandardsIgnoreLine WordPress.VIP.ValidatedSanitizedInput.InputNotValidated

		if ( ! empty( $_POST['register'] ) && wp_verify_nonce( $nonce_value, 'woocommerce-register' ) ) { // WPCS: input var ok.
			$username	 = 'no' === get_option( 'woocommerce_registration_generate_username' ) ? $_POST['username'] : '';  // @codingStandardsIgnoreLine WordPress.VIP.ValidatedSanitizedInput.InputNotValidated
			$password	 = 'no' === get_option( 'woocommerce_registration_generate_password' ) ? $_POST['password'] : '';  // @codingStandardsIgnoreLine WordPress.VIP.ValidatedSanitizedInput.InputNotValidated
			$email		 = $_POST['email']; // WPCS: input var ok.

			try {
				$validation_error	 = new WP_Error();
				$validation_error	 = apply_filters( 'woocommerce_process_registration_errors', $validation_error, $username, $password, $email );

				if ( $validation_error->get_error_code() ) {
					throw new Exception( $validation_error->get_error_message() );
				}

				$new_customer = wc_create_new_customer( sanitize_email( $email ), wc_clean( $username ), $password );

				if ( is_wp_error( $new_customer ) ) {
					throw new Exception( $new_customer->get_error_message() );
				}

				if ( apply_filters( 'woocommerce_registration_auth_new_customer', true, $new_customer ) ) {
					wc_set_customer_auth_cookie( $new_customer );
				}

				if ( ! empty( $_POST['redirect'] ) ) { // WPCS: input var ok.
					$redirect = wp_sanitize_redirect( $_POST['redirect'] );  // @codingStandardsIgnoreLine WordPress.VIP.ValidatedSanitizedInput.InputNotValidated
				} elseif ( wc_get_raw_referer() ) {
					$redirect = wc_get_raw_referer();
				} else {
					$redirect = wc_get_page_permalink( 'myaccount' );
				}

				wp_send_json_success( wp_validate_redirect( apply_filters( 'woocommerce_registration_redirect', $redirect ), wc_get_page_permalink( 'myaccount' ) ) );
			} catch ( Exception $e ) {
				wp_send_json_error( '<div class="woocommerce-error"><strong>' . esc_html__( 'Error:', 'woocommerce' ) . '</strong> ' . $e->getMessage() . '</div>' );
			}
		} else {
			wp_send_json_error();
		} // End if().
	}
} // End if().
if ( ! function_exists( 'av5_woocommerce_product_share' ) ) {

	/**
	 * Share woo product
	 *
	 * @global \WP_Post $post
	 */
	function av5_woocommerce_product_share() {
		if ( av5_get_option( 'product-pages-social-share' ) ) {
			global $post;
			$has_cat = get_the_terms( $post->ID, 'product_cat' );
			if ( 0 !== $has_cat ) {
				?>
				<ul class="av5-product-share">
					<li><a target="_blank" class="av5-social-button" href="<?php
						$_post = get_post();
						echo esc_url( 'https://twitter.com/intent/tweet?' . http_build_query( array( // WPCS: xss ok.
							'text'	 => $_post->post_title,
							'url'	 => get_permalink(),
						) ) );
						?>"><i class="fa fa-twitter"></i> </a></li>
					<li><a target="_blank" class="av5-social-button" href="<?php echo esc_url( 'https://www.facebook.com/sharer/sharer.php?' . http_build_query( array( 'url' => get_permalink() ) ) ); ?>"><i class="fa fa-facebook"></i> </a></li>
					<?php list( $image ) = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' ); ?>
					<li><a target="_blank" class="av5-social-button" href="<?php
						echo esc_url( 'http://pinterest.com/pin/create/button/?' . http_build_query( array(
							'url'	 => get_permalink(),
							'media'	 => $image,
						) ) );
						?>"><i class="fa fa-pinterest"></i> </a></li>
					<li><a target="_blank" class="av5-social-button" href="<?php echo esc_url( 'https://plus.google.com/share?' . http_build_query( array( 'url' => get_permalink() ) ) ); ?>"><i class="fa fa-google-plus"></i> </a></li>
				</ul>
				<?php
			}
		}
	}
} // End if().
if ( ! function_exists( 'av5_woocommerce_show_product_images_sticky' ) ) {

	/**
	 * Output the product image before the single product summary.
	 */
	function av5_woocommerce_show_product_images_sticky() {
		wc_get_template( 'single-product/product-image-sticky.php' );
	}
} // End if().

