<?php
/**
 * Size guide for woocommerce product attribute
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

/**
 * Size guide for woocommerce product attribute
 */
class AV5_SizeGuide {

	/**
	 * Initialization of the functional
	 */
	public static function init() {
		add_action( 'woocommerce_after_add_attribute_fields', array( __CLASS__, 'admin_field_add' ) );
		add_action( 'woocommerce_after_edit_attribute_fields', array( __CLASS__, 'admin_field_edit' ) );
		add_action( 'woocommerce_attribute_added', array( __CLASS__, 'save_field' ) );
		add_action( 'woocommerce_attribute_updated', array( __CLASS__, 'save_field' ) );
		add_filter( 'woocommerce_attribute_deleted', array( __CLASS__, 'delete_field' ), 10, 3 );
		add_filter( 'woocommerce_dropdown_variation_attribute_options_html', array( __CLASS__, 'output' ), 1000, 2 );
	}

	/**
	 * The field for adding content
	 */
	public static function admin_field_add() {
		?>
		<div class="form-field">
			<label for="av5_attribute_sizeguide"><?php esc_html_e( 'Size Guide Content', '5th-avenue' ); ?></label>
			<?php
			wp_editor( '', 'av5_attribute_sizeguide', array(
				'editor_class'	 => '',
				'textarea_rows'	 => 10,
				'teeny'			 => true,
			) );
			?>
		</div>	
		<?php
	}

	/**
	 * Field for editing content
	 */
	public static function admin_field_edit() {
		$edit		 = absint( $_GET['edit'] ); // @codingStandardsIgnoreLine WordPress.VIP.ValidatedSanitizedInput.InputNotValidated
		$attribute	 = wc_get_attribute( $edit );
		$value		 = get_option( 'av5_sizeguide_' . $attribute->slug, '' );
		?>
		<tr class="form-field form-required">
			<th scope="row" valign="top">
				<label for="av5_attribute_sizeguide"><?php esc_html_e( 'Size Guide Content', '5th-avenue' ); ?></label>
			</th>
			<td>
				<?php
				wp_editor( $value, 'av5_attribute_sizeguide', array(
					'editor_class'	 => '',
					'textarea_rows'	 => 10,
					'teeny'			 => true,
				) );
				?>
			</td>
		</tr>	
		<?php
	}

	/**
	 * Saving the content field
	 *
	 * @param integer $id Atribute ID.
	 */
	public static function save_field( $id ) {
		$value		 = filter_input( INPUT_POST, 'av5_attribute_sizeguide', FILTER_DEFAULT );
		$attribute	 = wc_get_attribute( $id );
		update_option( 'av5_sizeguide_' . $attribute->slug, $value );
	}

	/**
	 * Deleting the content field
	 *
	 * @param integer $id Atribute ID.
	 * @param string  $name  Atribute name.
	 * @param string  $taxonomy  Atribute slug.
	 */
	public static function delete_field( $id, $name, $taxonomy ) {
		delete_option( 'av5_sizeguide_' . $taxonomy );
	}

	/**
	 * Output of field information near its select element
	 *
	 * @param string $html HTML output.
	 * @param array  $args Array with data for dropdown attribute.
	 * @return string
	 */
	public static function output( $html, $args ) {
		$value = get_option( 'av5_sizeguide_' . $args['attribute'], '' );

		if ( ! empty( $value ) ) {
			$args['size_guide_content'] = $value;
			$html .= av5c_get_template_html( 'woocommerce/single-product/add-to-cart/variable-size-guide.php', $args );
		}

		return $html;
	}
}
