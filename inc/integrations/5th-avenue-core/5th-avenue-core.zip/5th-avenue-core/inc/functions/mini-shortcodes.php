<?php
/**
 * 5th-Avenue small shortcodes
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'av5_get_empty_space' ) ) {
	/**
	 * Create shortcode to output empty space with height value
	 *
	 * @param array $atts Attributes for shortcode.
	 * @return string
	 */
	function av5_get_empty_space( $atts ) {
		$a		 = shortcode_atts( array( 'height' => '30px' ), $atts );
		$content = '<div style="display:block; height:' . $a['height'] . '"></div>';
		return $content;
	}
} // End if().

if ( ! function_exists( 'av5_get_footer_menu' ) ) {
	/**
	 * Create shortcode to output footer menu
	 *
	 * @return string
	 */
	function av5_get_footer_menu() {
		return wp_nav_menu( array( 'menu' => 'footer-copyright-menu', 'theme_location' => 'footer-copyright-menu', 'echo' => false ) );
	}
} // End if().

if ( ! function_exists( 'av5_get_the_year' ) ) {
	/**
	 * Create shortcode to output year
	 *
	 * @return string
	 */
	function av5_get_the_year() {
		return date( 'Y' );
	}
} // End if().

if ( ! function_exists( 'av5_get_site_name' ) ) {
	/**
	 * Create shortcode to output site name
	 *
	 * @return string
	 */
	function av5_get_site_name() {
		return get_bloginfo( 'name' );
	}
} // End if().

$shortcodes = array(
	'site-name'		 => 'av5_get_site_name',
	'the-year'		 => 'av5_get_the_year',
	'footer-menu'	 => 'av5_get_footer_menu',
	'empty-space'	 => 'av5_get_empty_space',
);

foreach ( $shortcodes as $tag => $callback ) {
	add_shortcode( $tag, $callback );
}
