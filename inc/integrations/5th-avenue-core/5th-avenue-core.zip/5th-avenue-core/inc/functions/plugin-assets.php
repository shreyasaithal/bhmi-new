<?php
/**
 * 5th-Avenue theme assets
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

/**
 * Setup Styles and Scripts
 */
function av5c_scripts() {
	$suffix_js = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG || ! av5_get_option( 'min-js' ) ? '' : '.min';
	$suffix_style = defined( 'STYLE_DEBUG' ) && STYLE_DEBUG || ! av5_get_option( 'min-css' ) ? '' : '.min';
	// Main Styles.
	wp_enqueue_style( 'av5-core-main', AV5C_URL . 'assets/css/main' . $suffix_style . '.css', array(), '1.0.0', 'all' );

	wp_enqueue_script( 'jquery-pointparallax', AV5C_URL . 'assets/js/jquery.pointparallax' . $suffix_js . '.js', array( 'jquery' ), '1.0.2', true );
	wp_enqueue_script( 'av5-core-js', AV5C_URL . 'assets/js/main' . $suffix_js . '.js', array(
		'jquery',
		'jquery-pointparallax',
	), '1.0.0', true );

	if ( av5_is_woocommerce_activated() ) {
		if ( av5_get_option( 'shop-page-quickview', '0' ) ) {
			wp_enqueue_script( 'wc-add-to-cart-variation' );
			wp_enqueue_script( 'photoswipe-ui-default' );
			wp_enqueue_script( 'zoom' );
			add_action( 'wp_footer', 'woocommerce_photoswipe' );
		}

		wp_enqueue_script( 'av5-shop-js', AV5C_URL . 'assets/js/shop' . $suffix_js . '.js', array(
			'av5-js',
			'owl.carousel',
			'infinite-scroll',
			'waypoints',
			'jquery-hoverIntent',
			'jquery-validate',
		), '', true );
		wp_localize_script( 'av5-shop-js', 'av5_shopJS', array(
			'pagination_type'			 => av5_get_option( 'shop-listing-pagination-type', '' ),
			'loadin_animation'			 => av5_get_option( 'shop-listing-loadin-animation', 'none' ),
			'pagination_infinity_loader' => apply_filters( 'av5_shop_pagination_infinity_loader', '<div class="line-preloader"></div>' ),
			'pagination_load_more'		 => esc_js( apply_filters( 'av5_shop_pagination_load_more', esc_html__( 'Load More', '5th-avenue' ) ) ),
			'pagination_message'		 => esc_js( apply_filters( 'av5_shop_pagination_message', esc_html__( 'All products are loaded.', '5th-avenue' ) ) ),
			'product_ajax_addtocart'	 => (bool) av5_get_option( 'product-pages-ajax-addtocart' ),
			'wc_ajax_url'				 => WC_AJAX::get_endpoint( '%%endpoint%%' ),
			'owlcarousel'				 => array(
				'lazyLoad'			 => true,
				'autoplay'			 => false,
				'autoplayTimeout'	 => 5000,
				'autoplaySpeed'		 => false,
				'animateOut'		 => false,
				'animateIn'			 => false,
				'dots'				 => false,
				'nav'				 => false,
				'loop'				 => true,
				'nav'				 => true,
				'navText'			 => array(
					'<svg class="next-arrow" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 39 12"><line x1="23" y1="-0.5" x2="29.5" y2="6.5" stroke="#ffffff;"></line><line x1="23" y1="12.5" x2="29.5" y2="5.5" stroke="#ffffff;"></line></svg><span class="line"></span>',
					'<svg class="next-arrow" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 39 12"><line x1="23" y1="-0.5" x2="29.5" y2="6.5" stroke="#ffffff;"></line><line x1="23" y1="12.5" x2="29.5" y2="5.5" stroke="#ffffff;"></line></svg><span class="line"></span>',
				),
			),
			'quickview'					 => '1' == av5_get_option( 'shop-page-quickview', '0' ),
			'quickview_settings'		 => apply_filters( 'av5_shop_quickview_settings', array(
				'width'	 => '960',
				'height' => '550',
			) ),
			'validation_login'			 => array(
				'username' => esc_html__( 'Username is required.', '5th-avenue' ),
			),
			'validation_register'		 => array(
				'email'		 => array(
					'required'	 => esc_js( sprintf( esc_html__( '%s is a required field.', '5th-avenue' ), esc_html__( 'Email address', '5th-avenue' ) ) ),
					'email'		 => esc_js( esc_html__( 'Please provide a valid email address.', '5th-avenue' ) ),
				),
				'password'	 => esc_js( esc_html__( 'Please enter an account password.', '5th-avenue' ) ),
			),
		) );

		wp_localize_script( 'av5-shop-js', 'av5_single_product_params', array(
			'owlcarousel'				 => apply_filters( 'av5_single_product_carousel_options', array(
				'lazyLoad'			 => true,
				'autoplay'			 => false,
				'autoplayTimeout'	 => 5000,
				'autoplaySpeed'		 => false,
				'animateOut'		 => false,
				'animateIn'			 => false,
				'dots'				 => false,
				'nav'				 => (bool) av5_get_option( 'product-pages-product-image-arrows' ),
				'navText'			 => array(
					'<svg class="next-arrow" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 39 12"><line x1="23" y1="-0.5" x2="29.5" y2="6.5" stroke="#ffffff;"></line><line x1="23" y1="12.5" x2="29.5" y2="5.5" stroke="#ffffff;"></line></svg><span class="line"></span>',
					'<svg class="next-arrow" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 39 12"><line x1="23" y1="-0.5" x2="29.5" y2="6.5" stroke="#ffffff;"></line><line x1="23" y1="12.5" x2="29.5" y2="5.5" stroke="#ffffff;"></line></svg><span class="line"></span>',
				),
			) ),
			'thumb_horizontal_enabled'	 => av5_get_option( 'product-pages-product-thumbnails-position' ) != 'no-thumbs',
			'thumb_vertical_enabled'	 => av5_get_option( 'product-pages-product-thumbnails-position' ) == 'thumbs-left',
			'thumb_horizontal'			 => apply_filters( 'av5_single_product_thumb_horizontal_options', array(
				'lazyLoad'	 => true,
				'dots'		 => false,
				'nav'		 => false,
				'animateOut' => false,
				'animateIn'	 => false,
				'margin'	 => 10,
				'responsive' => array(
					'0'		 => array(
						'items' => 4,
					),
					'480'	 => array(
						'items' => 6,
					),
					'768'	 => array(
						'items' => 8,
					),
					'991'	 => array(
						'items' => 8,
					),
					'1025'	 => array(
						'items' => 6,
					),
				),
			) ),
			'zoom_enabled'				 => (bool) av5_get_option( 'product-pages-image-zoom' ),
			'zoom_options'				 => apply_filters( 'av5_single_product_zoom_options', array() ),
			'photoswipe_enabled'		 => (bool) av5_get_option( 'product-pages-image-lightbox' ),
			'photoswipe_options'		 => apply_filters( 'av5_single_product_photoswipe_options', array(
				'shareEl'				 => false,
				'closeOnScroll'			 => false,
				'history'				 => false,
				'showHideOpacity'		 => true,
				'hideAnimationDuration'	 => 333,
				'showAnimationDuration'	 => 333,
			) ),
			'owlCarousel_enabled'		 => apply_filters( 'av5_single_product_owlcarousel_enabled', get_theme_support( 'wc-product-gallery-slider' ) ),
		) );
	} // End if().


}

add_action( 'wp_enqueue_scripts', 'av5c_scripts', 100 );
