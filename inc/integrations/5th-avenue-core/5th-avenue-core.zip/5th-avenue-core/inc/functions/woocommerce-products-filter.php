<?php
/**
 * Products filter for woocommerce product attribute
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

/**
 * Products filter for woocommerce product attribute
 */
class AV5_Products_Filter {

	/**
	 * Allows you to use categories for the filter
	 *
	 * @var boolean
	 */
	static $use_cat;

	/**
	 * Allows you to use attributes for the filter
	 *
	 * @var boolean
	 */
	static $use_attributes;

	/**
	 * Allows you to use tags for the filter
	 *
	 * @var boolean
	 */
	static $use_tag;

	/**
	 * Allows you to use price range for the filter
	 *
	 * @var boolean
	 */
	static $use_price;

	/**
	 * Allows you to display sorting options
	 *
	 * @var boolean
	 */
	static $use_order;

	/**
	 * Add "All"
	 *
	 * @var boolean
	 */
	static $add_all;

	/**
	 * Is Slideout?
	 *
	 * @var boolean
	 */
	static $only_slideout;

	/**
	 * Position filters
	 *
	 * @var integer
	 */
	static $position;

	/**
	 * Initialization of the functional
	 */
	public static function init() {
		if (  av5_get_option( 'shop-page-product-filters', 1 ) ) {
			self::$use_cat			 = av5_get_option( 'shop-page-product-filter-category', 1 );
			self::$use_attributes	 = av5_get_option( 'shop-page-product-filter-attributes', 1 );
			self::$use_tag			 = av5_get_option( 'shop-page-product-filter-tag', 0 );
			self::$use_price		 = av5_get_option( 'shop-page-product-filter-price', 1 );
			self::$add_all			 = av5_get_option( 'shop-page-product-filter-element-all', 1 );
			self::$use_order		 = av5_get_option( 'shop-page-product-filter-order', 1 );
			self::$only_slideout	 = '2' == av5_get_option( 'shop-page-product-filters-style', '1' ); // WPCS: loose comparison ok.
			self::$position			 = absint( av5_get_option( 'shop-page-product-filters-position', '1' ) );
		}

		switch ( av5_get_option( 'shop-page-product-filters-position', '1' ) ) {
			case 3:
				add_action( 'av5_title_area_after', array( __CLASS__, 'output' ), 40 );
				add_action( 'av5_title_area_hero_after', array( __CLASS__, 'output' ), 40 );
				add_action( 'av5_before_title_area_revslider', array( __CLASS__, 'output' ), 40 );
				break;
			case 1:
			case 2:
			default:
				add_action( 'woocommerce_before_shop_loop', array( __CLASS__, 'output' ), 5 );
				add_action( 'woocommerce_no_products_found', array( __CLASS__, 'output' ), 5 );
		}

		remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );
		remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );
		if ( self::$use_order ) {
			add_action( 'av5_products_after_filter', 'woocommerce_result_count', 20 );
			add_action( 'av5_products_after_filter', 'woocommerce_catalog_ordering', 30 );
		}

		add_filter( 'woocommerce_product_query', array( __CLASS__, 'product_query' ), 10, 2 );
		add_filter( 'init', array( __CLASS__, 'redirect_filter' ) );
		add_filter( 'woocommerce_is_filtered', array( __CLASS__, 'is_filtered' ) );

		add_filter( 'av5_products_before_filter', array( __CLASS__, 'slideout_output' ) );
		add_filter( 'av5_products_filter_product_cat', array( __CLASS__, 'filter_cat' ) );
		add_filter( 'av5_products_filter_product_attributes', array( __CLASS__, 'filter_attributes' ) );
		add_filter( 'av5_products_filter_product_tag', array( __CLASS__, 'filter_tags' ) );
		add_filter( 'av5_products_filter_product_cat', array( __CLASS__, 'filter_current_category' ) );
		add_filter( 'av5_products_filter_prepare_attribute', array( __CLASS__, 'prepare_attribute' ) );
		add_filter( 'av5_products_filter_prepare_checked', array( __CLASS__, 'prepare_checked' ), 10, 3 );
		add_filter( 'av5_products_filter_prepare_name', array( __CLASS__, 'prepare_name' ), 10, 3 );
		add_action( 'save_post_product', array( __CLASS__, 'remove_cache' ) );
	}

	/**
	 * Adds verification that products filtered by these filters
	 *
	 * @param boolean $filtered Filtered products.
	 * @return boolean
	 */
	public static function is_filtered( $filtered ) {
		if ( ! $filtered ) {
			if ( isset( $_GET['av5_product_cat'] ) ) { // WPCS: input var ok.
				return true;
			}
			if ( isset( $_GET['av5_product_tag'] ) ) { // WPCS: input var ok.
				return true;
			}
			$post_data = array_keys( $_POST ); // WPCS: input var ok. CSRF ok.
			foreach ( $post_data as $key ) {
				if ( preg_match( '/^av5a_/i', $key ) ) {
					return true;
				}
			}
		}
		return $filtered;
	}

	/**
	 * Redirects to simplified filtering arguments
	 */
	public static function redirect_filter() {
		if ( is_admin() ) {
			return;
		}
		$post_data	 = $_POST; // WPCS: input var ok. CSRF ok.
		$_post_data	 = array();
		if ( empty( $post_data ) ) {
			return;
		}
		foreach ( $post_data as $key => $value ) {
			if ( preg_match( '/^av5_filter_/i', $key ) ) {
				$value	 = array_filter( (array) filter_var( $value, FILTER_DEFAULT, array(
					'flags' => FILTER_REQUIRE_ARRAY,
				) ) );
				$prefix	 = 'av5a_';
				if ( in_array( $key, array( 'av5_filter_product_cat', 'av5_filter_product_tag' ) ) ) {  // @codingStandardsIgnoreLine WordPress.PHP.StrictInArray.MissingTrueStrict
					$prefix = 'av5_';
				}
				$key				 = preg_replace( '/^av5_filter_/i', $prefix, $key );
				$_post_data[ $key ]	 = implode( ',', $value );
			}
		}
		if ( array_key_exists( 'min_price', $post_data ) ) {
			$_post_data['min_price'] = $post_data['min_price'];
		}
		if ( array_key_exists( 'max_price', $post_data ) ) {
			$_post_data['max_price'] = $post_data['max_price'];
		}

		if ( empty( $_post_data ) ) {
			return;
		}
		$__post_data = array();
		foreach ( $_post_data as $key => $value ) {
			if ( empty( $value ) ) {
				$__post_data[] = $key;
			}
		}
		$query	 = add_query_arg( $_post_data );
		$query	 = remove_query_arg( $__post_data, $query );

		wp_safe_redirect( $query );
		exit();
	}

	/**
	 * Adds filtering to wc_query
	 *
	 * @param \WP_Query $q The WordPress Query class.
	 * @param \WC_Query $wc_query Contains the query functions for WooCommerce which alter the front-end post queries and loops.
	 */
	public static function product_query( $q, $wc_query ) {
		if ( ! $q->is_main_query() ) {
			return;
		}
		if ( isset( $_GET['av5_product_cat'] ) ) { // WPCS: input var ok.
			$filter_terms = explode( ',', wc_clean( $_GET['av5_product_cat'] ) ); // WPCS: input var ok. sanitization ok.
			if ( ! empty( $filter_terms ) ) {
				$isset_terms = get_terms( array(
					'taxonomy'	 => 'product_cat',
					'hide_empty' => 0,
					'fields'	 => 'id=>slug',
				) );
				$filter_terms = array_intersect( $filter_terms, $isset_terms );
			}
			if ( ! empty( $filter_terms ) ) {
				self::add_to_tax_query( $q, array(
					'field'		 => 'slug',
					'operator'	 => 'IN',
					'taxonomy'	 => 'product_cat',
					'terms'		 => $filter_terms,
				) );
			}
		}
		if ( $attribute_taxonomies = wc_get_attribute_taxonomies() ) {
			foreach ( $attribute_taxonomies as $tax ) {
				$taxonomy		 = wc_attribute_taxonomy_name( wc_sanitize_taxonomy_name( $tax->attribute_name ) );
				$filter_terms	 = ! empty( $_GET[ 'av5a_' . $taxonomy ] ) ? explode( ',', wc_clean( $_GET[ 'av5a_' . $taxonomy ] ) ) : array(); // WPCS: input var ok. sanitization ok.
				if ( ! empty( $filter_terms ) ) {
					$isset_terms = get_terms( array(
						'taxonomy'	 => $taxonomy,
						'hide_empty' => 0,
						'fields'	 => 'id=>slug',
					) );
					$filter_terms = array_intersect( $filter_terms, $isset_terms );
				}
				if ( ! empty( $filter_terms ) ) {
					self::add_to_tax_query( $q, array(
						'field'		 => 'slug',
						'operator'	 => 'IN',
						'taxonomy'	 => $taxonomy,
						'terms'		 => $filter_terms,
					) );
				}
			}
		}
		if ( isset( $_GET['av5_product_tag'] ) ) { // WPCS: input var ok.
			$filter_terms = explode( ',', wc_clean( $_GET['av5_product_tag'] ) ); // WPCS: input var ok. sanitization ok.
			if ( ! empty( $filter_terms ) ) {
				$isset_terms = get_terms( array(
					'taxonomy'	 => 'product_tag',
					'hide_empty' => 0,
					'fields'	 => 'id=>slug',
				) );
				$filter_terms = array_intersect( $filter_terms, $isset_terms );
			}
			if ( ! empty( $filter_terms ) ) {
				self::add_to_tax_query( $q, array(
					'field'		 => 'slug',
					'operator'	 => 'IN',
					'taxonomy'	 => 'product_tag',
					'terms'		 => $filter_terms,
				) );
			}
		}
	}

	/**
	 * Updates the arguments for querying items
	 *
	 * @param \WP_Query $q The WordPress Query class.
	 * @param array     $tax_query Array arguments for query.
	 * @return type
	 */
	public static function add_to_tax_query( $q, $tax_query = array() ) {
		$_tax_query		 = $q->get( 'tax_query' );
		$_tax_query[]	 = $tax_query;
		$q->set( 'tax_query', $_tax_query );
		return $q;
	}

	/**
	 * Clears all current filters
	 *
	 * @global \WP_Query $wp_query The WordPress Query class.
	 * @param array $query_vars Product request arguments.
	 * @return array
	 */
	public static function resest_filter_query( $query_vars = array() ) {
		if ( empty( $query_vars ) ) {
			global $wp_query;

			$query_vars = $wp_query->query_vars;
		}

		$query_vars['posts_per_page']	 = 9999999; // @codingStandardsIgnoreLine WordPress.VIP.PostsPerPage.posts_per_page
		$query_vars['paged']			 = 0; // @codingStandardsIgnoreLine WordPress.VIP.PostsPerPage.paged

		if ( array_key_exists( 'product_cat', $query_vars ) ) {
			$query_vars['taxonomy']	 = 'product_cat';
			$query_vars['term']		 = $query_vars['product_cat'];
		} else {
			if ( array_key_exists( 'taxonomy', $query_vars ) ) {
				unset( $query_vars['taxonomy'] );
			}
			if ( array_key_exists( 'term', $query_vars ) ) {
				unset( $query_vars['term'] );
			}
		}

		foreach ( $query_vars['tax_query'] as $key => $tax_query ) {
			if ( 'relation' === $key || 'product_visibility' === $tax_query['taxonomy'] ) {
				continue;
			}
			unset( $query_vars['tax_query'][ $key ] );
		}
		foreach ( $query_vars['meta_query'] as $key => $tax_query ) {
			unset( $query_vars['meta_query'][ $key ] );
		}

		return apply_filters( 'av5_products_filter_resets_vars', $query_vars );
	}

	/**
	 * Selects all elements from products for possible filtration.
	 *
	 * @param bool $use_cat Use categories.
	 * @param bool $use_attributes Use attributes.
	 * @param bool $use_tag Use tags.
	 * @param bool $use_price Use price.
	 * @return array
	 */
	public static function get_elements( $use_cat = true, $use_attributes = true, $use_tag = true, $use_price = true ) {
		$get_keys = array_keys( $_GET ); // WPCS: input var ok.
		foreach ( $get_keys as $key => $get_key ) {
			if ( ! preg_match( '/^av5a_/i', $get_key ) ) {
				unset( $get_keys[ $key ] );
			}
		}
		$get_keys[]	 = 'av5_product_cat';
		$get_keys[]	 = 'av5_product_tag';
		$get_keys[]	 = 'paged';
		$transient	 = 'av5_filter_' . md5( remove_query_arg( $get_keys ) );

		$filter_elements = get_transient( $transient );
		if ( empty( $filter_elements ) || current_user_can( 'editor' ) || current_user_can( 'administrator' ) ) {
			$_query = new WP_Query( self::resest_filter_query() );

			$product_cat			 = array();
			$product_attributes		 = array();
			$product_tag			 = array();
			$product_price			 = array();
			$products				 = apply_filters( 'av5_products_filter_products', $_query->posts );
			$grouped_type_products	 = apply_filters( 'av5_products_filter_grouped_type_products', array( 'grouped' ) );

			foreach ( $products as $post ) {
				$product = wc_get_product( $post );
				if ( $use_cat ) {
					$value = $product->get_category_ids();
					if ( is_array( $value ) ) {
						$product_cat = array_merge( $product_cat, $value );
					}
				}
				if ( $use_attributes ) {
					$value = $product->get_attributes();
					foreach ( $value as $key => $_value ) {
						if ( $_value->is_taxonomy() ) {
							if ( array_key_exists( $key, $product_attributes ) ) { // Exclude not global attributes.
								$product_attributes[ $key ]->set_options( array_merge( $product_attributes[ $key ]->get_options(), $_value->get_options() ) );
							} else {
								$product_attributes[ $key ] = $_value;
							}
						}
					}
				}
				if ( $use_tag ) {
					$value = $product->get_tag_ids();
					if ( is_array( $value ) ) {
						$product_tag = array_merge( $product_tag, $value );
					}
				}
				if ( $use_price ) {
					if ( in_array( $product->get_type(), $grouped_type_products ) ) { // @codingStandardsIgnoreLine WordPress.PHP.StrictInArray.MissingTrueStrict
						$children = array_filter( array_map( 'wc_get_product', $product->get_children() ), 'wc_products_array_filter_visible_grouped' );
						foreach ( $children as $child ) {
							if ( method_exists( $child, 'get_variation_price' ) ) {
								$product_price[] = $child->get_variation_price();
								$product_price[] = $child->get_variation_price( 'max' );
							} else {
								$product_price[] = $child->get_price();
							}
						}
					} elseif ( method_exists( $product, 'get_variation_price' ) ) {
						$product_price[] = $product->get_variation_price();
						$product_price[] = $product->get_variation_price( 'max' );
					} else {
						$product_price[] = $product->get_price();
					}
				}
			} // End foreach().
			if ( $use_cat && ! empty( $product_cat ) ) {
				$product_cat = apply_filters( 'av5_products_filter_product_cat', $product_cat );
			}
			if ( $use_attributes && ! empty( $product_attributes ) ) {
				$product_attributes = apply_filters( 'av5_products_filter_product_attributes', $product_attributes );
			}
			if ( $use_tag && ! empty( $product_tag ) ) {
				$product_tag = apply_filters( 'av5_products_filter_product_tag', $product_tag );
			}
			if ( $use_price && ! empty( $product_price ) ) {
				$product_price	 = array_filter( $product_price );
				$product_price	 = array(
					floor( min( $product_price ) ),
					ceil( max( $product_price ) ),
				);
				$product_price	 = apply_filters( 'av5_products_filter_product_price', $product_price );
			}

			$filter_elements = compact( 'product_cat', 'product_attributes', 'product_tag', 'product_price' );
			set_transient( $transient, $filter_elements );
		} // End if().

		return $filter_elements;
	}

	/**
	 * Filtering categories for uniqueness
	 *
	 * @param array $cat Id product categories.
	 * @return array
	 */
	public static function filter_cat( $cat ) {
		return array_unique( $cat, SORT_NUMERIC );
	}

	/**
	 * Selects all nested categories if we are on a category page
	 *
	 * @param array $cat Id product categories.
	 * @return array
	 */
	public static function filter_current_category( $cat ) {
		if ( is_tax() ) {
			$term_id		 = get_queried_object()->term_id;
			$term_children	 = get_term_children( $term_id, 'product_cat' );
			$cat			 = array_intersect( $term_children, $cat );
		}

		return $cat;
	}

	/**
	 * Filtering attributes for uniqueness
	 *
	 * @param array $attributes Array of product attributes.
	 * @return array
	 */
	public static function filter_attributes( $attributes ) {
		foreach ( $attributes as $key => $attribute ) {
			$attributes[ $key ]->set_options( array_unique( $attribute->get_options() ) );
		}

		return $attributes;
	}

	/**
	 * Prepare product attributes for display
	 *
	 * @param \WC_Product_Attribute $attribute Represents a product attribute.
	 * @return array
	 */
	public static function prepare_attribute( $attribute ) {
		$terms = $attribute->get_terms();
		if ( ! empty( $terms ) ) {
			$attributes = $attribute->get_options();
			foreach ( $terms as $key => $term ) {
				if ( ! in_array( $term->term_id, $attributes ) ) { // @codingStandardsIgnoreLine WordPress.PHP.StrictInArray.MissingTrueStrict
					unset( $terms[ $key ] );
				}
			}

			return $terms;
		}
	}

	/**
	 * Filtering tags for uniqueness
	 *
	 * @param array $tag Id product tags.
	 * @return array
	 */
	public static function filter_tags( $tag ) {
		return array_unique( $tag, SORT_NUMERIC );
	}

	/**
	 * Prepare the marked filter elements
	 *
	 * @param string $value Value for comparison.
	 * @param string $key Key of the field.
	 * @param string $slug The value of the current item.
	 * @return string
	 */
	public static function prepare_checked( $value, $key, $slug ) {
		$woo_key = str_replace( 'pa_', 'filter_', $key );
		if ( empty( $slug ) ) {
			if ( isset( $_GET[ 'av5_' . $key ] ) ) { // WPCS: input var ok.
				return $_GET[ 'av5_' . $key ]; // WPCS: input var ok. sanitization ok.
			}
			if ( isset( $_GET[ 'av5a_' . $key ] ) ) { // WPCS: input var ok.
				return $_GET[ 'av5a_' . $key ]; // WPCS: input var ok. sanitization ok.
			}
			if ( isset( $_GET[ $woo_key ] ) ) { // WPCS: input var ok.
				return $_GET[ $woo_key ]; // WPCS: input var ok. sanitization ok.
			}
		} else {
			$value = array();
			if ( isset( $_GET[ 'av5_' . $key ] ) ) { // WPCS: input var ok.
				$value = explode( ',', wc_clean( $_GET[ 'av5_' . $key ] ) ); // WPCS: input var ok. sanitization ok.
			} elseif ( isset( $_GET[ 'av5a_' . $key ] ) ) { // WPCS: input var ok.
				$value = explode( ',', wc_clean( $_GET[ 'av5a_' . $key ] ) ); // WPCS: input var ok. sanitization ok.
			} elseif ( isset( $_GET[ $woo_key ] ) ) { // WPCS: input var ok.
				$value = explode( ',', wc_clean( $_GET[ $woo_key ] ) ); // WPCS: input var ok. sanitization ok.
			}
			if ( in_array( $slug, (array) $value ) ) { // @codingStandardsIgnoreLine WordPress.PHP.StrictInArray.MissingTrueStrict
				return $slug;
			}
		}
		return '';
	}

	/**
	 * Adds selected current filters to the name field
	 *
	 * @param string $name Name of the filter.
	 * @param string $key Key of the field.
	 * @param array  $options Filter options.
	 * @return type
	 */
	public static function prepare_name( $name, $key, $options ) {
		$value = array();
		if ( isset( $_GET[ 'av5_' . $key ] ) ) { // WPCS: input var ok.
			$value = explode( ',', wc_clean( $_GET[ 'av5_' . $key ] ) ); // WPCS: input var ok. sanitization ok.
		} elseif ( isset( $_GET[ 'av5a_' . $key ] ) ) { // WPCS: input var ok.
			$value = explode( ',', wc_clean( $_GET[ 'av5a_' . $key ] ) ); // WPCS: input var ok. sanitization ok.
		}
		if ( ! empty( $value ) ) {
			$_value = array();
			foreach ( $options as $term ) {
				if ( in_array( $term->slug, $value ) ) { // @codingStandardsIgnoreLine WordPress.PHP.StrictInArray.MissingTrueStrict
					$_value[ $term->slug ] = $term->name;
				}
			}
			if ( ! empty( $_value ) ) {
				$name	 = sprintf( '%s: %s', $name, count( $_value ) );
			}
		}
		return $name;
	}

	/**
	 * Remove cached filters
	 *
	 * @global \wpdb $wpdb
	 */
	public static function remove_cache() {
		global $wpdb;

		$options_name = $wpdb->get_col( "SELECT `option_name` FROM " . $wpdb->options . " WHERE `option_name` LIKE '_transient_av5_filter_%'" );  // @codingStandardsIgnoreLine WordPress.VIP.DirectDatabaseQuery.DirectQuery
		foreach ( $options_name as $option_name ) {
			delete_transient( str_replace( '_transient_', '', $option_name ) );
		}
	}

	/**
	 * Displays filters for products
	 */
	public static function output() {
		$data = self::get_elements( self::$use_cat, self::$use_attributes, self::$use_tag, self::$use_price );

		if ( ! empty( $data['product_cat'] ) ) {
			$data['product_cat'] = get_terms( array(
				'taxonomy'			 => 'product_cat',
				'term_taxonomy_id'	 => $data['product_cat'],
			) );
		}
		if ( ! empty( $data['product_tag'] ) ) {
			$data['product_tag'] = get_terms( array(
				'taxonomy'			 => 'product_tag',
				'term_taxonomy_id'	 => $data['product_tag'],
			) );
		}
		if ( ! empty( $data['product_price'] ) ) {
			/**
			 * This code is taken from widget functionality
			 *
			 * @see \WC_Widget_Price_Filter
			 */
			$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
			wp_register_script( 'accounting', WC()->plugin_url() . '/assets/js/accounting/accounting' . $suffix . '.js', array( 'jquery' ), '0.4.2' );
			wp_register_script( 'wc-jquery-ui-touchpunch', WC()->plugin_url() . '/assets/js/jquery-ui-touch-punch/jquery-ui-touch-punch' . $suffix . '.js', array( 'jquery-ui-slider' ), WC_VERSION, true );
			wp_register_script( 'wc-price-slider', WC()->plugin_url() . '/assets/js/frontend/price-slider' . $suffix . '.js', array( 'jquery-ui-slider', 'wc-jquery-ui-touchpunch', 'accounting' ), WC_VERSION, true );
			wp_localize_script( 'wc-price-slider', 'woocommerce_price_slider_params', array(
				'currency_format_num_decimals'	 => 0,
				'currency_format_symbol'		 => get_woocommerce_currency_symbol(),
				'currency_format_decimal_sep'	 => esc_attr( wc_get_price_decimal_separator() ),
				'currency_format_thousand_sep'	 => esc_attr( wc_get_price_thousand_separator() ),
				'currency_format'				 => esc_attr( str_replace( array( '%1$s', '%2$s' ), array( '%s', '%v' ), get_woocommerce_price_format() ) ),
			) );
		}
		$_data = array_filter( $data );
		if ( empty( $_data ) ) {
			return;
		}

		$data['element_all'] = self::$add_all;

		$get_keys = array_keys( $_GET ); // WPCS: input var ok.
		foreach ( $get_keys as $k => $get_key ) {
			if ( in_array( $get_key, array( 'min_price', 'max_price', 'av5_product_cat', 'av5_product_tag' ) ) ) { // @codingStandardsIgnoreLine WordPress.PHP.StrictInArray.MissingTrueStrict
				continue;
			}
			if ( preg_match( '/^av5a_/i', $get_key ) ) {
				continue;
			}
			if ( preg_match( '/^filter_/i', $get_key ) ) {
				continue;
			}
			unset( $get_keys[ $k ] );
		}
		$data['only_slideout']	 = self::$only_slideout;
		$data['positon_filters']	 = self::$position;
		$data['need_clean']		 = $get_keys;

		av5c_get_template( 'woocommerce/loop/products-filter.php', $data );
	}

	/**
	 * Output slideout
	 *
	 * @param array $data Data for filters.
	 */
	public static function slideout_output( $data ) {
		av5c_get_template( 'woocommerce/loop/products-filter-slideout.php', $data );
	}

	/**
	 * Displays filters for products in title area
	 */
	public static function output_in_title() {
		if ( ! is_shop() && ! is_product_taxonomy() ) {
			return;
		}
		self::output();
	}

}
