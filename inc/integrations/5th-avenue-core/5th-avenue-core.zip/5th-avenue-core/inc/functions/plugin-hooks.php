<?php
/**
 * 5th-Avenue theme hooks
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;


add_action( 'av5_post_author_additional_description', 'av5_author_additional_description', 20 );
if ( av5_get_option( 'blog-post-social-share' ) ) {
	add_action( 'av5_after_post_content', 'av5_post_social', 20 );
}

if ( ! function_exists( 'av5_post_social' ) ) {

	/**
	 * Social Share.
	 */
	function av5_post_social() {
		av5c_get_template_part( 'template-parts/posts/elements/social' );
	}
}

if ( ! function_exists( 'av5_get_author_additional_description' ) ) {

	/**
	 * Get author additional description.
	 */
	function av5_get_author_additional_description() {
		global $post;

		$author_links = '';
		if ( defined( 'WPSEO_PATH' ) ) {
			$twitter	 = get_the_author_meta( 'twitter', $post->post_author );
			$facebook	 = get_the_author_meta( 'facebook', $post->post_author );
			$google_plus = get_the_author_meta( 'googleplus', $post->post_author );
			if ( $facebook ) {
				$author_links .= '<a href="' . esc_url( $facebook ) . '" rel="nofollow" target="_blank">' . esc_html__( 'Facebook', '5th-avenue' ) . '</a>';
			}
			if ( $twitter ) {
				$author_links .= '<a href="' . esc_url( 'https://twitter.com/' . $twitter ) . '" rel="nofollow" target="_blank">' . esc_html__( 'Twitter', '5th-avenue' ) . '</a>';
			}
			if ( $google_plus ) {
				$author_links .= '<a href="' . esc_url( $google_plus ) . '" rel="nofollow" target="_blank">' . esc_html__( 'Google +', '5th-avenue' ) . '</a>';
			}
		}
		if ( get_the_author_meta( 'url' ) ) {
			$author_links .= '<a href="' . esc_url( get_the_author_meta( 'url' ) ) . '" rel="nofollow" target="_blank">' . esc_html__( 'Website', '5th-avenue' ) . '</a>';
		}
		if ( $author_links ) {
			$author_links = '<div class="about-author__links"><p>' . $author_links . '</p></div>';
		}

		return $author_links;
	}
}

if ( ! function_exists( 'av5_author_additional_description' ) ) {

	/**
	 * Author additional description.
	 */
	function av5_author_additional_description() {
		echo av5_get_author_additional_description(); // WPCS: xss ok.
	}
}