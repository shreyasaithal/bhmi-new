<?php
/**
 * Extension-Boilerplate
 *
 * @link https://github.com/ReduxFramework/extension-boilerplate
 *
 * Radium Importer - Modified For ReduxFramework
 * @link https://github.com/FrankM1/radium-one-click-demo-install
 *
 * @package     WBC_Importer - Extension for Importing demo content
 * @author      Webcreations907
 * @version     1.0.1
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Merlin_Demo_Data_Importer' ) ) {

	if ( ! class_exists( 'Merlin' ) ) {
		require_once dirname( __FILE__ ) . '/importer/merlin.php'; // Load admin theme data importer.
	}

	/**
	 * Merlin.
	 */
	class Merlin_Demo_Data_Importer extends Merlin {

		/**
		 * Class Constructor.
		 *
		 * @param array $config Package-specific configuration args.
		 * @param array $strings Text for the different elements.
		 */
		function __construct( $config = array(), $strings = array() ) {
			$this->directory = dirname( __FILE__ ) . '/importer';

			$this->required_classes();
		}

		/**
		 * Require necessary classes.
		 */
		function required_classes() {
			if ( ! class_exists( '\WP_Importer' ) ) {
				require ABSPATH . '/wp-admin/includes/class-wp-importer.php';
			}
			if ( ! class_exists( 'Merlin_Downloader' ) ) {
				require_once $this->directory . '/includes/class-merlin-downloader.php';
			}
			require_once $this->directory . '/vendor/autoload.php';

			$logger = new ProteusThemes\WPContentImporter2\WPImporterLogger();

			$this->importer = new ProteusThemes\WPContentImporter2\Importer( array( 'fetch_attachments' => true ), $logger );

			if ( ! class_exists( 'Merlin_Widget_Importer' ) ) {
				require_once $this->directory . '/includes/class-merlin-widget-importer.php';
			}

			if ( ! class_exists( 'WP_Customize_Setting' ) ) {
				require_once ABSPATH . 'wp-includes/class-wp-customize-setting.php';
			}
			if ( ! class_exists( 'Merlin_Customizer_Option' ) ) {
				require_once $this->directory . '/includes/class-merlin-customizer-option.php';
			}
			if ( ! class_exists( 'Merlin_Customizer_Importer' ) ) {
				require_once $this->directory . '/includes/class-merlin-customizer-importer.php';
			}
			if ( ! class_exists( 'Merlin_Redux_Importer' ) ) {
				require_once $this->directory . '/includes/class-merlin-redux-importer.php';
			}
			if ( ! class_exists( 'Merlin_Hooks' ) ) {
				require_once $this->directory . '/includes/class-merlin-hooks.php';
			}

			$this->hooks = new Merlin_Hooks();

			if ( class_exists( 'EDD_Theme_Updater_Admin' ) ) {
				$this->updater = new EDD_Theme_Updater_Admin();
			}
		}

		/**
		 * Init Settings for current demo
		 *
		 * @param \ReduxFramework_extension_wbc_importer $parent Extensions class.
		 * @param \ReduxFramework                        $redux_instance Redux.
		 */
		public function initSettings( $parent, $redux_instance ) {
			$opt_name = $redux_instance->args['opt_name'];
			if ( array_key_exists( 'import_redux', $parent->active_import ) ) {
				$redux_file								 = $parent->active_import['import_redux'];
				$parent->active_import['import_redux'] = array(
					array(
						'file_url'		 => $redux_file,
						'option_name'	 => $opt_name,
					),
				);
			}
			if ( array_key_exists( 'local_import_redux', $parent->active_import ) ) {
				$redux_file										 = $parent->active_import['local_import_redux'];
				$parent->active_import['local_import_redux']	 = array(
					array(
						'file_path'		 => $redux_file,
						'option_name'	 => $opt_name,
					),
				);
			}
			$this->import_files = array( $parent->active_import_id => $parent->active_import );
		}

		/**
		 * Do content's AJAX
		 *
		 * @staticvar string $content Worked conten.
		 * @param string $action Action for imports.
		 * @param mixed  $selected_import Selecte import demo content.
		 */
		public function action( $action, $selected_import = 0 ) {
			static $content = null;

			if ( empty( $action ) ) {
				$data = $this->get_import_data_info( $selected_import );
				wp_send_json( $data );
			}
			if ( 'alldone' == $action ) {
				$imported = get_option( 'wbc_imported_demos' );
				if ( empty( $imported ) ) {
					$imported = array();
				}
				$imported[ $selected_import ] = 'imported';
				update_option( 'wbc_imported_demos', $imported );
				wp_send_json( array( 'done' => 1 ) );
			}

			if ( null === $content ) {
				$content = $this->get_import_data( $selected_import );
			}
			if ( ! isset( $content[ $action ] ) ) {
				wp_send_json_error( array( 'error' => 1, 'message' => esc_html__( 'Invalid content!', 'merlin-wp' ) ) );
			}

			$json			 = false;
			$this_content	 = $content[ $action ];
			if ( is_callable( $this_content['install_callback'] ) ) {
				$logs = call_user_func( $this_content['install_callback'], $this_content['data'] );
				if ( $logs ) {
					$json = array(
						'done'		 => 1,
						'message'	 => $this_content['success'],
						'debug'		 => '',
						'logs'		 => $logs,
						'errors'	 => '',
					);
				} else {
					$json = array(
						'error'		 => 1,
						'message'	 => esc_html__( 'Error', 'merlin-wp' ),
						'debug'		 => '',
						'logs'		 => $logs,
						'errors'	 => '',
					);
				}
			}
			if ( $json ) {
				$json['hash'] = md5( serialize( $json ) );
				wp_send_json( $json );
			} else {
				wp_send_json( array(
					'error'		 => 1,
					'message'	 => esc_html__( 'Error', 'merlin-wp' ),
					'logs'		 => '',
					'errors'	 => '',
				) );
			}
		}

	}

} // End if().
