<?php

/**
 * Extension-Boilerplate
 *
 * @link https://github.com/ReduxFramework/extension-boilerplate
 *
 * Radium Importer - Modified For ReduxFramework
 * @link https://github.com/FrankM1/radium-one-click-demo-install
 *
 * @package     WBC_Importer - Extension for Importing demo content
 * @author      Webcreations907
 * @version     1.0.3
 * @codingStandardsIgnoreFile
 */
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) )
	exit;

// Don't duplicate me!
if ( ! class_exists( 'ReduxFramework_extension_wbc_importer' ) ) {

	class ReduxFramework_extension_wbc_importer {

		public static $instance;
		static $version			 = "1.0.3";
		protected $parent;
		private $filesystem		 = array();
		public $extension_url;
		public $extension_dir;
		public $demo_data_dir;
		public $wbc_import_files = array();
		public $active_import_id;
		public $active_import;

		/**
		 * Class Constructor
		 *
		 * @since       1.0
		 * @access      public
		 * @param class $parent
		 * @return      void
		 */
		public function __construct( $parent ) {

			$this->parent = $parent;

			if ( ! is_admin() ) {
				return;
			}

			// Hides importer section if anything but true returned. Way to abort :).
			if ( true !== apply_filters( 'wbc_importer_abort', true ) ) {
				return;
			}

			if ( empty( $this->extension_dir ) ) {
				$this->extension_dir = trailingslashit( str_replace( '\\', '/', dirname( __FILE__ ) ) );
				$this->extension_url = site_url( str_replace( trailingslashit( str_replace( '\\', '/', ABSPATH ) ), '', $this->extension_dir ) );
				$this->demo_data_dir = apply_filters( 'wbc_importer_dir_path', $this->extension_dir . 'demo-data/' );
				$this->demo_data_url = apply_filters( 'wbc_importer_url_path', '' );
			}

			// Delete saved options of imported demos, for dev/testing purpose.
			// delete_option('wbc_imported_demos');

			$this->getLocalImports();

			$this->field_name = 'wbc_importer';

			self::$instance = $this;

			add_filter( 'redux/' . $this->parent->args['opt_name'] . '/field/class/' . $this->field_name, array( &$this, 'overload_field_path' ) );

			add_action( 'wp_ajax_redux_wbc_importer', array( $this, 'ajax_importer' ) );

			add_filter( 'redux/' . $this->parent->args['opt_name'] . '/field/wbc_importer_files', array( $this, 'addImportFiles' ) );
		}

		public function demoImports() {
			if ( ! empty( $this->wbc_import_files ) ) {
				return $this->wbc_import_files;
			}
			$this->getLocalImports();
			$this->getUrlImports();

			return $this->wbc_import_files;
		}

		public function getUrl() {
			$content = get_transient( 'wbc_demo_url_content' );
			if ( empty( $content ) ) {
				$_content		 = file_get_contents( $this->demo_data_url );
				$content_array	 = @json_decode( $_content, true );
				$content		 = array();
				if ( ! empty( $content_array ) && is_array( $content_array ) ) {
					$content = $content_array;
				}
				set_transient( 'wbc_demo_url_content', $content, 12 * 60 * 60 );
			}
			return $content;
		}

		public function getUrlImports() {
			$imported	 = get_option( 'wbc_imported_demos' );
			$content	 = $this->getUrl();

			if ( ! empty( $content ) && is_array( $content ) ) {
				foreach ( $content as $key => $import ) {
					$demo = 'wbc-import-' . $key;
					if ( ! array_key_exists( $demo, $this->wbc_import_files ) ) {
						$this->wbc_import_files[ $demo ] = array();
					}

					$this->wbc_import_files[ $demo ]['import_file_name'] = $import['import_file_name'];

					if ( ! empty( $imported ) && is_array( $imported ) ) {
						if ( array_key_exists( $demo, $imported ) ) {
							$this->wbc_import_files[ $demo ]['imported'] = 'imported';
						}
					}
					foreach ( $import as $_key => $_import ) {
						switch ( $_key ) {
							case 'import_file_url':
							case 'import_widget_file_url':
							case 'import_customizer_file_url':
							case 'import_rev_slider_file_url':
							case 'import_redux':
							case 'image':
								$this->wbc_import_files[ $demo ][ $_key ] = $_import;
								break;
						}
					}
				}
			}
		}

		/**
		 * Get the demo folders/files
		 * Provided fallback where some host require FTP info
		 *
		 * @return array list of files for demos
		 */
		public function demoFiles() {
			$dir_array = array();

			$demo_directory = array_diff( scandir( $this->demo_data_dir ), array( '..', '.' ) );

			if ( ! empty( $demo_directory ) && is_array( $demo_directory ) ) {
				foreach ( $demo_directory as $key => $value ) {
					if ( is_dir( $this->demo_data_dir . $value ) ) {
						$demo_arr = array(
							'import_file_name'	 => ucwords( strtolower( str_replace( array( '_', '-' ), ' ', $value ) ) ),
							'files'				 => array(),
						);

						$demo_content = array_diff( scandir( $this->demo_data_dir . $value ), array( '..', '.' ) );

						foreach ( $demo_content as $d_key => $d_value ) {
							if ( is_file( $this->demo_data_dir . $value . '/' . $d_value ) ) {
								$filename							 = pathinfo( $d_value, PATHINFO_FILENAME );
								$demo_arr['files'][ $filename ]	 = $value . '/' . $d_value;
							}
						}
						$dir_array[ $value ] = $demo_arr;
					}
				}
			}
			return $dir_array;
		}

		public function getLocalImports() {
			$imports	 = $this->demoFiles();
			$imported	 = get_option( 'wbc_imported_demos' );
			$demo_dir	 = trailingslashit( str_replace( '\\', '/', $this->demo_data_dir ) );
			$demo_url	 = site_url( str_replace( trailingslashit( str_replace( '\\', '/', ABSPATH ) ), '', $demo_dir ) );

			if ( ! empty( $imports ) && is_array( $imports ) ) {
				foreach ( $imports as $key => $import ) {
					if ( ! isset( $import['files'] ) || empty( $import['files'] ) || empty( $import['import_file_name'] ) ) {
						continue;
					}

					$demo = 'wbc-import-' . $key;
					if ( ! array_key_exists( $demo, $this->wbc_import_files ) ) {
						$this->wbc_import_files[ $demo ] = array();
					}

					$this->wbc_import_files[ $demo ]['import_file_name'] = $import['import_file_name'];

					if ( ! empty( $imported ) && is_array( $imported ) ) {
						if ( array_key_exists( $demo, $imported ) ) {
							$this->wbc_import_files[ $demo ]['imported'] = 'imported';
						}
					}

					foreach ( $import['files'] as $filename => $file ) {
						switch ( $filename ) {
							case 'content':
								$this->wbc_import_files[ $demo ]['local_import_file']				 = $demo_dir . $file;
								break;
							case 'widgets':
								$this->wbc_import_files[ $demo ]['local_import_widget_file']		 = $demo_dir . $file;
								break;
							case 'customizer':
								$this->wbc_import_files[ $demo ]['local_import_customizer_file']	 = $demo_dir . $file;
								break;
							case 'sliders':
								$this->wbc_import_files[ $demo ]['local_import_rev_slider_file']	 = $demo_dir . $file;
								break;
							case 'redux':
								$this->wbc_import_files[ $demo ]['local_import_redux']			 = $demo_dir . $file;
								break;
							case 'screen-image':
								$this->wbc_import_files[ $demo ]['image']							 = $demo_url . $file;
								break;
						}
					}
				} // End foreach().
			} // End if().
		}

		public function addImportFiles( $wbc_import_files ) {

			if ( ! is_array( $wbc_import_files ) || empty( $wbc_import_files ) ) {
				$wbc_import_files = array();
			}

			$wbc_import_files = wp_parse_args( $wbc_import_files, $this->wbc_import_files );

			return $wbc_import_files;
		}

		/**
		 * Ajax Importer action
		 */
		public function ajax_importer() {
			$post_data = filter_input_array( INPUT_POST, array(
				'nonce'			 => FILTER_DEFAULT,
				'type'			 => FILTER_SANITIZE_STRING,
				'demo_import_id' => FILTER_SANITIZE_STRING,
				'wbc_import'	 => FILTER_SANITIZE_STRING,
				'subaction'		 => FILTER_SANITIZE_STRING,
			), true );
			if ( ! empty( $post_data['nonce'] ) && ! empty( $post_data['demo_import_id'] ) && wp_verify_nonce( $post_data['nonce'], sprintf( 'redux_%s_wbc_importer', $this->parent->args['opt_name'] ) ) ) {
				$imports = $this->demoImports();
				if ( array_key_exists( $post_data['demo_import_id'], $imports ) ) {
					$reimporting			 = 're-importing' == $post_data['wbc_import'];
					$this->active_import_id	 = $post_data['demo_import_id'];
					$this->active_import	 = $this->wbc_import_files[ $this->active_import_id ];
					$import_parts			 = $imports[ $post_data['demo_import_id'] ];
					if ( $reimporting || ! isset( $import_parts['imported'] ) ) {
						if ( ! class_exists( 'Merlin_Demo_Data_Importer' ) ) {
							include_once $this->extension_dir . 'inc/init-installer.php';
						}
						$importer = new Merlin_Demo_Data_Importer();
						$importer->initSettings( $this, $this->parent );
						$importer->action( $post_data['subaction'], $this->active_import_id );
					} else {
						wp_send_json( array(
							'error'		 => 1,
							'message'	 => esc_html( 'Demo Already Imported', '5th-avenue' )
						) );
					}
				}
			}
			die();
		}

		/**
		 * Instance
		 *
		 * @return \ReduxFramework_extension_wbc_importer
		 */
		public static function get_instance() {
			return self::$instance;
		}

		/**
		 * Forces the use of the embeded field path vs what the core typically would use.
		 *
		 * @param class $field
		 * @return string
		 */
		public function overload_field_path( $field ) {
			return dirname( __FILE__ ) . '/' . $this->field_name . '/field_' . $this->field_name . '.php';
		}

	}

} // End if().
