<?php
/**
 * The template for the panel header area.
 *
 * @package    5th-Avenue
 * @subpackage Redux
 * @version:    3.5.4.18
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

?>
<div id="av5-theme-core-options-header">
	<?php if ( ! empty( $this->parent->args['display_name'] ) ) { ?>
		<div class="display_header">
			<img src="<?php echo esc_url( get_template_directory_uri() . '/inc/options/assets/img/logo-white-va.png' ); ?>" height="17px"/> 
			<h2><?php echo wp_kses_post( $this->parent->args['display_name'] ); ?></h2>
			<?php if ( ! empty( $this->parent->args['display_version'] ) ) { ?>
				<span><?php echo wp_kses_post( $this->parent->args['display_version'] ); ?></span>
			<?php } ?> 
		</div>
	<?php } ?>

	<div class="clear"></div>
</div>
