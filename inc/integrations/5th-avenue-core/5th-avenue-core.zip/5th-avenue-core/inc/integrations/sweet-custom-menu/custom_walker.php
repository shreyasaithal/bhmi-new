<?php
/**
 * 5th-Avenue Custom Walker
 *
 * @package 5th-Avenue
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Custom Walker
 */
class av5_walker extends Walker_Nav_Menu { // @codingStandardsIgnoreLine PEAR.NamingConventions.ValidClassName.Invalid

	/**
	 * Starts the list before the elements are added.
	 *
	 * @since 3.0.0
	 *
	 * @see Walker::start_lvl()
	 *
	 * @param string   $output Used to append additional content (passed by reference).
	 * @param int      $depth  Depth of menu item. Used for padding.
	 * @param stdClass $args   An object of wp_nav_menu() arguments.
	 */
	public function start_lvl( &$output, $depth = 0, $args = array() ) {
		if ( isset( $args->item_spacing ) && 'discard' === $args->item_spacing ) {
			$t	 = '';
			$n	 = '';
		} else {
			$t	 = "\t";
			$n	 = "\n";
		}
		$indent = str_repeat( $t, $depth );

		// Default class.
		$classes = array( 'sub-menu' );

		$class_names = join( ' ', apply_filters( 'nav_menu_submenu_css_class', $classes, $args, $depth ) );
		$class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';

		if ( isset( $args->background_image ) && 0 < absint( $args->background_image ) ) {
			$background_image	 = absint( $args->background_image );
			$background_image	 = wp_get_attachment_image_src( $background_image, 'full' );
			if ( $background_image ) {
				$background_image = $background_image[0];
				$class_names .= ' style="background-image:url(' . $background_image . ')"';
			}
		}

		$output .= "{$n}{$indent}<ul$class_names>{$n}";
	}

	/**
	 * Starts the element output.
	 *
	 * @since 3.0.0
	 * @since 4.4.0 The {@see 'nav_menu_item_args'} filter was added.
	 *
	 * @see Walker::start_el()
	 *
	 * @param string   $output Used to append additional content (passed by reference).
	 * @param WP_Post  $item   Menu item data object.
	 * @param int      $depth  Depth of menu item. Used for padding.
	 * @param stdClass $args   An object of wp_nav_menu() arguments.
	 * @param int      $id     Current item ID.
	 */
	public function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
		if ( isset( $args->item_spacing ) && 'discard' === $args->item_spacing ) {
			$t	 = '';
			$n	 = '';
		} else {
			$t	 = "\t";
			$n	 = "\n";
		}
		$indent = ( $depth ) ? str_repeat( $t, $depth ) : '';

		$classes	 = empty( $item->classes ) ? array() : (array) $item->classes;
		$classes[]	 = 'menu-item-' . $item->ID;
		if ( $item->is_mega_menu ) {
			$classes[] = 'av5-multicolumn-menu';
		}
		if ( $item->full_width_menu ) {
			$classes[] = 'av5-fullwidth-menu';
		}
		if ( $item->mega_menu_text_bold ) {
			$classes[] = 'av5-multicolumn-menu--text-bold';
		}
		if ( $item->mega_menu_text_centered ) {
			$classes[] = 'align-center';
		}

		$image = '';

		if ( isset( $item->item_image ) && 0 < absint( $item->item_image ) ) {
			$image = wp_get_attachment_image( absint( $item->item_image ), 'post-thumbnail', false, array( 'class' => 'av5-menu-item-image' ) );
			if ( $image ) {
				$classes[] = 'menu-item-with-image';
			}
		}

		$args = apply_filters( 'nav_menu_item_args', $args, $item, $depth );

		$class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args, $depth ) );
		$class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';

		$id	 = apply_filters( 'nav_menu_item_id', 'menu-item-' . $item->ID, $item, $args, $depth );
		$id	 = $id ? ' id="' . esc_attr( $id ) . '"' : '';

		$output .= $indent . '<li' . $id . $class_names . '>';

		$atts				 = array();
		$atts['title']	 = ! empty( $item->attr_title ) ? $item->attr_title : '';
		$atts['target']	 = ! empty( $item->target ) ? $item->target : '';
		$atts['rel']		 = ! empty( $item->xfn ) ? $item->xfn : '';
		$atts['href']		 = ! empty( $item->url ) ? $item->url : '';

		$atts = apply_filters( 'nav_menu_link_attributes', $atts, $item, $args, $depth );

		$attributes = '';
		foreach ( $atts as $attr => $value ) {
			if ( ! empty( $value ) ) {
				$value = ( 'href' === $attr ) ? esc_url( $value ) : esc_attr( $value );
				$attributes .= ' ' . $attr . '="' . $value . '"';
			}
		}

		/** This filter is documented in wp-includes/post-template.php */
		$title = apply_filters( 'the_title', $item->title, $item->ID );

		$title = apply_filters( 'nav_menu_item_title', $title, $item, $args, $depth );

		$item_output = $args->before;
		$item_output .= '<a' . $attributes . '>';
		$item_output .= $args->link_before . $image . $title . $args->link_after;
		$item_output .= '</a>';
		$item_output .= $args->after;

		$output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );

		apply_filters( 'walker_nav_menu_start_lvl', $item_output, $depth, $args->background_image = $item->background_image );
	}

}
