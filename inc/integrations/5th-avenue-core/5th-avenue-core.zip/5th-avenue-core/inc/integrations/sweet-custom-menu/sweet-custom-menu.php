<?php
/**
 * Plugin Name: Sweet Custom Menu
 * Plugin URL: http://remicorson.com/sweet-custom-menu
 * Description: A little plugin to add attributes to WordPress menus
 * Version: 0.1
 * Author: Remi Corson
 * Author URI: http://remicorson.com
 * Contributors: corsonr
 * Text Domain: av5
 *
 * @package SweetCustomMenu
 */

/**
 * Sweet Custom Menu
 */
class av5_sweet_custom_menu { // @codingStandardsIgnoreLine PEAR.NamingConventions.ValidClassName.Invalid

	/**
	 * Initializes the plugin by setting localization, filters, and administration functions.
	 */
	function __construct() {

		add_action( 'load-nav-menus.php', array( $this, 'av5_add_media_js' ) );

		// Add custom menu fields to menu.
		add_filter( 'wp_setup_nav_menu_item', array( $this, 'av5_add_custom_nav_fields' ) );

		// Save menu custom fields.
		add_action( 'wp_update_nav_menu_item', array( $this, 'av5_update_custom_nav_fields' ), 10, 3 );

		// Edit menu walker.
		add_filter( 'wp_edit_nav_menu_walker', array( $this, 'av5_edit_walker' ), 10, 2 );
	}

	/**
	 * Add media js.
	 */
	function av5_add_media_js() {
		wp_enqueue_media();
	}

	/**
	 * Add custom fields to $item nav object
	 * in order to be used in custom Walker
	 *
	 * @access      public
	 * @since       1.0
	 */
	/**
	 * Add custom fields to $item nav object
	 * in order to be used in custom Walker
	 *
	 * @param type $menu_item Element menu.
	 * @return type
	 */
	function av5_add_custom_nav_fields( $menu_item ) {

		$menu_item->full_width_menu			 = get_post_meta( $menu_item->ID, '_menu_item_full_width_menu', true );
		$menu_item->is_mega_menu			 = get_post_meta( $menu_item->ID, '_menu_item_is_mega_menu', true );
		$menu_item->mega_menu_text_bold		 = get_post_meta( $menu_item->ID, '_menu_item_mega_menu_text_bold', true );
		$menu_item->mega_menu_text_centered	 = get_post_meta( $menu_item->ID, '_menu_item_mega_menu_text_centered', true );
		$menu_item->background_image		 = get_post_meta( $menu_item->ID, '_menu_item_background_image', true );
		$menu_item->item_image				 = get_post_meta( $menu_item->ID, '_menu_item_item_image', true );

		return $menu_item;
	}

	/**
	 * Save menu custom fields
	 *
	 * @access      public
	 * @since       1.0
	 */
	/**
	 * Update Custom nav fields
	 *
	 * @param int   $menu_id Menu item ID.
	 * @param int   $menu_item_db_id Menu item ID.
	 * @param array $args Menu item arguments.
	 */
	function av5_update_custom_nav_fields( $menu_id, $menu_item_db_id, $args ) {

		// Check if element is properly sent.
		if ( isset( $_REQUEST['menu-item-full_width_menu'] ) && is_array( $_REQUEST['menu-item-full_width_menu'] ) && array_key_exists( $menu_item_db_id, $_REQUEST['menu-item-full_width_menu'] ) ) { // @codingStandardsIgnoreLine WordPress.VIP.SuperGlobalInputUsage.AccessDetected
			$subtitle_value = $_REQUEST['menu-item-full_width_menu'][ $menu_item_db_id ]; // @codingStandardsIgnoreLine WordPress.VIP.SuperGlobalInputUsage.AccessDetected
			update_post_meta( $menu_item_db_id, '_menu_item_full_width_menu', $subtitle_value );
		} else {
			delete_post_meta( $menu_item_db_id, '_menu_item_full_width_menu' );
		}
		// Check if element is properly sent.
		if ( isset( $_REQUEST['menu-item-mega_menu_text_bold'] ) && is_array( $_REQUEST['menu-item-mega_menu_text_bold'] ) && array_key_exists( $menu_item_db_id, $_REQUEST['menu-item-mega_menu_text_bold'] ) ) { // @codingStandardsIgnoreLine WordPress.VIP.SuperGlobalInputUsage.AccessDetected
			$subtitle_value = $_REQUEST['menu-item-mega_menu_text_bold'][ $menu_item_db_id ]; // @codingStandardsIgnoreLine WordPress.VIP.SuperGlobalInputUsage.AccessDetected
			update_post_meta( $menu_item_db_id, '_menu_item_mega_menu_text_bold', $subtitle_value );
		} else {
			delete_post_meta( $menu_item_db_id, '_menu_item_mega_menu_text_bold' );
		}
		// Check if element is properly sent.
		if ( isset( $_REQUEST['menu-item-mega_menu_text_centered'] ) && is_array( $_REQUEST['menu-item-mega_menu_text_centered'] ) && array_key_exists( $menu_item_db_id, $_REQUEST['menu-item-mega_menu_text_centered'] ) ) { // @codingStandardsIgnoreLine WordPress.VIP.SuperGlobalInputUsage.AccessDetected
			$subtitle_value = $_REQUEST['menu-item-mega_menu_text_centered'][ $menu_item_db_id ]; // @codingStandardsIgnoreLine WordPress.VIP.SuperGlobalInputUsage.AccessDetected
			update_post_meta( $menu_item_db_id, '_menu_item_mega_menu_text_centered', $subtitle_value );
		} else {
			delete_post_meta( $menu_item_db_id, '_menu_item_mega_menu_text_centered' );
		}
		// Check if element is properly sent.
		if ( isset( $_REQUEST['menu-item-is_mega_menu'] ) && is_array( $_REQUEST['menu-item-is_mega_menu'] ) && array_key_exists( $menu_item_db_id, $_REQUEST['menu-item-is_mega_menu'] ) ) { // @codingStandardsIgnoreLine WordPress.VIP.SuperGlobalInputUsage.AccessDetected
			$subtitle_value = $_REQUEST['menu-item-is_mega_menu'][ $menu_item_db_id ]; // @codingStandardsIgnoreLine WordPress.VIP.SuperGlobalInputUsage.AccessDetected
			update_post_meta( $menu_item_db_id, '_menu_item_is_mega_menu', $subtitle_value );
		} else {
			delete_post_meta( $menu_item_db_id, '_menu_item_is_mega_menu' );
		}
		// Check if element is properly sent.
		if ( isset( $_REQUEST['menu-item-background_image'] ) && is_array( $_REQUEST['menu-item-background_image'] ) && array_key_exists( $menu_item_db_id, $_REQUEST['menu-item-background_image'] ) ) { // @codingStandardsIgnoreLine WordPress.VIP.SuperGlobalInputUsage.AccessDetected
			$subtitle_value = $_REQUEST['menu-item-background_image'][ $menu_item_db_id ]; // @codingStandardsIgnoreLine WordPress.VIP.SuperGlobalInputUsage.AccessDetected
			update_post_meta( $menu_item_db_id, '_menu_item_background_image', $subtitle_value );
		}
		// Check if element is properly sent.
		if ( isset( $_REQUEST['menu-item-item_image'] ) && is_array( $_REQUEST['menu-item-item_image'] ) && array_key_exists( $menu_item_db_id, $_REQUEST['menu-item-item_image'] ) ) { // @codingStandardsIgnoreLine WordPress.VIP.SuperGlobalInputUsage.AccessDetected
			$subtitle_value = $_REQUEST['menu-item-item_image'][ $menu_item_db_id ]; // @codingStandardsIgnoreLine WordPress.VIP.SuperGlobalInputUsage.AccessDetected
			update_post_meta( $menu_item_db_id, '_menu_item_item_image', $subtitle_value );
		}
	}

	/**
	 * Define new Walker edit
	 *
	 * @param string $walker Class name Walker for menu.
	 * @param int    $menu_id Menu item ID.
	 * @return string
	 */
	function av5_edit_walker( $walker, $menu_id ) {

		return 'Walker_Nav_Menu_Edit_Custom';
	}

}

// Instantiate plugin's class.
$GLOBALS['sweet_custom_menu'] = new av5_sweet_custom_menu();


include_once( 'edit_custom_walker.php' );
include_once( 'custom_walker.php' );
include_once( 'custom_walker_full_screen.php' );
