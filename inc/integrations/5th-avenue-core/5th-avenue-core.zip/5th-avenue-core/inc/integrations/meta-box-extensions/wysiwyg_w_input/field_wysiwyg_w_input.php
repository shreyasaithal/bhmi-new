<?php
/**
 * The WYSIWYG (editor) field.
 *
 * @package Meta Box
 */

defined( 'ABSPATH' ) || exit;

/**
 * WYSIWYG (editor) field class.
 */
class RWMB_Wysiwyg_W_Input_Field extends RWMB_Wysiwyg_Field {

	/**
	 * Extension Url
	 *
	 * @var string
	 */
	static $_extension_url;

	/**
	 * Wxtension Dir
	 *
	 * @var string
	 */
	static $_extension_dir;

	/**
	 * Enqueue scripts and styles.
	 */
	public static function admin_enqueue_scripts() {
		if ( empty( self::$_extension_dir ) ) {
			self::$_extension_dir	 = trailingslashit( str_replace( '\\', '/', dirname( __FILE__ ) ) );
			self::$_extension_url	 = site_url( str_replace( trailingslashit( str_replace( '\\', '/', ABSPATH ) ), '', self::$_extension_dir ) );
		}

		wp_enqueue_script( 'rwmb-wysiwyg-with-input', self::$_extension_url . 'field_wysiwyg_w_input.js', array( 'jquery' ), RWMB_VER, 'all' );
		wp_enqueue_style( 'rwmb-wysiwyg-with-input', self::$_extension_url . 'field_wysiwyg_w_input.css', '', RWMB_VER );
		parent::admin_enqueue_scripts();
	}

	/**
	 * Change field value on save.
	 *
	 * @param mixed $new     The submitted meta value.
	 * @param mixed $old     The existing meta value.
	 * @param int   $post_id The post ID.
	 * @param array $field   The field parameters.
	 * @return string
	 */
	public static function value( $new, $old, $post_id, $field ) {
		if ( isset( $new['content'] ) ) {
			$new['content'] = $field['raw'] ? $new['content'] : wpautop( $new['content'] );
		}

		return $new;
	}

	/**
	 * Get field HTML.
	 *
	 * @param mixed $meta  Meta value.
	 * @param array $field Field parameters.
	 * @return string
	 */
	public static function html( $meta, $field ) {
		// Using output buffering because wp_editor() echos directly.
		ob_start();

		foreach ( $field['inputs'] as $key => $label ) {
			printf( '<div class="wysiwyg-input"><label for="%s">%s<label/><input %s></div>', esc_attr( $field['id'] . '_' . $key ), $label, self::render_attributes( array(
					'value'	 => esc_attr( isset( $meta[ $key ] ) ? $meta[ $key ] : ( isset( $field['std'][ $key ] ) ? $field['std'][ $key ] : '' ) ), // @codingStandardsIgnoreLine WordPress.XSS.EscapeOutput.OutputNotEscaped
					'type'	 => 'text',
					'class'	 => 'rwmb-text rwmb-wysiwyg-input-' . esc_attr( $key ),
					'id'	 => esc_attr( $field['id'] . '_' . $key ),
					'name'	 => esc_attr( $field['field_name'] . '[' . $key . ']' ),
			) ) );
		}

		$field['options']['textarea_name']	 = $field['field_name'] . '[content]';
		$attributes								 = self::get_attributes( $field );

		// Use new wp_editor() since WP 3.3.
		wp_editor( $meta['content'], $attributes['id'], $field['options'] );

		return ob_get_clean();
	}

	/**
	 * Normalize parameters for field.
	 *
	 * @param array $field Field parameters.
	 * @return array
	 */
	public static function normalize( $field ) {
		$field	 = parent::normalize( $field );
		$field	 = wp_parse_args( $field, array(
			'multiple'	 => true,
			'inputs'	 => array(),
		) );

		return $field;
	}

}
