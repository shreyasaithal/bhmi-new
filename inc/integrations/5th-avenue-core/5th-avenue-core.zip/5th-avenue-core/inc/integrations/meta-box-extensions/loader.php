<?php
/**
 * 5th-Avenue loader meta box extensions.
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author LifeisDesign
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'av5_theme_core_rwbm_extension_loader' ) ) {

	/**
	 * Loading extetions
	 */
	function av5_theme_core_rwbm_extension_loader() {
		if ( ! class_exists( 'RWMB_Text_Field' ) ) {
			return;
		}
		$path	 = AV5C_PATH . 'inc/integrations/meta-box-extensions/';
		$folders = scandir( $path, 1 );
		foreach ( $folders as $folder ) {
			if ( '.' === $folder || '..' === $folder || ! is_dir( $path . $folder ) ) {
				continue;
			}
			$file = $path . $folder . DIRECTORY_SEPARATOR . 'field_' . $folder . '.php';
			if ( file_exists( $file ) ) {
				require_once $file;
			}
		}
	}
}

add_action( 'init', 'av5_theme_core_rwbm_extension_loader', 19 );
