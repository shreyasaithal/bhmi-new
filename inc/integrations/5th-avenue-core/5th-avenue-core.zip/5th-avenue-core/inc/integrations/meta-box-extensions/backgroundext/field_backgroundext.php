<?php
/**
 * The color field which uses WordPress color picker to select a color.
 *
 * @package Meta Box
 */

defined( 'ABSPATH' ) || exit;


/**
 * Color field class.
 */
class RWMB_Backgroundext_Field extends RWMB_Field {

	/**
	 * Extension url
	 *
	 * @var string
	 */
	static $_extension_url;

	/**
	 * Extension dir
	 *
	 * @var string
	 */
	static $_extension_dir;

	/**
	 * Enqueue scripts and styles.
	 */
	public static function admin_enqueue_scripts() {
		if ( empty( self::$_extension_dir ) ) {
			self::$_extension_dir	 = trailingslashit( str_replace( '\\', '/', dirname( __FILE__ ) ) );
			self::$_extension_url	 = site_url( str_replace( trailingslashit( str_replace( '\\', '/', ABSPATH ) ), '', self::$_extension_dir ) );
		}
		if ( function_exists( 'wp_enqueue_media' ) ) {
			wp_enqueue_media();
		} else {
			if ( ! wp_script_is( 'media-upload' ) ) {
				wp_enqueue_script( 'media-upload' );
			}
		}
		wp_register_script( 'select2-js', '//cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js', array( 'jquery' ), '4.0.3', true );
		wp_enqueue_script( 'rwbm-field-backgroundext-js', self::$_extension_url . 'field_backgroundext.js', array( 'jquery', 'wp-color-picker', 'select2-js' ), RWMB_VER, 'all' );
		wp_enqueue_style( 'rwbm-field-backgroundext', self::$_extension_url . 'field_backgroundext.css', array( 'wp-color-picker' ), RWMB_VER );
	}

	/**
	 * Get the attributes for a field.
	 *
	 * @param array $field Field parameters.
	 * @param mixed $value Meta value.
	 *
	 * @return array
	 */
	public static function get_attributes( $field, $value = null ) {
		$defaults	 = array(
			'background-color'		 => true,
			'background-repeat'		 => true,
			'background-attachment'	 => true,
			'background-position'	 => true,
			'background-image'		 => true,
			'background-gradient'	 => false,
			'background-clip'		 => false,
			'background-origin'		 => false,
			'background-size'		 => true,
			'preview_media'			 => false,
			'preview'				 => true,
			'preview_height'		 => '200px',
			'transparent'			 => true,
		);
		$attributes	 = parent::get_attributes( $field, $value );
		$attributes	 = wp_parse_args( $attributes, $defaults );

		return $attributes;
	}

	/**
	 * Get field HTML.
	 *
	 * @param mixed $meta  Meta value.
	 * @param array $field Field parameters.
	 * @return string
	 */
	public static function html( $meta, $field ) {
		$attributes		 = self::call( 'get_attributes', $field, $meta );
		$defaults		 = array(
			'background-color'		 => '',
			'background-repeat'		 => '',
			'background-attachment'	 => '',
			'background-position'	 => '',
			'background-image'		 => '',
			'background-clip'		 => '',
			'background-origin'		 => '',
			'background-size'		 => '',
			'media'					 => array(),
		);
		$meta			 = wp_parse_args( $meta, $defaults );
		$defaults		 = array(
			'id'		 => '',
			'width'		 => '',
			'height'	 => '',
			'thumbnail'	 => '',
		);
		$meta['media'] = wp_parse_args( $meta['media'], $defaults );

		$string = '<input type="hidden" ' . self::render_attributes( $attributes ) . '>';
		// select2 args
		if ( isset( $attributes['select2'] ) ) { // if there are any let's pass them to js.
			$select2_params	 = json_encode( $attributes['select2'] );
			$select2_params	 = htmlspecialchars( $select2_params, ENT_QUOTES );

			$string .= '<input type="hidden" class="select2_params" value="' . $select2_params . '">';
		}

		if ( true === $attributes['background-color'] ) {
			if ( isset( $meta['color'] ) && empty( $meta['background-color'] ) ) {
				$meta['background-color'] = $meta['color'];
			}

			$string .= '<input data-id="' . $attributes['id'] . '" name="' . $attributes['name'] . '[background-color]" id="' . $attributes['id'] . '-color" class="rwmb-color rwmb-background-input rwmb-color-init ' . $attributes['class'] . '"  type="text" value="' . $meta['background-color'] . '"  data-default-color="' . ( isset( $attributes['default']['background-color'] ) ? $attributes['default']['background-color'] : '' ) . '" />';
			$string .= '<input type="hidden" class="rwmb-saved-color" id="' . $attributes['id'] . '-saved-color' . '" value="">'; // @codingStandardsIgnoreLine Generic.Strings.UnnecessaryStringConcat.Found

			if ( ! isset( $attributes['transparent'] ) || false !== $attributes['transparent'] ) {
				$string .= '<label for="' . $attributes['id'] . '-transparency" class="color-transparency-check"><input type="checkbox" class="checkbox color-transparency rwmb-background-input ' . $attributes['class'] . '" id="' . $attributes['id'] . '-transparency" data-id="' . $attributes['id'] . '-color" value="1"' . checked( $meta['background-color'], 'transparent', false ) . '> ' . esc_html__( 'Transparent', 'meta-box' ) . '</label>';
			}

			if ( true === $attributes['background-repeat'] || true === $attributes['background-position'] || true === $attributes['background-attachment'] ) {
				$string .= '<br />';
			}
		}
		if ( true === $attributes['background-repeat'] ) {
			$array = array(
				'no-repeat'	 => 'No Repeat',
				'repeat'	 => 'Repeat All',
				'repeat-x'	 => 'Repeat Horizontally',
				'repeat-y'	 => 'Repeat Vertically',
				'inherit'	 => 'Inherit',
			);
			$string .= '<select id="' . $attributes['id'] . '-repeat-select" data-placeholder="' . esc_html__( 'Background Repeat', 'meta-box' ) . '" name="' . $attributes['name'] . '[background-repeat]" class="rwmb-select-item rwmb-background-input rwmb-background-repeat ' . $attributes['class'] . '">';
			$string .= '<option></option>';

			foreach ( $array as $k => $v ) {
				$string .= '<option value="' . $k . '"' . selected( $meta['background-repeat'], $k, false ) . '>' . $v . '</option>';
			}
			$string .= '</select>';
		}

		if ( true === $attributes['background-clip'] ) {
			$array = array(
				'inherit'		 => 'Inherit',
				'border-box'	 => 'Border Box',
				'content-box'	 => 'Content Box',
				'padding-box'	 => 'Padding Box',
			);
			$string .= '<select id="' . $attributes['id'] . '-repeat-select" data-placeholder="' . esc_html__( 'Background Clip', 'meta-box' ) . '" name="' . $attributes['name'] . '[background-clip]" class="rwmb-select-item rwmb-background-input rwmb-background-clip ' . $attributes['class'] . '">';
			$string .= '<option></option>';

			foreach ( $array as $k => $v ) {
				$string .= '<option value="' . $k . '"' . selected( $meta['background-clip'], $k, false ) . '>' . $v . '</option>';
			}
			$string .= '</select>';
		}

		if ( true === $attributes['background-origin'] ) {
			$array = array(
				'inherit'		 => 'Inherit',
				'border-box'	 => 'Border Box',
				'content-box'	 => 'Content Box',
				'padding-box'	 => 'Padding Box',
			);
			$string .= '<select id="' . $attributes['id'] . '-repeat-select" data-placeholder="' . esc_html__( 'Background Origin', 'meta-box' ) . '" name="' . $attributes['name'] . '[background-origin]" class="rwmb-select-item rwmb-background-input rwmb-background-origin ' . $attributes['class'] . '">';
			$string .= '<option></option>';

			foreach ( $array as $k => $v ) {
				$string .= '<option value="' . $k . '"' . selected( $meta['background-origin'], $k, false ) . '>' . $v . '</option>';
			}
			$string .= '</select>';
		}

		if ( true === $attributes['background-size'] ) {
			$array = array(
				'inherit'	 => 'Inherit',
				'cover'		 => 'Cover',
				'contain'	 => 'Contain',
			);
			$string .= '<select id="' . $attributes['id'] . '-repeat-select" data-placeholder="' . esc_html__( 'Background Size', 'meta-box' ) . '" name="' . $attributes['name'] . '[background-size]" class="rwmb-select-item rwmb-background-input rwmb-background-size ' . $attributes['class'] . '">';
			$string .= '<option></option>';

			foreach ( $array as $k => $v ) {
				$string .= '<option value="' . $k . '"' . selected( $meta['background-size'], $k, false ) . '>' . $v . '</option>';
			}
			$string .= '</select>';
		}

		if ( true === $attributes['background-attachment'] ) {
			$array = array(
				'fixed'		 => 'Fixed',
				'scroll'	 => 'Scroll',
				'inherit'	 => 'Inherit',
			);
			$string .= '<select id="' . $attributes['id'] . '-attachment-select" data-placeholder="' . esc_html__( 'Background Attachment', 'meta-box' ) . '" name="' . $attributes['name'] . '[background-attachment]" class="rwmb-select-item rwmb-background-input rwmb-background-attachment ' . $attributes['class'] . '">';
			$string .= '<option></option>';
			foreach ( $array as $k => $v ) {
				$string .= '<option value="' . $k . '"' . selected( $meta['background-attachment'], $k, false ) . '>' . $v . '</option>';
			}
			$string .= '</select>';
		}

		if ( true === $attributes['background-position'] ) {
			$array = array(
				'left top'		 => 'Left Top',
				'left center'	 => 'Left center',
				'left bottom'	 => 'Left Bottom',
				'center top'	 => 'Center Top',
				'center center'	 => 'Center Center',
				'center bottom'	 => 'Center Bottom',
				'right top'		 => 'Right Top',
				'right center'	 => 'Right center',
				'right bottom'	 => 'Right Bottom',
			);
			$string .= '<select id="' . $attributes['id'] . '-position-select" data-placeholder="' . esc_html__( 'Background Position', 'meta-box' ) . '" name="' . $attributes['name'] . '[background-position]" class="rwmb-select-item rwmb-background-input rwmb-background-position ' . $attributes['class'] . '">';
			$string .= '<option></option>';

			foreach ( $array as $k => $v ) {
				$string .= '<option value="' . $k . '"' . selected( $meta['background-position'], $k, false ) . '>' . $v . '</option>';
			}
			$string .= '</select>';
		}

		if ( true === $attributes['background-image'] ) {
			$string .= '<br />';

			if ( empty( $meta ) && ! empty( $attributes['default'] ) ) { // If there are standard values and value is empty.
				if ( is_array( $attributes['default'] ) ) {
					if ( ! empty( $attributes['default']['media']['id'] ) ) {
						$meta['media']['id'] = $attributes['default']['media']['id'];
					} else if ( ! empty( $attributes['default']['id'] ) ) {
						$meta['media']['id'] = $attributes['default']['id'];
					}

					if ( ! empty( $attributes['default']['url'] ) ) {
						$meta['background-image'] = $attributes['default']['url'];
					} else if ( ! empty( $attributes['default']['media']['url'] ) ) {
						$meta['background-image'] = $attributes['default']['media']['url'];
					} else if ( ! empty( $attributes['default']['background-image'] ) ) {
						$meta['background-image'] = $attributes['default']['background-image'];
					}
				} else {
					if ( is_numeric( $attributes['default'] ) ) { // Check if it's an attachment ID.
						$meta['media']['id'] = $attributes['default'];
					} else { // Must be a URL.
						$meta['background-image'] = $attributes['default'];
					}
				}
			}

			if ( empty( $meta['background-image'] ) && ! empty( $meta['media']['id'] ) ) {
				$img						 = wp_get_attachment_image_src( $meta['media']['id'], 'full' );
				$meta['background-image']	 = $img[0];
				$meta['media']['width']	 = $img[1];
				$meta['media']['height'] = $img[2];
			}

			$hide = 'hide ';

			if ( ( isset( $attributes['preview_media'] ) && false === $attributes['preview_media'] ) ) {
				$attributes['class'] .= ' noPreview';
			}

			if ( ( ! empty( $attributes['background-image'] ) && true === $attributes['background-image'] ) || isset( $attributes['preview'] ) && false === $attributes['preview'] ) {
				$hide = '';
			}

			$placeholder = isset( $attributes['placeholder'] ) ? $attributes['placeholder'] : esc_html__( 'No media selected', 'meta-box' );

			$string .= '<input placeholder="' . $placeholder . '" type="text" class="rwmb-background-input ' . $hide . 'upload ' . $attributes['class'] . '" name="' . $attributes['name'] . '[background-image]" id="' . 'rwmb' . '[' . $attributes['id'] . '][background-image]" value="' . $meta['background-image'] . '" />'; // @codingStandardsIgnoreLine Generic.Strings.UnnecessaryStringConcat.Found
			$string .= '<input type="hidden" class="upload-id ' . $attributes['class'] . '" name="' . $attributes['name'] . '[media][id]" id="' . 'rwmb' . '[' . $attributes['id'] . '][media][id]" value="' . $meta['media']['id'] . '" />'; // @codingStandardsIgnoreLine Generic.Strings.UnnecessaryStringConcat.Found
			$string .= '<input type="hidden" class="upload-height" name="' . $attributes['name'] . '[media][height]" id="' . 'rwmb' . '[' . $attributes['id'] . '][media][height]" value="' . $meta['media']['height'] . '" />'; // @codingStandardsIgnoreLine Generic.Strings.UnnecessaryStringConcat.Found
			$string .= '<input type="hidden" class="upload-width" name="' . $attributes['name'] . '[media][width]" id="' . 'rwmb' . '[' . $attributes['id'] . '][media][width]" value="' . $meta['media']['width'] . '" />'; // @codingStandardsIgnoreLine Generic.Strings.UnnecessaryStringConcat.Found
			$string .= '<input type="hidden" class="upload-thumbnail" name="' . $attributes['name'] . '[media][thumbnail]" id="' . 'rwmb' . '[' . $attributes['id'] . '][media][thumbnail]" value="' . $meta['media']['thumbnail'] . '" />'; // @codingStandardsIgnoreLine Generic.Strings.UnnecessaryStringConcat.Found

			// Preview.
			$hide = '';

			if ( ( isset( $attributes['preview_media'] ) && false === $attributes['preview_media'] ) || empty( $meta['background-image'] ) ) {
				$hide = 'hide ';
			}

			if ( empty( $meta['media']['thumbnail'] ) && ! empty( $meta['background-image'] ) ) { // Just in case.
				if ( ! empty( $meta['media']['id'] ) ) {
					$image							 = wp_get_attachment_image_src( $meta['media']['id'], array(
						150,
						150,
					) );
					$meta['media']['thumbnail']	 = $image[0];
				} else {
					$meta['media']['thumbnail'] = $meta['background-image'];
				}
			}

			$string .= '<div class="' . $hide . 'screenshot">';
			$string .= '<a class="of-uploaded-image" href="' . $meta['background-image'] . '" target="_blank">';
			$string .= '<img class="rwmb-option-image" id="image_' . $meta['media']['id'] . '" src="' . $meta['media']['thumbnail'] . '" alt="" target="_blank" rel="external" />';
			$string .= '</a>';
			$string .= '</div>';

			// Upload controls DIV.
			$string .= '<div class="upload_button_div">';

			// If the user has WP3.5+ show upload/remove button.
			$string .= '<span class="button rwmb-background-upload" id="' . $attributes['id'] . '-media">' . esc_html__( 'Upload', 'meta-box' ) . '</span>';

			$hide = '';
			if ( empty( $meta['background-image'] ) ) {
				$hide = ' hide';
			}

			$string .= '<span class="button removeCSS rwmb-remove-background' . $hide . '" id="reset_' . $attributes['id'] . '" rel="' . $attributes['id'] . '">' . esc_html__( 'Remove', 'meta-box' ) . '</span>';

			$string .= '</div>';
		} // End if().
		return $string;
	}

}
