/* global jQuery, _, google */
( function ( $, window, document ) {
    'use strict';
    function check_slug() {
        var value = $( this ).val();
        $( this ).val( value.replace( /[^a-zA-Z0-9-_]/g, '' ) );
    }
    $( function ( $ ) {
        $( 'body' ).on( 'keyup,change', '.rwmb-wysiwyg-input-slug', check_slug );
        $( '.rwmb-wysiwyg-input-slug' ).each( check_slug );
    } );
} )( jQuery, window, document );