<?php
/**
 * 5th-Avenue basic class for widget.
 *
 * @package    5th-Avenue
 * @subpackage Widget
 * @version 1.0.0
 * @author lifeis.design
 */

/**
 * Basic class for widget.
 */
class AV5_WidgetBasic extends WP_Widget {

	/**
	 * 3600 sec - Hour
	 */
	const EXPIRATION_HOUR = 3600;

	/**
	 * Widget Prefix
	 *
	 * @var string
	 */
	protected $prefix = 'AV5';

	/**
	 * Widget Prefix Name
	 *
	 * @var string
	 */
	protected $prefix_name = '5th Avenue';

	/**
	 * Textdomain for translation
	 *
	 * @var string
	 */
	protected $textdomain;

	/**
	 * Class name
	 *
	 * @var string
	 */
	protected $classname = '';

	/**
	 * Required if more than 250px
	 *
	 * @var int
	 */
	protected $width = 200;

	/**
	 * Currently not used but may be needed in the future
	 *
	 * @var int
	 */
	protected $height = 350;

	/**
	 * Shown on the configuration page.
	 *
	 * @var string
	 */
	protected $description = '';

	/**
	 * Name
	 *
	 * @var string
	 */
	protected $__name = '';

	/**
	 * Part of base_id. THEMENAME-{__id}
	 *
	 * @var type
	 */
	protected $__id = '';

	/**
	 * Delimiter between the name of the THEME and the name of the widget <br/>
	 * displayed on the configuration page
	 *
	 * @var string
	 */
	protected $name_delimiter = ' &rarr; ';

	/**
	 *  Wiget constructor
	 */
	function __construct() {
		parent::__construct( $this->getBaseId(), $this->getTranslatedName(), $this->getWidgetOption(), $this->getWidgetControlOption() );

		add_action( 'save_post', array( $this, 'flush_widget_cache' ) );
		add_action( 'deleted_post', array( $this, 'flush_widget_cache' ) );
		add_action( 'switch_theme', array( $this, 'flush_widget_cache' ) );
	}

	/**
	 * Set Widget name
	 * for the widget displayed on the configuration page
	 *
	 * @param string $name Name for widget.
	 */
	protected function setName( $name ) {
		$this->__name = $name;
	}

	/**
	 * Get widget name
	 * for the widget displayed on the configuration page
	 *
	 * @return string
	 */
	public function getName() {
		return $this->__name;
	}

	/**
	 * Set widget description for shown on the configuration page
	 *
	 * @param string $description Shown on the configuration page.
	 */
	public function setDescription( $description ) {
		$this->description = $description;
	}

	/**
	 * Get widget description for shown on the configuration page
	 *
	 * @return string
	 */
	public function getDescription() {
		return $this->description;
	}

	/**
	 * Set suffix part of id_base (THEMENAME-{suffix})
	 *
	 * @param string $suffix Theme sufix.
	 */
	protected function setIdSuffix( $suffix ) {
		$this->__id = $suffix;
	}

	/**
	 * Get suffix part of id_base (THEMNAME-{suffix})
	 *
	 * @return string
	 */
	protected function getIdSuffix() {
		return $this->__id;
	}

	/**
	 * Get wigget prefix( lowercase THEMNAME)
	 *
	 * @return string
	 */
	public function getPrefix() {
		return $this->prefix;
	}

	/**
	 * Get  Base ID for the widget, lower case,
	 * if left empty a portion of the widget's class name will be used. Has to be unique.
	 *
	 * @return string
	 */
	protected function getBaseId() {
		$base_id = "{$this->getPrefix()}-{$this->getIdSuffix()}";
		return strtolower( $base_id );
	}

	/**
	 * Set Delimetr for the THEMANAME and widget name displayed on the configuration page
	 *
	 * @param string $name_delimiter Delimiter for name.
	 */
	protected function setNameDelimiter( $name_delimiter ) {
		$this->name_delimiter = $name_delimiter;
	}

	/**
	 * Get Delimetr for the THEMANAME and widget name displayed on the configuration page
	 *
	 * @return string
	 */
	protected function getNameDelimiter() {

		return $this->name_delimiter;
	}

	/**
	 * Translated name for the widget displayed on the configuration page/
	 *
	 * @return string
	 */
	protected function getTranslatedName() {
		return $this->prefix_name . $this->getNameDelimiter() . $this->getName();
	}

	/**
	 * Set widget classname
	 *
	 * @param string $classname Class Nmae.
	 */
	public function setClassName( $classname ) {
		$this->classname = $classname;
	}

	/**
	 * Get widget classname
	 *
	 * @return string
	 */
	public function getClassName() {

		return $this->classname;
	}

	/**
	 * Get classname and translated description
	 *
	 * @return array Optional Passed to wp_register_sidebar_widget()
	 *  - classname:
	 *  - description: shown on the configuration page
	 */
	protected function getWidgetOption() {
		return array(
			'classname'		 => $this->getClassName(),
			'description'	 => $this->getDescription(),
		);
	}

	/**
	 * Get wodget control data
	 *
	 * @return array Passed to wp_register_widget_control()
	 * 	 - width: required if more than 250px
	 * 	 - height: currently not used but may be needed in the future
	 * 	 - id_base:
	 */
	protected function getWidgetControlOption() {
		return array(
			'width'		 => $this->getWidth(),
			'height'	 => $this->getHeight(),
			'id_base'	 => $this->getBaseId(),
		);
	}

	/**
	 * Set width for widget
	 *
	 * @param int $width Width.
	 */
	public function setWidth( $width ) {
		$this->width = $width;
	}

	/**
	 * Get width for widget
	 *
	 * @return int
	 */
	public function getWidth() {
		return $this->width;
	}

	/**
	 * Set height for widget
	 *
	 * @param int $height Height.
	 */
	public function setHeight( $height ) {
		$this->height = $height;
	}

	/**
	 * Get height for widget
	 *
	 * @return int
	 */
	public function getHeight() {
		return $this->height;
	}

	/**
	 * Check is plugin wpml is active
	 *
	 * @return boolean
	 */
	protected function isWPML_PluginActive() {
		return defined( 'ICL_LANGUAGE_CODE' );
	}

	/**
	 * Default field values
	 *
	 * @return array
	 */
	public function getDefaultFieldValues() {
		return array(
			'title' => $this->getName(),
		);
	}

	/**
	 * Vaidation flags for field values
	 *
	 * @see http://php.net/manual/en/filter.filters.php
	 *
	 * @return array
	 */
	public function vaidateFieldValues() {
		return array(
			'title' => array(
				'filter' => FILTER_DEFAULT,
				'flags'	 => FILTER_FLAG_STRIP_LOW,
			),
		);
	}

	/**
	 * If need sanitize values after validation
	 *
	 * @param array $values Array with values.
	 * @return array
	 */
	public function sanitizeValues( $values ) {
		return $values;
	}

	/**
	 * Update value after save widget.
	 *
	 * @param array $new_instance New value.
	 * @param array $old_instance Old value.
	 * @return array
	 */
	public function update( $new_instance, $old_instance ) {
		$instance	 = wp_parse_args( filter_var_array( $new_instance, $this->vaidateFieldValues(), true ), $old_instance );
		$instance	 = wp_parse_args( $instance, $this->getDefaultFieldValues() );
		$instance	 = $this->sanitizeValues( $instance );
		$this->flush_widget_cache();
		return $instance;
	}

	/**
	 * Output widget
	 *
	 * @param array $args Arguments for widgets.
	 * @param array $instance Value array.
	 */
	public function widget( $args, $instance ) {
		$this->widget_start( $args, $instance );
		esc_html_e( 'Please rewrite this function', '5th-avenue' );
		$this->widget_end( $args, $instance );
	}

	/**
	 * Output start widget
	 *
	 * @param array $args Arguments for widgets.
	 * @param array $instance Value array.
	 */
	public function widget_start( $args, $instance ) {
		echo  $args['before_widget']; // WPCS: xss ok.
		if ( array_key_exists( 'title', $instance ) ) {
			$title = apply_filters( 'widget_title', $instance['title'] );
			if ( $title ) {
				echo  $args['before_title'] . esc_html( $title ) . $args['after_title']; // WPCS: xss ok.
			}
		}
	}

	/**
	 * Output start widget
	 *
	 * @param array $args Arguments for widgets.
	 * @param array $instance Value array.
	 */
	public function widget_end( $args, $instance ) {
		echo  $args['after_widget']; // WPCS: xss ok.
	}

	/**
	 * Form for update widget.
	 *
	 * @param array $instance Value array.
	 */
	public function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, $this->getDefaultFieldValues() );
		?>
		<div>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html( $labels['title'] ); ?>: </label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" value="<?php echo esc_attr( $instance['title'] ); ?>" type="text">
			</p>
		</div>
		<div style="clear:both;">&nbsp;</div>
		<?php
	}

	/**
	 * Get cached widget.
	 *
	 * @param  array $args Attributes for widget.
	 * @return bool true if the widget is cached otherwise false
	 */
	public function get_cached_widget( $args ) {
		$cache = get_transient( $this->getBaseId() );

		if ( ! is_array( $cache ) ) {
			$cache = array();
		}

		if ( isset( $cache[ $args['widget_id'] ] ) ) {
			echo  $cache[ $args['widget_id'] ]; // WPCS: xss ok.
			return true;
		}

		return false;
	}

	/**
	 * Cache the widget.
	 *
	 * @param  array  $args Attributes for widget.
	 * @param  string $content Content widget.
	 * @return string the content that was cached
	 */
	public function cache_widget( $args, $content ) {
		$cache = get_transient( $this->getBaseId() );

		if ( ! is_array( $cache ) ) {
			$cache = array();
		}

		$cache[ $args['widget_id'] ] = $content;
		set_transient( $this->getBaseId(), $cache, self::EXPIRATION_HOUR );

		return $content;
	}

	/**
	 * Flush the cache.
	 */
	public function flush_widget_cache() {
		delete_transient( $this->getBaseId() );
	}

}
