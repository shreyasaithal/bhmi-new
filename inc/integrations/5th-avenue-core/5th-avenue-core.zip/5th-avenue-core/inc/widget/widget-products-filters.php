<?php
/**
 * 5th-Avenue widget Products Filters.
 *
 * @package    5th-Avenue
 * @subpackage Widget
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

if ( ! av5_is_woocommerce_activated() || ! class_exists( 'AV5_Products_Filter' ) ) {
	return;
}

/**
 * Widget Products Filters.
 */
class AV5_Widget_Products_Filters extends AV5_WidgetBasic {

	/**
	 * Create Widget for Products Filters
	 */
	function __construct() {
		$this->setName( esc_html__( 'Products Filters', '5th-avenue' ) );
		$this->setDescription( esc_html__( 'Show filter for products', '5th-avenue' ) );
		$this->setIdSuffix( 'products-filters' );
		$this->setClassName( get_class( $this ) );
		parent::__construct();
	}

	/**
	 * Default field values
	 *
	 * @return array
	 */
	public function getDefaultFieldValues() {
		return array(
			'title'			 => $this->getName(),
			'use_cat'		 => true,
			'use_attributes' => true,
			'use_tag'		 => true,
			'use_price'		 => true,
			'add_all'		 => true,
		);
	}

	/**
	 * Default field values
	 *
	 * @return array
	 */
	public function getLabelField() {
		return array(
			'title'			 => esc_html__( 'Title', '5th-avenue' ),
			'use_cat'		 => esc_html__( 'Display Categories filter', '5th-avenue' ),
			'use_attributes' => esc_html__( 'Display Attributes filter', '5th-avenue' ),
			'use_tag'		 => esc_html__( 'Display Tags filter', '5th-avenue' ),
			'use_price'		 => esc_html__( 'Display Price filter', '5th-avenue' ),
			'add_all'		 => esc_html__( 'Display Add all', '5th-avenue' ),
		);
	}

	/**
	 * Vaidation flags for field values
	 *
	 * @return array
	 */
	public function vaidateFieldValues() {
		return array(
			'title'			 => array(
				'filter' => FILTER_SANITIZE_STRING,
				'flags'	 => FILTER_FLAG_STRIP_LOW,
			),
			'use_cat'		 => FILTER_VALIDATE_BOOLEAN,
			'use_attributes' => FILTER_VALIDATE_BOOLEAN,
			'use_tag'		 => FILTER_VALIDATE_BOOLEAN,
			'use_price'		 => FILTER_VALIDATE_BOOLEAN,
			'add_all'		 => FILTER_VALIDATE_BOOLEAN,
		);
	}

	/**
	 * Form for update widget.
	 *
	 * @param array $instance Value array.
	 */
	function form( $instance ) {
		$instance	 = wp_parse_args( (array) $instance, $this->getDefaultFieldValues() );
		$labels		 = $this->getLabelField();
		?>
		<div>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html( $labels['title'] ); ?>: </label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" value="<?php echo esc_attr( $instance['title'] ); ?>" type="text">
			</p>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'use_cat' ) ); ?>"><?php echo esc_html( $labels['use_cat'] ); ?>: </label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'use_cat' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'use_cat' ) ); ?>" value="on" type="checkbox"  <?php checked( $instance['use_cat'] ); ?>>
			</p>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'use_attributes' ) ); ?>"><?php echo esc_html( $labels['use_attributes'] ); ?>: </label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'use_attributes' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'use_attributes' ) ); ?>" value="on" type="checkbox"  <?php checked( $instance['use_attributes'] ); ?>>
			</p>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'use_tag' ) ); ?>"><?php echo esc_html( $labels['use_tag'] ); ?>: </label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'use_tag' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'use_tag' ) ); ?>" value="on" type="checkbox"  <?php checked( $instance['use_tag'] ); ?>>
			</p>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'use_price' ) ); ?>"><?php echo esc_html( $labels['use_price'] ); ?>: </label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'use_price' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'use_price' ) ); ?>" value="on" type="checkbox"  <?php checked( $instance['use_price'] ); ?>>
			</p>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'add_all' ) ); ?>"><?php echo esc_html( $labels['add_all'] ); ?>: </label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'add_all' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'add_all' ) ); ?>" value="on" type="checkbox"  <?php checked( $instance['add_all'] ); ?>>
			</p>
		</div>
		<div style="clear:both;">&nbsp;</div>
		<?php
	}

	/**
	 * Echoes the widget content.
	 *
	 * Sub-classes should over-ride this function to generate their widget code.
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance The settings for the particular instance of the widget.
	 */
	function widget( $args, $instance ) {
		global $widget_instance;
		if ( ! av5_is_woocommerce_activated() ) {
			return;
		}
		if ( ! is_shop() && ! is_product_taxonomy() ) {
			return;
		}
		ob_start();
		$this->widget_start( $args, $instance );
		$data = AV5_Products_Filter::get_elements( $instance['use_cat'], $instance['use_attributes'], $instance['use_tag'], $instance['use_price'] );

		$data['element_all'] = $instance['add_all'];

		if ( ! empty( $data['product_cat'] ) ) {
			$data['product_cat'] = get_terms( array(
				'taxonomy'			 => 'product_cat',
				'term_taxonomy_id'	 => $data['product_cat'],
			) );
		}
		if ( ! empty( $data['product_tag'] ) ) {
			$data['product_tag'] = get_terms( array(
				'taxonomy'			 => 'product_tag',
				'term_taxonomy_id'	 => $data['product_tag'],
			) );
		}
		if ( ! empty( $data['product_price'] ) ) {
			/**
			 * This code is taken from widget functionality
			 *
			 * @see \WC_Widget_Price_Filter
			 */
			$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
			wp_register_script( 'accounting', WC()->plugin_url() . '/assets/js/accounting/accounting' . $suffix . '.js', array( 'jquery' ), '0.4.2' );
			wp_register_script( 'wc-jquery-ui-touchpunch', WC()->plugin_url() . '/assets/js/jquery-ui-touch-punch/jquery-ui-touch-punch' . $suffix . '.js', array( 'jquery-ui-slider' ), WC_VERSION, true );
			wp_register_script( 'wc-price-slider', WC()->plugin_url() . '/assets/js/frontend/price-slider' . $suffix . '.js', array( 'jquery-ui-slider', 'wc-jquery-ui-touchpunch', 'accounting' ), WC_VERSION, true );
			wp_localize_script( 'wc-price-slider', 'woocommerce_price_slider_params', array(
				'currency_format_num_decimals'	 => 0,
				'currency_format_symbol'		 => get_woocommerce_currency_symbol(),
				'currency_format_decimal_sep'	 => esc_attr( wc_get_price_decimal_separator() ),
				'currency_format_thousand_sep'	 => esc_attr( wc_get_price_thousand_separator() ),
				'currency_format'				 => esc_attr( str_replace( array( '%1$s', '%2$s' ), array( '%s', '%v' ), get_woocommerce_price_format() ) ),
			) );
		}

		$get_keys = array_keys( $_GET );
		foreach ( $get_keys as $k => $get_key ) {
			if ( in_array( $get_key, array( 'min_price', 'max_price', 'av5_product_cat', 'av5_product_tag' ) ) ) {
				continue;
			}
			if ( preg_match( '/^av5a_/i', $get_key ) ) {
				continue;
			}
			if ( preg_match( '/^filter_/i', $get_key ) ) {
				continue;
			}
			unset( $get_keys[ $k ] );
		}
		$data['need_clean']	 = $get_keys;
		$data['prefix']		 = 'widget';

		$widget_instance = $data;

		av5c_get_template_part( 'widgets/products-filters' );

		$this->widget_end( $args, $instance );
		$content = ob_get_clean();
		echo  $content; // WPCS: xss ok.
	}

}
