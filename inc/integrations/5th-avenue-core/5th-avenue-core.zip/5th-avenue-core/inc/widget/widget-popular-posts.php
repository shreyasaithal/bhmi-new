<?php
/**
 * 5th-Avenue widget Popular Posts.
 *
 * @package    5th-Avenue
 * @subpackage Widget
 * @version 1.0.0
 * @author lifeis.design
 */

/**
 * Widget Popular Posts.
 */
class AV5_Widget_Popular_Posts extends AV5_WidgetBasic {

	/**
	 * Init Widget Popular Posts.
	 */
	function __construct() {
		$this->setName( esc_html__( 'Popular posts', '5th-avenue' ) );
		$this->setDescription( esc_html__( 'Show popular posts', '5th-avenue' ) );
		$this->setIdSuffix( 'popular-posts' );
		$this->setClassName( get_class( $this ) );
		parent::__construct();
	}

	/**
	 * Default field values
	 *
	 * @return array
	 */
	public function getDefaultFieldValues() {
		return array(
			'title'				 => $this->getName(),
			'number'			 => 5,
			'post_style'		 => 'default',
			'post_thumb'		 => true,
			'post_thumb_width'	 => 100,
			'post_thumb_height'	 => 100,
			'post_thumb_style'	 => 'square',
			'post_read_more'	 => true,
			'post_excerpt'		 => true,
			'post_cat'			 => true,
		);
	}

	/**
	 * Default field values
	 *
	 * @return array
	 */
	public function getLabelField() {
		return array(
			'title'				 => esc_html__( 'Title', '5th-avenue' ),
			'number'			 => esc_html__( 'Number of posts to show', '5th-avenue' ),
			'post_style'		 => esc_html__( 'Style post', '5th-avenue' ),
			'post_thumb'		 => esc_html__( 'Display post thumb', '5th-avenue' ),
			'post_thumb_width'	 => esc_html__( 'Size thumb', '5th-avenue' ),
			'post_thumb_height'	 => esc_html__( 'Size thumb', '5th-avenue' ),
			'post_thumb_style'	 => esc_html__( 'Style thumb', '5th-avenue' ),
			'post_read_more'	 => esc_html__( 'Display read more link', '5th-avenue' ),
			'post_excerpt'		 => esc_html__( 'Display post excerpt', '5th-avenue' ),
			'post_cat'			 => esc_html__( 'Display category', '5th-avenue' ),
		);
	}

	/**
	 * Vaidation flags for field values
	 *
	 * @return array
	 */
	public function vaidateFieldValues() {
		return array(
			'title'				 => array(
				'filter' => FILTER_SANITIZE_STRING,
				'flags'	 => FILTER_FLAG_STRIP_LOW,
			),
			'number'			 => array(
				'filter'	 => FILTER_VALIDATE_INT,
				'options'	 => array(
					'min_range'	 => 1,
					'max_range'	 => 10,
					'default'	 => 5,
				),
			),
			'post_style'		 => array(
				'filter' => FILTER_SANITIZE_STRING,
				'flags'	 => FILTER_FLAG_STRIP_LOW,
			),
			'post_thumb'		 => FILTER_VALIDATE_BOOLEAN,
			'post_thumb_width'	 => array(
				'filter'	 => FILTER_VALIDATE_INT,
				'options'	 => array(
					'default' => 100,
				),
			),
			'post_thumb_height'	 => array(
				'filter'	 => FILTER_VALIDATE_INT,
				'options'	 => array(
					'default' => 100,
				),
			),
			'post_thumb_style'	 => array(
				'filter' => FILTER_SANITIZE_STRING,
				'flags'	 => FILTER_FLAG_STRIP_LOW,
			),
			'post_read_more'	 => FILTER_VALIDATE_BOOLEAN,
			'post_excerpt'		 => FILTER_VALIDATE_BOOLEAN,
			'post_cat'			 => FILTER_VALIDATE_BOOLEAN,
		);
	}

	/**
	 * Form for update widget.
	 *
	 * @param array $instance Value array.
	 */
	function form( $instance ) {
		$instance	 = wp_parse_args( (array) $instance, $this->getDefaultFieldValues() );
		$labels		 = $this->getLabelField();
		?>
		<div>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html( $labels['title'] ); ?>: </label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" value="<?php echo esc_attr( $instance['title'] ); ?>" type="text">
			</p>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php echo esc_html( $labels['number'] ); ?>: </label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" value="<?php echo esc_attr( $instance['number'] ); ?>" type="number" min="1" max="10">
			</p>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'post_style' ) ); ?>"><?php echo esc_html( $labels['post_style'] ); ?>: </label>
				<select id="<?php echo esc_attr( $this->get_field_id( 'post_style' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'post_style' ) ); ?>">
					<option value="default" <?php selected( $instance['post_style'], 'default' ); ?>>Default</option>
					<option value="featured" <?php selected( $instance['post_style'], 'featured' ); ?>>Featured</option>
				</select>
			</p>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'post_thumb' ) ); ?>"><?php echo esc_html( $labels['post_thumb'] ); ?>: </label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'post_thumb' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'post_thumb' ) ); ?>" value="on" type="checkbox"  <?php checked( $instance['post_thumb'] ); ?>>
			</p>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'post_thumb_style' ) ); ?>"><?php echo esc_html( $labels['post_thumb_style'] ); ?>: </label>
				<select id="<?php echo esc_attr( $this->get_field_id( 'post_thumb_style' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'post_thumb_style' ) ); ?>">
					<option value="square" <?php selected( $instance['post_thumb_style'], 'square' ); ?>>Square</option>
					<option value="rounded" <?php selected( $instance['post_thumb_style'], 'rounded' ); ?>>Rounded</option>
				</select>
			</p>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'post_thumb_width' ) ); ?>"><?php echo esc_html( $labels['post_thumb_width'] ); ?>: </label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'post_thumb_width' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'post_thumb_width' ) ); ?>" value="<?php echo esc_attr( $instance['post_thumb_width'] ); ?>" type="number"> x <input id="<?php echo esc_attr( $this->get_field_id( 'post_thumb_height' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'post_thumb_height' ) ); ?>" value="<?php echo esc_attr( $instance['post_thumb_height'] ); ?>" type="number">
			</p>			
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'post_cat' ) ); ?>"><?php echo esc_html( $labels['post_cat'] ); ?>: </label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'post_cat' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'post_cat' ) ); ?>" value="on" type="checkbox"  <?php checked( $instance['post_cat'] ); ?>>
			</p>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'post_excerpt' ) ); ?>"><?php echo esc_html( $labels['post_excerpt'] ); ?>: </label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'post_excerpt' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'post_excerpt' ) ); ?>" value="on" type="checkbox"  <?php checked( $instance['post_excerpt'] ); ?>>
			</p>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'post_read_more' ) ); ?>"><?php echo esc_html( $labels['post_read_more'] ); ?>: </label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'post_read_more' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'post_read_more' ) ); ?>" value="on" type="checkbox"  <?php checked( $instance['post_read_more'] ); ?>>
			</p>
		</div>
		<div style="clear:both;">&nbsp;</div>
		<script>
		    jQuery( '#<?php echo esc_attr( $this->get_field_id( 'post_thumb' ) ); ?>' ).change( function () {
		        jQuery( '#<?php echo esc_attr( $this->get_field_id( 'post_thumb_width' ) ); ?>, #<?php echo esc_attr( $this->get_field_id( 'post_thumb_style' ) ); ?>' ).closest( 'p' ).toggle( jQuery( this ).is( ':checked' ) );
		    } ).trigger( 'change' );
		    jQuery( '#<?php echo esc_attr( $this->get_field_id( 'post_style' ) ); ?>' ).change( function () {
		        jQuery( '#<?php echo esc_attr( $this->get_field_id( 'post_read_more' ) ); ?>' ).closest( 'p' ).toggle( 'featured' === jQuery( this ).val() );
		    } ).trigger( 'change' );
		    jQuery( '#<?php echo esc_attr( $this->get_field_id( 'post_style' ) ); ?>' ).change( function () {
		        jQuery( '#<?php echo esc_attr( $this->get_field_id( 'post_excerpt' ) ); ?>' ).closest( 'p' ).toggle( 'featured' === jQuery( this ).val() );
		    } ).trigger( 'change' );
		</script>
		<?php
	}

	/**
	 * Echoes the widget content.
	 *
	 * Sub-classes should over-ride this function to generate their widget code.
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance The settings for the particular instance of the widget.
	 */
	function widget( $args, $instance ) {
		global $widget_instance;
		if ( $this->get_cached_widget( $args ) ) {
			return;
		}

		$widget_instance = $instance;
		ob_start();
		$recent_posts	 = new WP_Query( array(
			'posts_per_page'		 => $instance['number'],
			'orderby'				 => 'comment_count',
			'post_status'			 => 'publish',
			'ignore_sticky_posts'	 => true,
		) );
		if ( $recent_posts->have_posts() ) :
			$this->widget_start( $args, $instance );
			?><ul class="widget--style-<?php echo esc_attr( $instance['post_style'] ) . esc_attr( $instance['post_thumb'] ? ' widget-thumbnail widget-thumbnail--style-' . $instance['post_thumb_style'] : '' ); ?>"><?php
while ( $recent_posts->have_posts() ) {
	$recent_posts->the_post();
	av5c_get_template_part( 'widgets/popular-posts', $instance['post_style'] );
}
wp_reset_postdata();
				?></ul><?php
			$this->widget_end( $args, $instance );
		endif;
		$content = ob_get_clean();
		echo  $content; // WPCS: xss ok.
		$this->cache_widget( $args, $content );
	}

}
