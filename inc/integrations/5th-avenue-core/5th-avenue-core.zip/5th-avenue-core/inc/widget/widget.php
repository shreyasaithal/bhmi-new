<?php
/**
 * 5th-Avenue register widgets.
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'AV5_WidgetBasic' ) ) {
	require_once AV5C_PATH . '/inc/widget/base-widget.php';
}

if ( ! function_exists( 'av5c_register_widgets' ) ) {
	/**
	 * Register widgets
	 */
	function av5c_register_widgets() {
		$paths = glob( AV5C_PATH . 'inc' . DIRECTORY_SEPARATOR . 'widget' . DIRECTORY_SEPARATOR . 'widget-*.php' );
		foreach ( $paths as $path ) {
			$basename = basename( $path );
			$basename = str_replace( array( 'widget-', '.php', '-' ), array( '', '', ' ' ), $basename );
			$basename = ucwords( $basename );
			$basename = ucwords( $basename );
			$basename = str_replace( ' ', '_', $basename );
			$class_name = 'AV5_Widget_' . $basename;
			require_once $path;
			register_widget( $class_name );
		}
	}
}

add_action( 'widgets_init', 'av5c_register_widgets' );
