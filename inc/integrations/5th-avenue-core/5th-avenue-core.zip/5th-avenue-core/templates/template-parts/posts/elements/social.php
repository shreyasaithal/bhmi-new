<?php
/**
 * 5th-Avenue post social share element
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

?>
<ul class="single-post__social simple-social-icons">
	<?php if ( av5_get_option( 'blog-post-social-twitter' ) ) : ?>
		<li><a target="_blank" class="av5-social-button" href="<?php
			$cur_post = get_post();
			echo esc_url( 'https://twitter.com/intent/tweet?' . http_build_query( array(
				'text'	 => $cur_post->post_title,
				'url'	 => get_permalink(),
			) ) );
			?>"><i class="fa fa-twitter"></i> </a></li>
			<?php endif; ?>
			<?php if ( av5_get_option( 'blog-post-social-facebook' ) ) : ?>
		<li><a target="_blank" class="av5-social-button" href="<?php echo esc_url( 'https://www.facebook.com/sharer/sharer.php?' . http_build_query( array( 'url' => get_permalink() ) ) ); ?>"><i class="fa fa-facebook"></i> </a></li>
	<?php endif; ?>
	<?php
	if ( av5_get_option( 'blog-post-social-pinterest' ) && has_post_thumbnail() ) :
		list( $image ) = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' );
		?>
		<li><a target="_blank" class="av5-social-button" href="<?php
			echo esc_url( 'http://pinterest.com/pin/create/button/?' . http_build_query( array(
				'url'	 => get_permalink(),
				'media'	 => $image,
			) ) );
			?>"><i class="fa fa-pinterest"></i> </a></li>
			<?php endif; ?>
			<?php if ( av5_get_option( 'blog-post-social-google' ) ) : ?>
		<li><a target="_blank" class="av5-social-button" href="<?php echo esc_url( 'https://plus.google.com/share?' . http_build_query( array( 'url' => get_permalink() ) ) ); ?>"><i class="fa fa-google-plus"></i> </a></li>
		<?php endif; ?>
</ul>
