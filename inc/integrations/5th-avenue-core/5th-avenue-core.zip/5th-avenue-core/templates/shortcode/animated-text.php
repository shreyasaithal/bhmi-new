<?php
/**
 * 5th-Avenue animated text shortcode
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

$av5_custom_class	 = sprintf( 'av5_custom_%s_%s', time(), mt_rand( 0, time() ) );
$delay			 = 'data-delay="' . $delay . '" ';
$custom_styles	 = $inline_styles = '';
if ( $text_color ) {
	$custom_styles .= ' color:' . $text_color . '!important;';
}
if ( $align_center ) {
	$custom_styles .= ' text-align: center;';
}
if ( 'custom' === $font_h ) {
	if ( $font_size ) {
		$custom_styles .= ' font-size:' . $font_size . '!important;';
	}
	if ( $letter_spacing ) {
		$custom_styles .= ' letter-spacing:' . $letter_spacing . '!important;';
	}
	if ( $line_height ) {
		$custom_styles .= ' line-height:' . $line_height . '!important;';
	}
}
if ( ! empty( $custom_styles ) ) {
	$custom_styles = 'style="' . $custom_styles . '"';
}

if ( 'custom' === $font_h || ! $font_h ) {
	$font_h = 'h2';
}
if ( $bg_color ) {
	$inline_styles .= '.av5-animated-text--masked.'. $av5_custom_class .':after { background-color: '. $bg_color . '; }';
}
if ( ! empty( $inline_styles ) ) {
	$inline_styles	 = '<style>' . $inline_styles . '</style>';
}
echo  $inline_styles; // WPCS: xss ok.
if ( 'masked' === $animation_style ) {
	echo '<div class="wpb_animate_when_almost_visible av5-animated-text--masked ' . esc_attr( $av5_custom_class ) . ' ' . esc_attr( $extra_class ) . ' ' . esc_attr( $custom_class ) . '" ' . $custom_styles . ' ' . $delay . '><div class="wrap"><' . $font_h . ' class="inner">' . $content . '</' . $font_h . '></div></div>';
} else {
	echo '<' . $font_h . ' class="av5-animated-text--fadeIn ' . esc_attr( $extra_class ) . ' ' . esc_attr( $custom_class ) . '" ' . $custom_styles . ' ' . $delay . '>' . $content . '</' . $font_h . '>'; // WPCS: xss ok.
}