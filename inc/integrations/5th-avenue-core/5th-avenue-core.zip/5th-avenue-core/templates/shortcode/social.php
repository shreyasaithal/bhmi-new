<?php
/**
 * 5th-Avenue social icons shortcode
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

$av5_custom_class	 = sprintf( 'av5_custom_%s_%s', time(), mt_rand( 0, time() ) );
$custom_styles	 = '';
$icon_classes	 = '';

if ( $color ) {
	$custom_styles .= '.simple-social-icons.' . $av5_custom_class . ' li a { color: ' . $color . '!important; }';
}
if ( $color_hover ) {
	$custom_styles .= '.simple-social-icons.' . $av5_custom_class . ' li:hover a, .simple-social-icons.' . $av5_custom_class . ' li a:hover { color: ' . $color_hover . '!important; }';
}
if ( ! empty( $custom_styles ) ) {
	$custom_styles = '<style>' . $custom_styles . '</style>';
}
if ( 'inline' !== $align ) {
	$icon_classes .= 'align-center';
}
?>
<?php echo  $custom_styles; // WPCS: xss ok. ?>
<ul class="simple-social-icons <?php echo esc_attr( $custom_class ); ?> <?php echo esc_attr( $av5_custom_class ); ?> <?php echo esc_attr( $icon_classes ); ?>">
	<?php
	if ( $instagram ) {
		if ( ! empty( av5_get_option( 'social-url-instagram' ) ) ) {
			?> <li><a target="_blank" href="<?php echo esc_url( av5_get_option( 'social-url-instagram' ) ); ?>"><i class="fa fa-instagram"></i></a></li> <?php
		}
	}
	?>
	<?php
	if ( $facebook ) {
		if ( ! empty( av5_get_option( 'social-url-facebook' ) ) ) {
			?> <li><a target="_blank" href="<?php echo esc_url( av5_get_option( 'social-url-facebook' ) ); ?>"><i class="fa fa-facebook"></i> </a></li> <?php
		}
	}
			?>
			<?php
			if ( $twitter ) {
				if ( ! empty( av5_get_option( 'social-url-twitter' ) ) ) {
					?> <li><a target="_blank" href="<?php echo esc_url( av5_get_option( 'social-url-twitter' ) ); ?>"><i class="fa fa-twitter"></i> </a></li> <?php
				}
			}
		?>
		<?php
		if ( $google ) {
			if ( ! empty( av5_get_option( 'social-url-google' ) ) ) {
				?> <li><a target="_blank" href="<?php echo esc_url( av5_get_option( 'social-url-google' ) ); ?>"><i class="fa fa-google-plus"></i> </a></li> <?php
			}
		}
		?>
		<?php
		if ( $pinterest ) {
			if ( ! empty( av5_get_option( 'social-url-pinterest' ) ) ) {
				?> <li><a target="_blank" href="<?php echo esc_url( av5_get_option( 'social-url-pinterest' ) ); ?>"><i class="fa fa-pinterest"></i> </a></li> <?php
			}
		}
		?>
		<?php
		if ( $vimeo ) {
			if ( ! empty( av5_get_option( 'social-url-vimeo' ) ) ) {
				?> <li><a target="_blank" href="<?php echo esc_url( av5_get_option( 'social-url-vimeo' ) ); ?>"><i class="fa fa-vimeo"></i> </a></li> <?php
			}
		}
		?>
		<?php
		if ( $youtube ) {
			if ( ! empty( av5_get_option( 'social-url-youtube' ) ) ) {
				?> <li><a target="_blank" href="<?php echo esc_url( av5_get_option( 'social-url-youtube' ) ); ?>"><i class="fa fa-youtube-play"></i> </a></li> <?php
			}
		}
		?>
		<?php
		if ( $vk ) {
			if ( ! empty( av5_get_option( 'social-url-vk' ) ) ) {
				?> <li><a target="_blank" href="<?php echo esc_url( av5_get_option( 'social-url-vk' ) ); ?>"><i class="fa fa-vk"></i></a></li> <?php
			}
		}
			?>
</ul>
