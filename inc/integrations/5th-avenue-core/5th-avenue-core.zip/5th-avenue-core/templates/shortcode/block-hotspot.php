<?php
/**
 * 5th-Avenue parallax with hotsposts shortcode
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

?>
<div class="block-hotspot <?php echo esc_attr( $custom_class ); ?>"<?php echo  $attr; // WPCS: xss ok.     ?>><?php echo do_shortcode( $content ); // WPCS: xss ok.     ?></div>
