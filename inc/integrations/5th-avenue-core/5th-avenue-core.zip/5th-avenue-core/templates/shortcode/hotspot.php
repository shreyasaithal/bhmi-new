<?php
/**
 * 5th-Avenue parallax with hotsposts shortcode hotspot element
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

?>
<div id="<?php echo esc_attr( $tab_id ); ?>" class="hotspot-element<?php echo esc_attr( $class ); ?> "<?php echo  $attr; // WPCS: xss ok.      ?>>
	<?php echo do_shortcode( $content ); // WPCS: xss ok.   ?>
</div>
