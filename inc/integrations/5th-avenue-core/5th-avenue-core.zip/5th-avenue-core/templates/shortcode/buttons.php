<?php
/**
 * 5th-Avenue buttons shortcode
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

if ( ! isset( $link ) ) {
	$link = '';
}
$attributes		 = array();
$av5_custom_class	 = sprintf( 'av5_custom_%s_%s', time(), mt_rand( 0, time() ) );
$a_href			 = $custom_styles	 = '';
// Parse link.
$link			 = ( '||' === $link ) ? '' : $link;
if ( function_exists( 'vc_build_link' ) ) {
	$link = vc_build_link( $link );
	
	if ( strlen( $link['url'] ) > 0 ) {
		$use_link	 = true;
		$a_href		 = $link['url'];
		$a_href		 = apply_filters( 'vc_btn_a_href', $a_href );
		$a_title	 = $link['title'];
		$a_title	 = apply_filters( 'vc_btn_a_title', $a_title );
		$a_target	 = $link['target'];
		$a_rel		 = $link['rel'];
	}
}

$attributes[] = 'href="' . trim( $a_href ) . '"';
if ( ! empty( $a_title ) ) {
	$attributes[] = 'title="' . esc_attr( trim( $a_title ) ) . '"';
}
if ( ! empty( $a_target ) ) {
	$attributes[] = 'target="' . esc_attr( trim( $a_target ) ) . '"';
}
if ( ! empty( $a_rel ) ) {
	$attributes[] = 'rel="' . esc_attr( trim( $a_rel ) ) . '"';
}

/* button type and size */
$button_classes = array(
	'button',
	'av5-btn',
	'av5-btn-color--' . $colorset,
	'av5-btn-size--' . $size,
);
if ( 'underlined-long' == $style ) {
	$button_classes[] = 'av5-btn--underlined av5-btn--' . $style;
} else {
	$button_classes[] = 'av5-btn--' . $style;
}
if ( $shadow_hover ) {
	$button_classes[] = 'av5-btn--shadow-hover-simple';
	if ( $shadow_hover_color ) {
		$custom_styles .= '.' . $av5_custom_class . ' > a.button.av5-btn--shadow-hover-simple:hover { -webkit-box-shadow: 0 15px 45px 0px ' . $shadow_hover_color . '; -moz-box-shadow: 0 15px 45px 0px ' . $shadow_hover_color . '; box-shadow: 0 15px 45px 0px ' . $shadow_hover_color . '; } ';
	}
}
if ( 'inline' !== $align ) {
	$button_classes[] = 'vc_btn3-block';
}
if ( $button_classes ) {
	$button_classes	 = esc_attr( apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( $button_classes ) ) ) );
	$attributes[]	 = 'class="' . trim( $button_classes ) . '"';
}

$attributes = implode( ' ', $attributes );

$wrapper_classes = array(
	'vc_btn3-container',
	$this->getCSSAnimation( $css_animation ),
	$av5_custom_class,
	$custom_class,
);

if ( 'left' !== $align ) {
	$wrapper_classes[] = 'vc_btn3-' . $align;
}

if ( $anim_delay ) {
	$custom_styles .= '.vc_btn3-container.' . $av5_custom_class . '{ animation-delay: ' . $anim_delay . 'ms;}';
}

if ( 'custom' === $colorset ) {
	switch ( $style ) {
		case 'outline':
			if ( $custom_background ) {
				$custom_styles .= '.' . $av5_custom_class . ' > a.button { border-color:' . $custom_background . '!important; } ';
			}
			if ( $custom_background_hover ) {
				$custom_styles .= '.' . $av5_custom_class . ' > a.button:hover { background-color:' . $custom_background_hover . '!important; border-color:' . $custom_background_hover . '!important; } ';
			}
		case 'outline-top':
			if ( $custom_background ) {
				$custom_styles .= '.' . $av5_custom_class . ' > a.button { border-color:' . $custom_background . '!important; } ';
			}
			if ( $custom_background_hover ) {
				$custom_styles .= '.' . $av5_custom_class . ' > a.button:hover:after { background-color:' . $custom_background_hover . '!important; } ' . '.' . $av5_custom_class . ' > a.button:hover { border-color:' . $custom_background_hover . '!important; } '; // @codingStandardsIgnoreLine Generic.Strings.UnnecessaryStringConcat.Found
			}
		case 'single-underline':
		case 'underlined':
			if ( $custom_background ) {
				$custom_styles .= '.' . $av5_custom_class . ' > a.button:after { background-color:' . $custom_background . '!important; } ';
			}
			if ( $custom_background_hover ) {
				$custom_styles .= '.' . $av5_custom_class . ' > a.button:hover:after { background-color:' . $custom_background_hover . '!important; } ';
			}
			break;
		default:
			if ( $custom_background ) {
				$custom_styles .= '.' . $av5_custom_class . ' > a.button { background-color:' . $custom_background . '!important; } ';
			}
			if ( $custom_background_hover ) {
				$custom_styles .= '.' . $av5_custom_class . ' > a.button:hover { background-color:' . $custom_background_hover . '!important; } ';
			}
	}
	if ( $custom_text ) {
		$custom_styles .= '.' . $av5_custom_class . ' > a.button{color:' . $custom_text . '!important; } ';
	}
	if ( $custom_text_hover ) {
		$custom_styles .= '.' . $av5_custom_class . ' > a.button:hover {color:' . $custom_text_hover . '!important; } ';
	}
} // End if().
if ( ! empty( $custom_styles ) ) {
	$custom_styles	 = '<style>' . $custom_styles . '</style>';
}
$wrapper_classes = implode( ' ', $wrapper_classes );
?>
<?php echo  $custom_styles; // WPCS: xss ok.     ?> 
<div class="<?php echo esc_attr( trim( esc_attr( $wrapper_classes ) ) ); ?>">
	<a <?php echo  $attributes; // WPCS: xss ok.    ?>><?php echo  $title; // WPCS: xss ok.    ?></a>
</div>
