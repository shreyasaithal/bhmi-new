<?php
/**
 * 5th-Avenue text with icon shortcode
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

$attributes			 = array();
$av5_custom_class		 = sprintf( 'av5_custom_%s_%s', time(), mt_rand( 0, time() ) );
$custom_styles		 = $icon_item			 = '';
$wrapper_classes	 = array(
	'av5-text-with-icon',
	$this->getCSSAnimation( $css_animation ),
);
$wrapper_classes[]	 = $extra_class;

// Icon or image.
if ( 'image-icon' != $type ) {
	// Enqueue needed icon font.
	if ( function_exists( 'vc_icon_element_fonts_enqueue' ) ) {
		vc_icon_element_fonts_enqueue( $type );
	}
	$icon_class			 = isset( ${'icon_' . $type} ) ? esc_attr( ${'icon_' . $type} ) : 'fa fa-adjust';
	$icon_item			 = '<span class="vc_icon_element-icon ' . $icon_class . '"></span>';
	$wrapper_classes[]	 = 'av5-font-icon';
} else {
	$image_src = wp_get_attachment_image_src( $image, 'full' );
	if ( ! empty( $image_src[0] ) ) {
		$image_src = $image_src[0];
	}
	$wrapper_classes[] = 'av5-image-icon';
	if ( ! empty( $image_src ) ) {
		$icon_item = '<div class="av5-icon-image-wrap"><img alt="" src="' . $image_src . ' "></div>';
	}
}

// Inline styles.
if ( $anim_delay ) {
	$custom_styles .= '.av5-text-with-icon.' . $av5_custom_class . ' { animation-delay: ' . $anim_delay . 'ms!important; } ';
}
if ( $icon_color ) {
	$custom_styles .= '.av5-font-icon.' . $av5_custom_class . ' .vc_icon_element-icon { color:' . $icon_color . '!important; } ';
}
if ( $font_size ) {
	$custom_styles .= '.av5-font-icon.' . $av5_custom_class . ' .vc_icon_element-icon { font-size:' . $font_size . 'px!important; } ';
}
if ( ! empty( $custom_styles ) ) {
	$custom_styles = '<style>' . $custom_styles . '</style>';
}
$wrapper_classes[] = esc_attr( $custom_class );
$wrapper_classes[] = esc_attr( $av5_custom_class );
$wrapper_classes = implode( ' ', $wrapper_classes );
?>
<?php echo  $custom_styles; // WPCS: xss ok.      ?>
<div class="<?php echo esc_attr( $wrapper_classes ) ?>" >    
	<?php echo  $icon_item; // WPCS: xss ok.  ?>        
	<div class="text-content"><?php echo function_exists( 'wpb_js_remove_wpautop' ) ? wpb_js_remove_wpautop( $content, true ) : do_shortcode( $content ); // WPCS: xss ok.    ?></div>
</div>
