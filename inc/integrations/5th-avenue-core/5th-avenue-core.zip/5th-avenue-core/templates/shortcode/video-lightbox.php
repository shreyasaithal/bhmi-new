<?php
/**
 * 5th-Avenue video lightbox shortcode
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

$av5_custom_class	 = sprintf( 'av5_custom_%s_%s', time(), mt_rand( 0, time() ) );
$custom_styles	 = '';
$btn_classes	 = '';
$output			 = '';

$image_src = wp_get_attachment_image_src( $image, 'full' );
if ( ! empty( $image_src[0] ) ) {
	$image_src	 = $image_src[0];
	$image_src	 = '<img src="' . $image_src . '" alt="" />';
}

if ( $overlay_color ) {
	$custom_styles .= '.av5_video_button-image .av5_video_button.' . $av5_custom_class . ':before { background-color: ' . $overlay_color . '!important;}';
}
if ( $overlay__hover_color ) {
	$custom_styles .= '.av5_video_button-image .av5_video_button.' . $av5_custom_class . ':hover:before { background-color: ' . $overlay__hover_color . '!important;}';
}
if ( $img_anim_style ) {
	$img_anim_style = 'anim-style--' . $img_anim_style;
}

if ( $btn_style ) {
	$btn_classes .= ' av5_video_button--' . $btn_style;
}
if ( $icon_color ) {
	if ( 'filled' == $btn_style ) {
		$custom_styles .= '.av5_video_button.' . $av5_custom_class . ' .av5_video_icon:before { background-color: ' . $icon_color . '!important;}';
	} else {
		$custom_styles .= '.av5_video_button.' . $av5_custom_class . ' .av5_video_icon:before { box-shadow: 0 0 0 5px ' . $icon_color . '!important; } .av5_video_button.' . $av5_custom_class . ' .av5_video_icon .cls-1 { fill:' . $icon_color . '!important; } .av5_video_button.' . $av5_custom_class . ':hover .av5_video_icon:before  { box-shadow: 0 0 0 7px ' . $icon_color . ';}';
	}
	if ( 'circle_pulse' === $btn_style ) {
		$custom_styles .= '.av5_video_button.av5_video_button--circle_pulse.' . $av5_custom_class . ' .av5_video_icon:after { background:' . $icon_color . '!important; }';
	}
}
$btn_classes .= ' ' . esc_attr( $av5_custom_class );
if ( ! empty( $custom_styles ) ) {
	$custom_styles	 = '<style>' . $custom_styles . '</style>';
}
$icon			 = '<span class="av5_video_icon"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="25" viewBox="0 0 15 25"><path class="cls-1" style="fill:#fff;fill-rule:evenodd;" d="M-.021 24.528l14.41-12.081L-.021.5v24.028z"/></svg></span>';
echo  $custom_styles; // WPCS: xss ok.
$output			 = '<a href="' . $video_url . '" class="av5_video_button ' . $btn_classes . '">' . $icon . '' . $image_src . '</a>';
if ( ! empty( $image_src ) ) {
	echo '<div class="av5_video_button-image ' . esc_attr( $img_anim_style ) . '" >' . $output . '</div>'; // WPCS: xss ok.
} else {
	echo apply_filters( 'av5_shotcode_output_video-lightbox', $output ); // WPCS: xss ok.
}




