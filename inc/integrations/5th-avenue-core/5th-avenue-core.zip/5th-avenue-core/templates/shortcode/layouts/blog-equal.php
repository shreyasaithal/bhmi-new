<?php
/**
 * 5th-Avenue blog shortcode layout equal
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

global $av5_blog_shortcode_desc_status;
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'col-md-4 col-sm-6 col-xs-12' ); ?>>
	<div class="content-style-1">
		<?php if ( has_post_thumbnail() ) : ?>
			<div class="blog-listing__image-wrap blog-listing__image--uncropped">	
				<a href="<?php the_permalink(); ?>">
					<?php the_post_thumbnail( array( 650, 550 ) ); ?>
				</a>
			</div>
		<?php endif; ?>
		<?php get_template_part( 'template-parts/posts/elements/categories' ); ?>			
		<?php get_template_part( 'template-parts/posts/elements/title' ); ?>			
		<?php
		if ( av5_get_option( 'blog-listing-meta-show' ) ) {
			get_template_part( 'template-parts/posts/elements/meta' );
		}
		?>
		<?php if ( $av5_blog_shortcode_desc_status ) : ?>
			<div class="entry-content">
				<?php
				if ( 'excerpt' == av5_get_option( 'blog-listing-description' ) && has_excerpt() ) {
					the_excerpt();
				}
				if ( 'full' == av5_get_option( 'blog-listing-description' ) ) {
					the_content();
				}
				?>
				<?php
				wp_link_pages( array(
					'before' => '<div class="page-links">' . esc_html__( 'Pages:', '5th-avenue' ),
					'after'	 => '</div>',
				) );
				?>
			</div><!-- .entry-content -->
		<?php endif; ?>
		<?php if ( av5_get_option( 'blog-listing-readmore-text' ) ) : ?>
			<div class="blog-listing__read-more"><a href="<?php the_permalink(); ?>"><?php echo av5_get_option( 'blog-listing-readmore-text' ); // WPCS: xss ok. ?></a></div>
		<?php endif; ?>
	</div>

</article><!-- #-<?php the_ID(); ?> -->
