<?php
/**
 * 5th-Avenue empty space shortcode
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;
?>
<div style="display:block; height:<?php echo esc_attr( $height ); ?>"></div>
