<?php
/**
 * 5th-Avenue banner shortcode
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

$attributes				 = array();
$button_background_hover = $button_text_color_hover = $button					 = $button_colors			 = $overlay				 = $wrapper_classes		 = '';
$av5_custom_class			 = sprintf( 'av5_custom_%s_%s', time(), mt_rand( 0, time() ) );
$custom_styles			 = '';
$title_styles			 = '';
// Parse link.
$link					 = ( '||' === $link ) ? '' : $link;

$wrapper_classes .= 'av5-banner--' . $style;
$a_href = '#';
if ( function_exists( 'vc_build_link' ) ) {
	$link = vc_build_link( $link );
	
	if ( 0 < strlen( $link['url'] ) ) {
		$use_link	 = true;
		$a_href		 = $link['url'];
		$a_href		 = apply_filters( 'vc_btn_a_href', $a_href );
		$a_title	 = $link['title'];
		$a_title	 = apply_filters( 'vc_btn_a_title', $a_title );
		$a_target	 = $link['target'];
		$a_rel		 = $link['rel'];
	}
}

$attributes[] = 'href="' . trim( $a_href ) . '"';
if ( ! empty( $a_title ) ) {
	$attributes[] = 'title="' . esc_attr( trim( $a_title ) ) . '"';
}
if ( ! empty( $a_target ) ) {
	$attributes[] = 'target="' . esc_attr( trim( $a_target ) ) . '"';
}
if ( ! empty( $a_rel ) ) {
	$attributes[] = 'rel="' . esc_attr( trim( $a_rel ) ) . '"';
}
$attributes = implode( ' ', $attributes );

$image_src = wp_get_attachment_image_src( $image, 'full' );
if ( ! empty( $image_src[0] ) ) {
	$image_src = $image_src[0];
}

if ( $bg_overlay ) {
	$overlay = '<div class="av5-banner-overlay" style="background-color:' . $bg_overlay_color . '; opacity:' . $bg_overlay_opacity / 100 . ';">&nbsp;</div>';
} else {
	$wrapper_classes .= ' no-overlay';
	if ( 'overlay' === $hover_effect ) {
		$overlay = '<div class="av5-banner-overlay" style="background-color: #000000; opacity:0; ">&nbsp;</div>';
	}
}
$wrapper_classes .= ' ' . $custom_class;
$wrapper_classes .= ' ' . $av5_custom_class;
if ( ! $min_height ) {
	$min_height = '300px';
}
$banner_title = '';
if ( ! empty( $title ) ) {
	if ( $title_size ) {
		$title_styles .= 'font-size:' . $title_size . '!important; line-height: 1!important;';
	}
	if ( $title_color && 'custom' === $colorset ) {
		$title_styles .= 'color:' . $title_color . '!important; ';
	}
	if ( ! empty( $title_styles ) ) {
		$title_styles = ' style="' . $title_styles . '" ';
	}
	$banner_title = '<h3 ' . $title_styles . ' >' . $title . '</h3>';
}
$banner_subtitle = '';
if ( ! empty( $subtitle ) ) {
	$banner_subtitle = '<h6 class="fancy-title--small" >' . $subtitle . '</h6>';
}
if ( ! empty( $button_text ) ) {
	if ( 'custom' === $colorset ) {
		if ( $button_background ) {
			$custom_styles .= '.' . $av5_custom_class . ' a.button:after { background-color:' . $button_background . '!important; } ';
		}
		if ( $button_background_hover ) {
			$custom_styles .= '.' . $av5_custom_class . ' a.button:hover:after { background-color:' . $button_background_hover . '!important; } ';
		}
		if ( $button_text_color ) {
			$custom_styles .= '.' . $av5_custom_class . ' a.button {color:' . $button_text_color . '!important; } ';
		}
		if ( $button_text_color_hover ) {
			$custom_styles .= '.' . $av5_custom_class . ' a.button:hover {color:' . $button_text_color_hover . '!important; } ';
		}
	}
	$button = '<div class="av5-button-container">' . $button_colors . '<a ' . $attributes . ' class="button av5-btn--' . $button_style . '">' . $button_text . '</a></div>';
}
if ( $hover_border_color && 'custom' === $colorset ) {
	$custom_styles .= '.' . $av5_custom_class . '.av5-banner.av5-banner-border-hover .av5-banner-image-wrap {box-shadow: inset 0 0 0 0 ' . $hover_border_color . '!important; } ';
	$custom_styles .= '.' . $av5_custom_class . '.av5-banner.av5-banner-border-hover:hover .av5-banner-image-wrap {box-shadow: inset 0 0 0 20px ' . $hover_border_color . '!important; } ';
}
if ( ! empty( $custom_styles ) ) {
	$custom_styles = '<style>' . $custom_styles . '</style>';
}
$bg_image = '';
if ( ! empty( $image_src ) ) {
	if ( 'move' === $hover_effect ) {
		$bg_image = '<div class="av5-banner-image-wrap"><div class="av5-banner-image" style="background-image:url( ' . $image_src . ' )"></div></div>';
	} else {
		$bg_image = '<div class="av5-banner-image-wrap" style="background-image:url( ' . $image_src . ' )"></div>';
	}
}

if ( 'white' === $colorset ) {
	$wrapper_classes .= ' white-style';
}
if ( 'zoom' === $hover_effect ) {
	$wrapper_classes .= ' av5-banner-zoom-hover';
} elseif ( 'overlay' === $hover_effect ) {
	$wrapper_classes .= ' av5-banner-overlay-hover';
} elseif ( 'zoom_overlay' === $hover_effect ) {
	$wrapper_classes .= ' av5-banner-overlay-hover av5-banner-zoom-hover';
} elseif ( 'border' == $hover_effect ) {
	$wrapper_classes .= ' av5-banner-border-hover';
} elseif ( 'move' === $hover_effect ) {
	$wrapper_classes .= ' av5-banner-move-hover';
}
?>
<?php echo $custom_styles; // WPCS: xss ok.      ?>
<div class="av5-banner <?php echo esc_attr( $wrapper_classes ) ?>" <?php
if ( 'custom' === $colorset && isset( $background_color ) ) {
	echo 'style=" background-color: ' . $background_color . '"'; // WPCS: xss ok.
}
?> >

	<a href="<?php echo esc_url( $a_href ) ?>" class="av5-banner-link">&nbsp;</a>
	<div class="inner-wrap" style="min-height: <?php echo $min_height; // WPCS: xss ok.    ?>;" >
		<div class="inner-content"><?php echo $banner_subtitle; // WPCS: xss ok.     ?><?php echo $banner_title; // WPCS: xss ok.      ?><?php echo $content; // WPCS: xss ok.     ?></div>
		<?php echo $button; // WPCS: xss ok. ?>
	</div>
	<?php echo $overlay; // WPCS: xss ok.  ?>
	<?php echo $bg_image; // WPCS: xss ok.  ?>
</div>
