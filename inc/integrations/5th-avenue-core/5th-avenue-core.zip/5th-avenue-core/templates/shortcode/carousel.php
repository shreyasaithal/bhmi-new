<?php
/**
 * 5th-Avenue carousel shortcode
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

?>
<div class="av5-carousel-shortcode owl-carousel owl-theme<?php echo esc_attr( $animation ); ?> <?php echo esc_attr( $custom_class ); ?>" <?php echo  $options; // WPCS: xss ok.    ?>>
	<?php echo do_shortcode( $content ); // WPCS: xss ok.  ?>
</div>
