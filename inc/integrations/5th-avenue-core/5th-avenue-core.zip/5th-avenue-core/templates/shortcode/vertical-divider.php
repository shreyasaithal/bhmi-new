<?php
/**
 * 5th-Avenue vertical divider shortcode
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

$custom_styles = '';

if ( ! $style ) {
	$style = 'simple';
}
$av5_custom_class = sprintf( 'av5_custom_%s_%s', time(), mt_rand( 0, time() ) );

if ( $height ) {
	$custom_styles .= '.vetical-divider-simple.' . $av5_custom_class . ', .vetical-divider-simple.' . $av5_custom_class . ' >.line { height:' . $height . '!important;}';
}
if ( $custom_color ) {
	$custom_styles .= '.vetical-divider.' . $av5_custom_class . ' >.line {background-color:' . $custom_color . '!important;}';
}
if ( ! empty( $custom_styles ) ) {
	$custom_styles = '<style>' . $custom_styles . '</style>';
}

echo '<div class="wpb_content_element">' . $custom_styles . '<div class="vetical-divider vetical-divider-' . $style . ' ' . $av5_custom_class . '"><span class="line"></span></div></div>'; // WPCS: xss ok.
