<?php
/**
 * 5th-Avenue blog shortcode
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

if ( ! isset( $post_list ) || empty( $post_list ) ) {
	return;
}

global $av5_blog_shortcode_desc_status;
$blog_shortcode_desc_status = '';
if ( $show_desc ) {
	$blog_shortcode_desc_status = $show_desc;
}
if ( ! isset( $layout ) ) {
	$layout = 'default';
}
$blog_classes = 'av5-blog-shortcode';
$blog_classes .= $custom_class;
$blog_classes .= ' av5-blog-shortcode-' . $layout;
if ( isset( $readmore_style ) ) {
	$blog_classes .= ' read_more-style--' . $readmore_style;
}
if ( isset( $desc_align ) ) {
	$blog_classes .= ' align-' . $desc_align;
}
if ( isset( $hover_style ) ) {
	$blog_classes .= ' hover-style--' . $hover_style;
}
?>

<div class="blog-listing-wrap <?php echo esc_attr( $blog_classes ); ?> blog-listing--classic">
	<?php while ( $post_list->have_posts() ) : $post_list->the_post(); ?>
		<?php av5c_get_template_part( 'shortcode/layouts/blog', $layout ); ?>
	<?php endwhile; ?>
</div>
<?php
$total = $post_list->max_num_pages;
if ( $pagination && $total > 1 ) {
	?><div class="pagination clearfix"><?php
		$permalink_structure = get_option( 'permalink_structure' );
if ( empty( $permalink_structure ) ) {
	if ( is_front_page() ) {
		$format = '?paged=%#%';
	} else {
		$format = '&paged=%#%';
	}
} else {
	$format = 'page/%#%/';
}

echo paginate_links( array( // WPCS: xss ok.
	'base'		 => get_pagenum_link( 1 ) . '%_%',
	'format'	 => $format,
	'current'	 => $current_page,
	'total'		 => $total,
	'mid_size'	 => 10,
	'type'		 => 'list',
) );
?></div><?php
}
