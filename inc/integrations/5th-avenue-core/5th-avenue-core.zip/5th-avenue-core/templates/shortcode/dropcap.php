<?php
/**
 * 5th-Avenue dropcap shortcode
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

$custom_styles	 = '';
$custom_classes	 = $custom_class;
if ( $size ) {
	$custom_classes .= ' ' . $size;
}
if ( $font ) {
	$custom_classes .= ' ' . $font;
}
if ( $custom_color ) {
	$custom_styles .= 'color:' . $custom_color . '!important;';
}
if ( ! empty( $custom_styles ) ) {
	$custom_styles = 'style="' . $custom_styles . '"';
}
echo '<span class="dropcap-letter ' . $custom_classes . '" ' . $custom_styles . '>' . $content . '</span>'; // WPCS: xss ok.
