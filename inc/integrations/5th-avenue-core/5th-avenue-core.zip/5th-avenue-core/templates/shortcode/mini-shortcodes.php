<?php
/**
 * 5th-Avenue small shortcodes
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'av5_get_empty_space' ) ) {
	/**
	 * Create shortcode to output empty space with height value
	 *
	 * @param array $atts Attributes for shortcode.
	 * @return string
	 */
	function av5_get_empty_space( $atts ) {
		$a		 = shortcode_atts( array( 'height' => '30px' ), $atts );
		$content = '<div style="display:block; height:' . $a['height'] . '"></div>';
		return $content;
	}

	add_shortcode( 'empty-space', 'av5_get_empty_space' );
} // End if().

if ( ! function_exists( 'av5_get_footer_menu' ) ) {
	/**
	 * Create shortcode to output footer menu
	 *
	 * @return string
	 */
	function av5_get_footer_menu() {
		return wp_nav_menu( array( 'menu' => 'footer-copyright-menu', 'theme_location' => 'footer-copyright-menu', 'echo' => false ) );
	}

	add_shortcode( 'footer-menu', 'av5_get_footer_menu' );
} // End if().

if ( ! function_exists( 'av5_get_the_year' ) ) {
	/**
	 * Create shortcode to output year
	 *
	 * @return string
	 */
	function av5_get_the_year() {
		return date( 'Y' );
	}

	add_shortcode( 'the-year', 'av5_get_the_year' );
} // End if().

if ( ! function_exists( 'av5_get_site_name' ) ) {
	/**
	 * Create shortcode to output site name
	 *
	 * @return string
	 */
	function av5_get_site_name() {
		return get_bloginfo( 'name' );
	}

	add_shortcode( 'site-name', 'av5_get_site_name' );
} // End if().
