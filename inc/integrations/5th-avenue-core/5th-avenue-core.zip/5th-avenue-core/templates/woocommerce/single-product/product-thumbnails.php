<?php
/**
 * Single Product Thumbnails
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/product-thumbnails.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     3.3.2
 */

defined( 'ABSPATH' ) || exit;

global $post, $product;

if ( ! isset( $position ) ) {
	$position = 'horizontal';
}
$columns		 = apply_filters( 'woocommerce_product_thumbnails_columns', 4 );
$attachment_ids	 = $product->get_gallery_image_ids();
$video			 = av5_get_meta( 'gallery_video', null );
if ( av5_get_option( 'product-pages-thumbnails-first-images', true ) && has_post_thumbnail() ) {
	$thumb_id = absint( get_post_thumbnail_id( $post->ID ) );
	if ( ! in_array( $thumb_id, $attachment_ids ) ) {
		array_unshift( $attachment_ids, $thumb_id );
	}
}

if ( ! empty( $attachment_ids ) || ! empty( $video ) ) {
	echo '<div class="owl-product-thumbnail__wrapper owl-carousel owl-product-thumbnail-' . $position . '" data-columns="' . $columns . '">'; // WPCS: xss ok.
	foreach ( $attachment_ids as $attachment_id ) {
		$html = wp_get_lazy_attachment_image( $attachment_id, 'woocommerce_gallery_thumbnail_not_crop', false, array(
			'class' => 'owl-lazy',
		), false );
		echo apply_filters( 'woocommerce_single_product_image_thumbnail_html', $html, $attachment_id ); // WPCS: xss ok.
	}
	if ( ! empty( $video ) ) {
		$html = sprintf( '<img src="%s" alt="%s" class="wp-post-image" />', esc_url( av5_placeholder_video_src() ), esc_html__( 'Awaiting product video', '5th-avenue' ) );
		echo apply_filters( 'woocommerce_single_product_video_thumbnail_html', $html, $video, $product ); // WPCS: xss ok.
	}
	echo '</div>';
}
