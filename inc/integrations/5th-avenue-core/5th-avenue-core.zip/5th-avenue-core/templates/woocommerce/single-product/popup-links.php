<?php
/**
 * The template for displaying popup links content product
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 3.3.3
 */

defined( 'ABSPATH' ) || exit;

if ( ! isset( $slug ) || empty( $slug ) ) {
	return;
}
?>
<a href="#<?php echo esc_attr( $slug ); ?>" class="av5-overlay-button av5-popup-link"><?php echo esc_html( $label ); ?></a>
<div id="<?php echo esc_attr( $slug ); ?>" style="display: none;"><?php echo do_shortcode( shortcode_unautop( $content ) ); // WPCS: xss ok. ?></div>
