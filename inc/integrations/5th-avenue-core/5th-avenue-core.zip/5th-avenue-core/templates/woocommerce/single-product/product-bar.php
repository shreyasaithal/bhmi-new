<?php
/**
 * The template to display product price, title, variations, add to cart and wishist button in the sticky bar at the bottom of the page
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

global $av5_id_prefix;
$av5_id_prefix = 'product_bar_';
if ( av5_get_option( 'product-page-botom-bar' ) ) {
	add_action( 'av5-product-bar', 'woocommerce_template_single_title', 10 );
	add_action( 'av5-product-bar', 'woocommerce_template_single_price', 20 );
	add_action( 'av5-product-bar', 'woocommerce_template_single_add_to_cart', 30 );
	?>
	<div class="product-bar <?php
	if ( ! av5_get_option( 'product-page-botom-bar-wishlist' ) ) {
		echo 'hide-wishlist-button';
	}
	?>">
		<div class="flex-row">
			<?php do_action( 'av5-product-bar' ); ?>
		</div>
	</div>
<?php
}
