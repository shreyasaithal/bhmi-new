<?php
/**
 * 5th-Avenue product categories list for title area
 *
 * @package 5th-Avenue
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

global $wp_rewrite;

$category_id = 0;
if ( $cat_name	 = get_query_var( 'product_cat' ) ) {
	$category = get_term_by( 'name', $cat_name, 'product_cat' ); // @codingStandardsIgnoreLine WordPress.VIP.RestrictedFunctions.get_term_by
	if ( $category ) {
		$category_id = $category->term_id;
	}
}
$categories = get_categories( array( 'type' => 'product', 'taxonomy' => 'product_cat', 'child_of' => $category_id ) );

if ( empty( $category_id ) ) {
	foreach ( $categories as $k => $category ) {
		if ( $category->parent ) {
			unset( $categories[ $k ] );
		}
	}
}
$rel = ( is_object( $wp_rewrite ) && $wp_rewrite->using_permalinks() ) ? 'category tag' : 'category';
?>
<ul class="categories-list">
	<?php if ( av5_get_option( 'products-titlearea-categories-all', false ) ) { ?>
	<li><a href="<?php echo esc_url( get_permalink( woocommerce_get_page_id( 'shop' ) ) ); ?>"><?php esc_html_e( 'All', '5th-avenue' ); ?></a></li>
	<?php } ?>
	<?php foreach ( $categories as $category ) : ?>
	<li><a href="<?php echo esc_url( get_category_link( $category->term_id ) ); // @codingStandardsIgnoreLine WordPress.VIP.RestrictedFunctions.get_term_link ?>" rel="<?php echo esc_attr( $rel ); ?>"><?php echo esc_html( $category->name ); ?></a></li>
	<?php endforeach; ?>
</ul>
