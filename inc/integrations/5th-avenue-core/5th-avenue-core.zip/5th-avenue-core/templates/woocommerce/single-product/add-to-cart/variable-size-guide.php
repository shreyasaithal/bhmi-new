<?php
/**
 * Variable size guide product
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

?>
<a class="av5-size-guide-icon" data-av5-overlay=".size-guide-<?php echo esc_attr( $product->get_id() ); ?>"><?php esc_html_e( 'Size Guide', '5th-avenue' ) ?></a>
<div class="av5-size-guide-content size-guide-<?php echo esc_attr( $product->get_id() ); ?>" style="display: none;">
	<?php echo do_shortcode( shortcode_unautop( $size_guide_content ) ); // WPCS: xss ok.  ?>
</div>
