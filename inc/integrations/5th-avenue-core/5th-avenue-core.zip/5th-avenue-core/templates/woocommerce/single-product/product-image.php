<?php
/**
 * Single Product Image
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/product-image.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 3.3.2
 */

defined( 'ABSPATH' ) || exit;

global $post, $product;
$columns		 = apply_filters( 'woocommerce_product_thumbnails_columns', 4 );
$thumbnail_size	 = apply_filters( 'woocommerce_product_thumbnails_large_size', 'full' );
$placeholder	 = has_post_thumbnail() ? 'with-images' : 'without-images';
$wrapper_classes = apply_filters( 'woocommerce_single_product_image_gallery_classes', array(
	'av5-product-gallery',
	'av5-product-gallery-normal',
	'woocommerce-product-gallery--' . $placeholder,
	'woocommerce-product-gallery--columns-' . absint( $columns ),
	'images',
) );
?>
<div class="<?php echo esc_attr( implode( ' ', array_map( 'sanitize_html_class', $wrapper_classes ) ) ); ?>" style="opacity: 0; transition: opacity .25s ease-in-out;">
	<?php do_action( 'av5_woocommerce_product_before_product_image' ); ?>
	<figure class="owl-product-gallery__wrapper owl-carousel owl-theme" data-excludeimagevariation="<?php echo esc_attr( ( ! av5_get_option( 'product-pages-thumbnails-first-images', true ) && has_post_thumbnail() ) ? absint( get_post_thumbnail_id( $post->ID ) ) : 0 ); ?>">
		<?php
		$attachment_ids	 = $product->get_gallery_image_ids();
		$video			 = av5_get_meta( 'gallery_video', null );
		if ( av5_get_option( 'product-pages-thumbnails-first-images', true ) && has_post_thumbnail() ) {
			$thumb_id = absint( get_post_thumbnail_id( $post->ID ) );
			if ( ! in_array( $thumb_id, $attachment_ids ) ) {
				array_unshift( $attachment_ids, $thumb_id );
			}
		}
		if ( empty( $attachment_ids ) && empty( $video ) ) {
			$html = '<div class="woocommerce-product-gallery__image--placeholder">';
			$html .= sprintf( '<img src="%s" alt="%s" class="wp-post-image" />', esc_url( wc_placeholder_img_src() ), esc_html__( 'Awaiting product image', 'woocommerce' ) );
			$html .= '</div>';
			echo apply_filters( 'woocommerce_single_product_image_thumbnail_html', $html, get_post_thumbnail_id( $post->ID ) ); // WPCS: xss ok.
		} else {
			foreach ( $attachment_ids as $attachment_id ) {
				$html = wp_get_lazy_attachment_image( $attachment_id, 'woocommerce_single', false, array(
					'class' => 'owl-lazy av5-product-gallery__image',
				) );
				echo apply_filters( 'woocommerce_single_product_image_thumbnail_html', $html, $attachment_id ); // WPCS: xss ok.
			}
		}
		if ( ! empty( $video ) ) {
			$html = '<a class="owl-video av5-product-gallery__video" href="' . esc_url( $video ) . '"></a>';
			echo apply_filters( 'woocommerce_single_product_video_html', $html, $video, $product ); // WPCS: xss ok.
		}
		?>
	</figure>
	<?php do_action( 'woocommerce_product_vertical_thumbnails' ); ?>
	<?php do_action( 'woocommerce_product_thumbnails' ); ?>
</div>
