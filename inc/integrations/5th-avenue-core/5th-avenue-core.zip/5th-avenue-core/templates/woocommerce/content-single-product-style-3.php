<?php
/**
 * The template for displaying product content in the single-product.php template
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 3.4.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Hook: woocommerce_before_single_product hook.
 *
 * @hooked wc_print_notices - 10
 */
do_action( 'woocommerce_before_single_product' );

if ( post_password_required() ) {
	echo get_the_password_form(); // WPCS: xss ok.
	return;
}
?>

<?php
$prod_classes = 'product_layout_v3';
if ( ! av5_get_option( 'product-pages-quantity' ) ) {
	$prod_classes .= ' qty-field-hide';
}
if ( av5_get_option( 'product-pages-description-alignment' ) ) {
	$prod_classes .= ' description-align-' . av5_get_option( 'product-pages-description-alignment' );
}
if ( av5_get_option( 'product-pages-buttons-layout' ) ) {
	$prod_classes .= ' product-page--buttons-layout-' . av5_get_option( 'product-pages-buttons-layout' );
}
if ( av5_get_option( 'product-pages-product-thumbnails-position' ) ) {
	$prod_classes .= ' thumbnails-carousel-' . av5_get_option( 'product-pages-product-thumbnails-position' );
}
if ( av5_get_option( 'product-pages-description-vertical-alignment' ) ) {
	$prod_classes .= ' vertical-description-align-' . av5_get_option( 'product-pages-description-vertical-alignment' );
}
global $product;
if ( $product->get_gallery_image_ids() || av5_get_meta( 'gallery_video', null ) ) {
	$prod_classes .= ' product-page--has-thumbs';
}
?>
<div id="product-<?php the_ID(); ?>" <?php wc_product_class( $prod_classes ); ?>>
	<div class="product-info-background clearfix">
		<div class="empty-space"></div>
		<?php
		/**
		 * Above the product page content
		 *
		 * @hooked woocommerce_breadcrumb
		 */
		add_action( 'av5-woocommerce_before_single_product', 'woocommerce_template_single_rating', 10 );
		add_action( 'av5-woocommerce_before_single_product', 'woocommerce_template_single_title', 20 );
		add_action( 'av5-woocommerce_before_single_product', 'woocommerce_template_single_price', 30 );
		do_action( 'av5-woocommerce_before_single_product' );
		?>
		<div class="product-content-wrapper container">

			<?php
			/**
			 * Hook: woocommerce_before_single_product_summary hook.
			 *
			 * @hooked woocommerce_show_product_sale_flash - 10
			 * @hooked woocommerce_show_product_images - 20
			 */
			do_action( 'woocommerce_before_single_product_summary' );
			?>

			<div class="summary-right entry-summary">

				<div class="single_product_before_title">                    
					<?php
					do_action( 'av5_woocommerce_single_product_before_title' );
					?>
				</div>

				<?php
				/**
				 * Hook: woocommerce_single_product_summary hook.
				 *
				 * @hooked av5_woocommerce_product_navigation - 1
				 * @hooked woocommerce_show_product_sale_flash - 2
				 * @hooked woocommerce_template_single_title - 5
				 * @hooked woocommerce_template_single_rating - 10
				 * @hooked woocommerce_template_single_price - 10
				 * @hooked woocommerce_template_single_excerpt - 20
				 * @hooked woocommerce_template_single_add_to_cart - 30
				 * @hooked woocommerce_template_single_meta - 40
				 * @hooked woocommerce_template_single_sharing - 50
				 * @hooked WC_Structured_Data::generate_product_data() - 60
				 */
				remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );
				remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
				remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10 );
				if ( ! av5_get_option( 'product-pages-meta-information' ) ) {
					remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
				}
				do_action( 'woocommerce_single_product_summary' );
				?>

			</div><!-- .summary -->
		</div>
	</div>

	<?php
	/**
	 * Hook: woocommerce_after_single_product_summary hook.
	 *
	 * @hooked woocommerce_output_product_data_tabs - 10
	 * @hooked woocommerce_upsell_display - 15
	 * @hooked woocommerce_output_related_products - 20
	 */
	do_action( 'woocommerce_after_single_product_summary' );
	?>

</div><!-- #product-<?php the_ID(); ?> -->

<?php
/**
 * Hook: woocommerce_after_single_product
 *
 * @hooked av5_woocommerce_product_bar - 1
 */
do_action( 'woocommerce_after_single_product' );
?>
