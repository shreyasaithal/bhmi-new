<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 3.4.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

// Wishlist & Quickview.
$quickviewenabled	 = '';
$wishlistenabled	 = '';
if ( class_exists( 'YITH_WCWL' ) || ((defined( 'TINVWL_LOAD_FREE' ) || defined( 'TINVWL_LOAD_PREMIUM' )) && av5_get_option( 'shop-page-override_ti_wishlist' )) ) {
	$wishlistenabled = 'wishlist-enabled';
}
if ( av5_get_option( 'shop-page-quickview' ) ) {
	$quickviewenabled = 'quickview-enabled';
}

// Ensure visibility.
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}
$_classes = 'product-style--' . av5_get_option( 'shop-page-products-thumbnail-styles' );
if ( ! av5_get_option( 'shop-page-products-thumbnail-carousel-arrows' ) ) {
	$_classes .= ' hide-product-carousel-arrows';
}
if ( ! av5_get_option( 'shop-page-products-thumbnail-carousel-dots' ) ) {
	$_classes .= ' hide-product-carousel-dots';
}
if ( av5_get_option( 'shop-page-product-boxed' ) ) {
	$_classes .= ' products-boxed-style';
}
?>
<li <?php wc_product_class( $_classes ); ?>>
	<div class="grid-products-wrapper">
		<?php
		if ( ! function_exists( 'av5_product_additional_buttons' ) ) {

			/**
			 * Product Additional Buttons
			 */
			function av5_product_additional_buttons() {
				echo '<div class="product-additional"><a href="#">Wishlist</a><a href="#">Quickview</a></div>'; // WPCS: xss ok.
			}
		}

		// Wishlist default output.
		if ( ( 'default-simple' === av5_get_option( 'shop-page-products-thumbnail-styles' ) || 'default-moveup' === av5_get_option( 'shop-page-products-thumbnail-styles' ) ) && 'wishlist-enabled' === $wishlistenabled ) {
			do_action( 'tinvwl_after_shop_loop_item' );
			do_action( 'tinvwl_above_thumb_loop_item' );
		}

		remove_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open' );
		remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5 );
		/**
		 * Hook: woocommerce_before_shop_loop_item.
		 *
		 * @hooked woocommerce_template_loop_product_link_open - 10
		 */
		do_action( 'woocommerce_before_shop_loop_item' );
		?>
		<div class="product_thumbnail_image_wrap">
			<?php if ( av5_get_option( 'shop-page-products-thumbnail-styles' ) === 'bottom-line-simple' || av5_get_option( 'shop-page-products-thumbnail-styles' ) === 'bottom-line-moveup' || av5_get_option( 'shop-page-products-thumbnail-styles' ) === 'shadow-box' ) { ?>
				<?php if ( 'wishlist-enabled' === $wishlistenabled || 'quickview-enabled' === $quickviewenabled ) { ?>
					<div class="product-additional <?php echo esc_attr( $wishlistenabled ); ?> <?php echo esc_attr( $quickviewenabled ); ?>">
						<?php if ( $wishlistenabled ) { ?>
							<div class="product-link-wishlist">
								<?php
								do_action( 'tinvwl_after_shop_loop_item' );
								do_action( 'tinvwl_above_thumb_loop_item' );
								if ( class_exists( 'YITH_WCWL' ) ) {
									echo do_shortcode( '[yith_wcwl_add_to_wishlist]' );
								}
								?>
							</div>
						<?php } ?>
						<div class='h-divider'></div>
						<?php if ( $quickviewenabled ) { ?>                    
							<div class="product-link-quickview"><a href="#" class="av5-quickview-button" data-product_id="<?php echo esc_attr( $product->get_id() ); ?>"><?php if ( av5_get_option( 'shop-page-quickview-icon' ) ) { ?><i class="fa fa-eye" aria-hidden="true"></i><?php } // End if(). ?><?php echo av5_get_option( 'shop-page-quickview-text' ) // WPCS: xss ok. ?></a></div>
						<?php } ?>
					</div> 
				<?php } ?>
			<?php } ?>
			<?php
			/**
			 * Hook: woocommerce_before_shop_loop_item_title.
			 *
			 * @hooked woocommerce_show_product_loop_sale_flash - 10
			 * @hooked woocommerce_template_loop_product_thumbnail - 10
			 */
			do_action( 'woocommerce_before_shop_loop_item_title' );
			?>

		</div> 
		<div class='product-details align-<?php echo esc_attr( av5_get_option( 'shop-page-details-alignment' ) ); ?>'>
			<?php
			// Product categories.
			if ( av5_get_option( 'shop-page-elements-category' ) ) {
				echo wc_get_product_category_list( $product->get_id(), '', '<div class="posted_in">', '</div>' ); // WPCS: xss ok.
			}
			// Replaced title.
			?>            
			<h2 class="woocommerce-loop-product__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
			<?php
			/**
			 * Hook woocommerce_shop_loop_item_title hook.
			 *
			 * @hooked woocommerce_template_loop_product_title - 10
			 */
			remove_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title' );
			do_action( 'woocommerce_shop_loop_item_title' );

			// Get the product description.
			$product_description = av5_get_meta( 'product-additional-grid-description', null, $post->ID );
			if ( $product_description ) {
				echo '<div class="product-desc">' . $product_description . '</div>'; // WPCS: xss ok.
			}

			/**
			 * Hook woocommerce_after_shop_loop_item_title hook.
			 *
			 * @hooked woocommerce_template_loop_rating - 5
			 * @hooked woocommerce_template_loop_price - 10
			 */
			remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );
			remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );
			add_action( 'av5_woocommerce_after_shop_loop_item_price', 'woocommerce_template_loop_price', 10 );
			if ( 'yes' === get_option( 'woocommerce_enable_reviews', 'yes' ) ) {
				add_action( 'av5_woocommerce_after_shop_loop_item_rating', 'woocommerce_template_loop_rating', 5 );
			}
			?>
			<div class="product-rating">
				<?php do_action( 'av5_woocommerce_after_shop_loop_item_rating' ); ?>
			</div>
			<?php
			/**
			 * Hook: woocommerce_after_shop_loop_item_title.
			 *
			 * @hooked woocommerce_template_loop_rating - 5
			 * @hooked woocommerce_template_loop_price - 10
			 */
			do_action( 'woocommerce_after_shop_loop_item_title' );
			?>
			<div class="product-after-shop-loop <?php
			if ( av5_get_option( 'shop-page-elements-addtocart' ) && av5_get_option( 'shop-page-elements-addtocart-hover' ) ) {
				echo 'addtocart-on-hover';
			}
			?>">

				<div class="product-after-shop-wrap ">
					<div class='product-price'>
						<?php do_action( 'av5_woocommerce_after_shop_loop_item_price' ); ?>
					</div>
					<?php if ( av5_get_option( 'shop-page-elements-addtocart' ) ) { ?>
						<div class="product-buttons">
							<?php
							/**
							 * Hook: woocommerce_after_shop_loop_item.
							 *
							 * @hooked woocommerce_template_loop_product_link_close - 5
							 * @hooked woocommerce_template_loop_add_to_cart - 10
							 */
							do_action( 'woocommerce_after_shop_loop_item' );
							?>
						</div>
					<?php } ?>
				</div>
				<?php do_action( 'av5_woocommerce_after_shop_loop_item' ); ?>

			</div>
		</div>
	</div>
</li>
