<?php
/**
 * The Template for displaying dialog for add to wishlist product.
 *
 * @version             1.7.2
 * @package           TInvWishlist\Template
 */

defined( 'ABSPATH' ) || exit;

?>
<div class="tinvwl_add_to_select_wishlist tinv-modal">
	<div class="tinv-overlay"></div>
	<div class="tinv-table">
		<div class="tinv-cell">
			<div class="tinv-modal-inner">
				<i class="ti-icon icon_big_heart_plus"></i>
				<label>
					<?php esc_html_e( 'Choose Wishlist:', 'ti-woocommerce-wishlist-premium' ); ?>
					<select class="tinvwl_wishlist"></select>
				</label>
				<input class="tinvwl_new_input" style="display: none" type="text" value=""/>
				<button class="button tinvwl_button_add" type="button"><i class="fati fati-heart-o"></i><?php esc_html_e( 'Add to Wishlist', '5th-avenue' ); ?></button>
				<button class="button tinvwl_button_close" type="button"><i class="fati fati-times"></i><?php esc_html_e( 'Close', 'ti-woocommerce-wishlist-premium' ); ?></button>
				<div class="tinv-wishlist-clear"></div>
			</div>
		</div>
	</div>
</div>
