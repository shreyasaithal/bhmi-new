<?php
/**
 * The template for displaying product content in the single-product.php template
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see			templates/content-single-product.php
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     3.0.0
 */

defined( 'ABSPATH' ) || exit;


if ( post_password_required() ) {
	return;
}

$prod_classes = 'quickview-popup-container';
if ( ! av5_get_option( 'product-pages-quantity' ) ) {
	$prod_classes .= ' qty-field-hide';
}
if ( av5_get_option( 'product-pages-description-alignment' ) ) {
	$prod_classes .= ' description-align-' . av5_get_option( 'product-pages-description-alignment' );
}
?>
<div id="product-<?php the_ID(); ?>" <?php
post_class( $prod_classes );
if ( class_exists( 'YITH_WCCL_Frontend' ) ) {
	$yith_wcc = YITH_WCCL_Frontend::get_instance();
	echo sprintf( ' data-yith_attr="%s"', htmlspecialchars( json_encode( $yith_wcc->create_attributes_json( false, true ) ) ) ); // WPCS: xss ok.
}
?>>
			<?php
			/**
			 * Hook: woocommerce_before_single_product_summary.
			 *
			 * @hooked woocommerce_show_product_sale_flash - 10
			 * @hooked woocommerce_show_product_images - 20
			 */
			do_action( 'woocommerce_before_single_product_summary' );
			?>
	<div class="quickview-summary-wrapper">
		<div class="av5-white-gradient">&nbsp;</div>
		<div class="summary-right entry-summary">
			<?php
			/**
			 * Hook: Woocommerce_single_product_summary.
			 *
			 * @hooked woocommerce_template_single_title - 5
			 * @hooked woocommerce_template_single_rating - 10
			 * @hooked woocommerce_template_single_price - 10
			 * @hooked woocommerce_template_single_excerpt - 20
			 * @hooked woocommerce_template_single_add_to_cart - 30
			 * @hooked woocommerce_template_single_meta - 40
			 * @hooked woocommerce_template_single_sharing - 50
			 * @hooked WC_Structured_Data::generate_product_data() - 60
			 */
			remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );
			remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10 );
			add_action( 'av5_quickview_rating', 'woocommerce_template_single_rating', 5 );
			add_action( 'av5_quickview_title', 'woocommerce_template_single_title', 10 );
			remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
			remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_sharing', 50 );
			?>
			<?php do_action( 'av5_quickview_rating' ); ?>
			<a href="<?php the_permalink(); ?>"><?php do_action( 'av5_quickview_title' ); ?></a>
			<?php
			do_action( 'woocommerce_single_product_summary' );
			?>
		</div>
	</div>


</div>
