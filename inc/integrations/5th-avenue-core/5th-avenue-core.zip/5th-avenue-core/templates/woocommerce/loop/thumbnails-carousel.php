<?php
/**
 * WooCommerce product thumbnails carousel
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author LifeisDesign
 * @copyright Copyright (c) 2018, LifeisDesign
 * @link http://lifeis.design/
 */

defined( 'ABSPATH' ) || exit;

global $product;
?>
<div class="av5-carousel-thumbnails-wrapper owl-carousel owl-theme">
	<a href="<?php the_permalink(); ?>" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><?php echo implode( '</a><a href="' . esc_url( get_permalink() ) . '" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">', $gallery_image ); // WPCS: xss ok.     ?></a>
</div>
