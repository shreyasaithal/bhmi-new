<?php
/**
 * 5th-Avenue: WooCommerce products filter
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author LifeisDesign
 * @copyright Copyright (c) 2018, LifeisDesign
 * @link http://lifeis.design/
 */

defined( 'ABSPATH' ) || exit;

if ( ! isset( $only_slideout ) ) {
	$only_slideout = false;
}
$classes = array();
if ( 2 == $positon_filters ) {
	$classes[] = 'av5-products-filter-centered';
}
if ( $only_slideout ) {
	$classes[] = 'single-drop';
}
?>

<div class="av5-products-filter-wrap <?php echo esc_attr( implode( ' ', $classes ) ); ?> ">
	<?php
	do_action( 'av5_products_before_filter', $args );
	if ( ! $only_slideout ) {
		av5c_get_template( 'woocommerce/loop/products-filter-content.php', $args );
	}
	do_action( 'av5_products_after_filter', $args );
	?>
</div>
