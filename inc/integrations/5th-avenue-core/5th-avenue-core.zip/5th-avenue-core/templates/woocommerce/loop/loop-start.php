<?php
/**
 * Product Loop Start
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/loop/loop-start.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     3.3.0
 */

defined( 'ABSPATH' ) || exit;

$_classes = '';

if ( av5_get_option( 'shop-page-products-grid-mobile' ) ) {
	$products_per_column_mobile = av5_get_option( 'shop-page-products-grid-mobile' );
} else {
	$products_per_column_mobile = 2;
}

$_classes .= ' mobile-columns-' . $products_per_column_mobile;
if ( av5_get_option( 'shop-page-products-thumbnail-styles' ) === 'shadow-box-hover' ) {
	$_classes .= ' grid-style--shadow-hover';
}
if ( av5_get_option( 'shop-listing-loadin-animation' ) !== 'none' ) {
	$_classes .= ' reveal--on reveal-animation--' . av5_get_option( 'shop-listing-loadin-animation' );
}
if ( av5_get_option( 'shop-page-products-grid-centered' ) ) {
	$_classes .= ' centered-grid';
}
?>
<ul class="products product-columns-<?php echo esc_attr( wc_get_loop_prop( 'columns' ) ); ?> products-grid <?php echo esc_attr( $_classes ) ?>">
