<?php
/**
 * 5th-Avenue: WooCommerce products filter content
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author LifeisDesign
 * @copyright Copyright (c) 2018, LifeisDesign
 * @link http://lifeis.design/
 */

defined( 'ABSPATH' ) || exit;

if ( ! isset( $prefix ) ) {
	$prefix = '';
}
?>

<form method="POST" class="av5-products-filters">
	<?php
	do_action( 'av5_products_before_filter_content' );
	if ( isset( $product_cat ) && ! empty( $product_cat ) ) {
		av5c_get_template( 'woocommerce/loop/products-filter-element.php', array(
			'prefix'		 => $prefix,
			'key'			 => 'product_cat',
			'name'			 => esc_html__( 'Category', 'woocommerce' ),
			'options'		 => $product_cat,
			'element_all'	 => $element_all,
		) );
	}
	if ( isset( $product_attributes ) && ! empty( $product_attributes ) ) {
		foreach ( $product_attributes as $key => $attribute ) {
			av5c_get_template( 'woocommerce/loop/products-filter-element.php', array(
				'prefix'		 => $prefix,
				'key'			 => $key,
				'name'			 => $attribute->get_taxonomy_object()->attribute_label,
				'options'		 => apply_filters( 'av5_products_filter_prepare_attribute', $attribute, $key ),
				'element_all'	 => $element_all,
			) );
		}
	}
	if ( isset( $product_tag ) && ! empty( $product_tag ) ) {
		av5c_get_template( 'woocommerce/loop/products-filter-element.php', array(
			'prefix'		 => $prefix,
			'key'			 => 'product_tag',
			'name'			 => esc_html__( 'Tag', 'woocommerce' ),
			'options'		 => $product_tag,
			'element_all'	 => $element_all,
		) );
	}
	if ( isset( $product_price ) && ! empty( $product_price ) ) {
		av5c_get_template( 'woocommerce/loop/products-filter-price.php', array(
			'prefix'	 => $prefix,
			'name'		 => esc_html__( 'Price', 'woocommerce' ),
			'options'	 => $product_price,
		) );
	}
	?>
	<button type="submit" class="av5-filters-summary-button"><?php esc_html_e( 'Apply', 'woocommerce' ) ?></button>
	<?php
	if ( isset( $need_clean ) && ! empty( $need_clean ) ) {
		?><div class="av5-products-filter av5-products-filter-clear">
			<a class="button" href="<?php echo esc_url( remove_query_arg( $need_clean ) ); ?>"><?php esc_html_e( 'Clear', 'woocommerce' ) ?></a>
		</div><?php
	}
	do_action( 'av5_products_after_filter_content' );
	?>
</form>
