<?php
/**
 * 5th-Avenue: WooCommerce products filter element
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author LifeisDesign
 * @copyright Copyright (c) 2018, LifeisDesign
 * @link http://lifeis.design/
 */

defined( 'ABSPATH' ) || exit;

if ( ! isset( $prefix ) ) {
	$prefix = '';
}
if ( empty( $options ) ) {
	return;
}

$id = sprintf( 'av5_%s_filter_%s_', $prefix, $key );
?>
<div class="av5-products-filter av5-products-filter-<?php echo esc_attr( $key ); ?>">
	<div class="av5-products-filter-title"><?php echo apply_filters( 'av5_products_filter_prepare_name', esc_html( $name ), $key, $options ); // WPCS: xss ok.     ?></div>
	<div class="av5-products-filter-area">
		<ul>
			<?php if ( $element_all ) : ?>
				<li><input type="checkbox" id="<?php echo esc_attr( $id . 'all' ) ?>" class="av5-products-filter-element" name="av5_filter_<?php echo esc_attr( $key ); ?>[]" value="" <?php checked( apply_filters( 'av5_products_filter_prepare_checked', '', $key, '' ), '' ); ?>><label for="<?php echo esc_attr( $id . 'all' ) ?>"><?php esc_html_e( 'All', '5th-avenue' ); ?></label></li>
			<?php endif; ?>
			<?php foreach ( $options as $term ) : ?>
				<li><input type="checkbox" id="<?php echo esc_attr( $id . $term->slug ) ?>" class="av5-products-filter-element" name="av5_filter_<?php echo esc_attr( $key ); ?>[]" value="<?php echo esc_attr( $term->slug ); ?>" <?php checked( apply_filters( 'av5_products_filter_prepare_checked', '', $key, $term->slug ), $term->slug ); ?>><label for="<?php echo esc_attr( $id . $term->slug ) ?>"><?php echo esc_html( $term->name ); ?></label></li>
				<?php endforeach; ?>
		</ul>
		<button type="submit"><?php esc_html_e( 'Apply', 'woocommerce' ) ?></button>
	</div>
</div>
