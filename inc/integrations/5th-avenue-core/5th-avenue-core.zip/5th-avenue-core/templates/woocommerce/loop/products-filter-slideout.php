<?php
/**
 * 5th-Avenue: WooCommerce products filter slideout
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author LifeisDesign
 * @copyright Copyright (c) 2018, LifeisDesign
 * @link http://lifeis.design/
 */

defined( 'ABSPATH' ) || exit;

?>
<div class="av5-products-filter-single">
	<a href="#av5-products-filter-slideout" class="av5-slide-out-left-button av5-products-filter-title"><span class="av5-filter-icon"><span></span><span></span></span><?php esc_html_e( 'Filters', '5th-avenue' ); ?></a>
</div>
<div id="av5-products-filter-slideout" class="av5-products-filter-slideout-wrap" style="display: none;">
	<?php
	$args['prefix'] = 'slideout';
	av5c_get_template( 'woocommerce/loop/products-filter-content.php', $args );
	?>
</div>
