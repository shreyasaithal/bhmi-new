<?php
/**
 * 5th-Avenue: WooCommerce products filter price
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author LifeisDesign
 * @copyright Copyright (c) 2018, LifeisDesign
 * @link http://lifeis.design/
 */

defined( 'ABSPATH' ) || exit;

if ( ! isset( $prefix ) ) {
	$prefix = '';
}
if ( empty( $options ) ) {
	return;
}
wp_enqueue_script( 'wc-price-slider' );
$min_price	 = isset( $_GET['min_price'] ) ? esc_attr( $_GET['min_price'] ) : apply_filters( 'woocommerce_price_filter_widget_min_amount', $options[0] ); // WPCS: input var ok. sanitization ok.
$max_price	 = isset( $_GET['max_price'] ) ? esc_attr( $_GET['max_price'] ) : apply_filters( 'woocommerce_price_filter_widget_max_amount', $options[1] ); // WPCS: input var ok. sanitization ok.
?>
<div class="av5-products-filter av5-products-filter-produc_price">
	<div class="av5-products-filter-title"><?php echo apply_filters( 'av5_products_filter_prepare_name', esc_html( $name ), 'produc_price', $options ); // WPCS: xss ok.     ?></div>
	<div class="av5-products-filter-area widget_price_filter">
		<div class="price_slider_wrapper">
			<div class="price_slider" style="display:none;"></div>
			<div class="price_slider_amount">
				<input type="text" id="min_price" name="min_price" value="<?php echo esc_attr( $min_price ); ?>" data-min="<?php echo esc_attr( apply_filters( 'woocommerce_price_filter_widget_min_amount', $options[0] ) ); ?>" placeholder="<?php esc_attr_e( 'Min price', 'woocommerce' ); ?>" />
				<input type="text" id="max_price" name="max_price" value="<?php echo esc_attr( $max_price ); ?>" data-max="<?php echo esc_attr( apply_filters( 'woocommerce_price_filter_widget_max_amount', $options[1] ) ); ?>" placeholder="<?php esc_attr_e( 'Max price', 'woocommerce' ); ?>" />

				<?php if ( isset( $_GET['min_price'] ) || isset( $_GET['max_price'] ) ) : ?>
					<a class="button" href="<?php echo esc_url( remove_query_arg( array( 'min_price', 'max_price' ) ) ); ?>"><?php esc_html_e( 'Clear', 'woocommerce' ) ?></a>
				<?php endif; ?>
				<button type="submit" class="button"><?php esc_html_e( 'Filter', 'woocommerce' ); ?></button>
				<div class="price_label" style="display:none;">
					<?php esc_html_e( 'Price:', 'woocommerce' ); ?> <span class="from"></span> &mdash; <span class="to"></span>
				</div>
				<?php echo wc_query_string_form_fields( null, array( 'min_price', 'max_price' ), '', true ); // WPCS: xss ok.  ?>
				<div class="clear"></div>
			</div>
		</div>
	</div>
</div>
