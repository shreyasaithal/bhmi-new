<?php
/**
 * 5th-Avenue: WooCommerce banner in products grid
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author LifeisDesign
 * @copyright Copyright (c) 2018, LifeisDesign
 * @link http://lifeis.design/
 */

defined( 'ABSPATH' ) || exit;

if ( ! isset( $classes ) ) {
	$classes = array();
}
?>
<li <?php post_class( implode( ' ', $classes ) ); ?>>
	<div class="grid-products-wrapper">
		<div class="dashed_border">
			<div class="grid-products-banner-wrapper">
				<div class="banner-content">
					<?php echo do_shortcode( $content ); ?>
				</div>
			</div>
		</div>
	</div>
</li>
