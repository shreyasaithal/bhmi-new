<?php
/**
 * Extended Visual Composer column element
 *
 * @package 5th-Avenue
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Shortcode attributes
 *
 * @var $atts
 * @var $el_id
 * @var $el_class
 * @var $width
 * @var $css
 * @var $offset
 * @var $content - shortcode content
 * @var $css_animation
 * Shortcode class
 * @var $this WPBakeryShortCode_VC_Column
 */
$theme_options_styles	 = $el_class				 = $el_id					 = $width					 = $parallax_speed_bg		 = $parallax_speed_video	 = $parallax				 = $parallax_image			 = $video_bg				 = $video_bg_url			 = $video_bg_parallax		 = $css					 = $offset					 = $css_animation			 = $bg_overlay				 = $bg_overlay_color		 = $bg_overlay_opacity		 = $overlay				 = $boxed_block			 = $boxed_bg_color			 = $boxed_size				 = $boxed_shadow			 = $max_width				 = $max_width_centered		 = $theme_options_styles	 = $align_content			 = $align_content_mobile	 = $align_content_tablet	 = '';
$max_width_align_class	 = $output					 = '';
$atts					 = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts ); // @codingStandardsIgnoreLine WordPress.Functions.DontExtract.extract
$custom_class			 = sprintf( 'av5_custom_%s_%s', time(), mt_rand( 0, time() ) );
if ( $bg_overlay ) {
	$overlay = '<div class="av5-column-overlay" style="background-color:' . $bg_overlay_color . '; opacity:' . absint( $bg_overlay_opacity ) / 100 . ';">&nbsp;</div>';
}
wp_enqueue_script( 'wpb_composer_front_js' );

$width	 = wpb_translateColumnWidthToSpan( $width );
$width	 = vc_column_offset_class_merge( $offset, $width );

$css_classes = array(
	$this->getExtraClass( $el_class ) . $this->getCSSAnimation( $css_animation ),
	'wpb_column',
	'vc_column_container',
	$width,
);

if ( vc_shortcode_custom_css_has_property( $css, array(
	'border',
	'background',
) ) || $video_bg || $parallax ) {
	$css_classes[] = 'vc_col-has-fill';
}

$css_classes[] = $custom_class;
if ( $block_overlap ) {
	$css_classes[] = 'av5-block--' . $block_overlap;
}
if ( $align_content ) {
	$css_classes[] = 'align-' . $align_content;
}
if ( $align_content_mobile ) {
	$css_classes[] = 'align-' . $align_content_mobile . '-mobile';
}
if ( $align_content_small ) {
	$css_classes[] = 'align-' . $align_content_small . '-mobile-small';
}
if ( $align_content_tablet ) {
	$css_classes[] = 'align-' . $align_content_tablet . '-tablet';
}
if ( $boxed_block ) {
	$css_classes[] = 'boxed-block';
	if ( $boxed_size ) {
		$css_classes[] = 'boxed-block-' . $boxed_size;
	}
	if ( $boxed_shadow ) {
		$css_classes[] = 'boxed-block--with-shadow';
	}
}
if ( $max_width ) {
	$theme_options_styles .= '.vc_column_container.' . $custom_class . ' .vc_column-inner { max-width: ' . $max_width . ';}';
	if ( $max_width_align ) {
		$max_width_align_class = 'max-width-' . $max_width_align;
	}
	if ( $max_width_align_tablet ) {
		$max_width_align_class .= ' max-width-tablet-' . $max_width_align_tablet;
	}
	if ( $max_width_align_mobile ) {
		$max_width_align_class .= ' max-width-mobile-' . $max_width_align_mobile;
	}
	if ( $max_width_align_small ) {
		$max_width_align_class .= ' max-width-small-' . $max_width_align_small;
	}
}
if ( $anim_delay ) {
	$theme_options_styles .= '.vc_column_container.' . $custom_class . ' { animation-delay: ' . $anim_delay . 'ms;}';
}
$wrapper_attributes = array();

$has_video_bg = ( ! empty( $video_bg ) && ! empty( $video_bg_url ) && vc_extract_youtube_id( $video_bg_url ) );

$parallax_speed = $parallax_speed_bg;
if ( $has_video_bg ) {
	$parallax		 = $video_bg_parallax;
	$parallax_speed	 = $parallax_speed_video;
	$parallax_image	 = $video_bg_url;
	$css_classes[]	 = 'vc_video-bg-container';
	wp_enqueue_script( 'vc_youtube_iframe_api_js' );
}

if ( ! empty( $parallax ) ) {
	wp_enqueue_script( 'vc_jquery_skrollr_js' );
	$wrapper_attributes[]	 = 'data-vc-parallax="' . esc_attr( $parallax_speed ) . '"'; // Parallax speed.
	$css_classes[]			 = 'vc_general vc_parallax vc_parallax-' . $parallax;
	if ( false !== strpos( $parallax, 'fade' ) ) {
		$css_classes[]			 = 'js-vc_parallax-o-fade';
		$wrapper_attributes[]	 = 'data-vc-parallax-o-fade="on"';
	} elseif ( false !== strpos( $parallax, 'fixed' ) ) {
		$css_classes[] = 'js-vc_parallax-o-fixed';
	}
}

if ( ! empty( $parallax_image ) ) {
	if ( $has_video_bg ) {
		$parallax_image_src = $parallax_image;
	} else {
		$parallax_image_id	 = preg_replace( '/[^\d]/', '', $parallax_image );
		$parallax_image_src	 = wp_get_attachment_image_src( $parallax_image_id, 'full' );
		if ( ! empty( $parallax_image_src[0] ) ) {
			$parallax_image_src = $parallax_image_src[0];
		}
	}
	$wrapper_attributes[] = 'data-vc-parallax-image="' . esc_attr( $parallax_image_src ) . '"';
}
if ( ! $parallax && $has_video_bg ) {
	$wrapper_attributes[] = 'data-vc-video-bg="' . esc_attr( $video_bg_url ) . '"';
}

$css_class				 = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( $css_classes ) ), $this->settings['base'], $atts ) );
$wrapper_attributes[]	 = 'class="' . esc_attr( trim( $css_class ) ) . '"';
if ( ! empty( $el_id ) ) {
	$wrapper_attributes[] = 'id="' . esc_attr( $el_id ) . '"';
}
if ( ! empty( $theme_options_styles ) ) {
	$theme_options_styles = '<style>' . $theme_options_styles . '</style>';
}
$output .= $theme_options_styles;
$output .= '<div ' . implode( ' ', $wrapper_attributes ) . '>';
$output .= $overlay;
$output .= '<div class="vc_column-inner ' . $max_width_align_class . ' ' . esc_attr( trim( vc_shortcode_custom_css_class( $css ) ) ) . '">';
$output .= '<div class="wpb_wrapper ">';
$output .= wpb_js_remove_wpautop( $content );
$output .= '</div>';
$output .= '</div>';
$output .= '</div>';

echo apply_filters( 'vc_shotcode_output_vc_column', $output ); // WPCS: xss ok.
