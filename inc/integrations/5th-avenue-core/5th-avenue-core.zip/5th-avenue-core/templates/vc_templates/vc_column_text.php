<?php
/**
 * Extended Visual Composer text element
 *
 * @package 5th-Avenue
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;


/**
 * Shortcode attributes
 *
 * @var $atts
 * @var $el_class
 * @var $el_id
 * @var $css_animation
 * @var $css
 * @var $content - shortcode content
 * Shortcode class
 * @var $this WPBakeryShortCode_VC_Column_text
 */
$theme_options_styles	 = $max_width_align_class	 = $output					 = $el_class				 = $el_id					 = $css					 = $css_animation			 = '';
$atts					 = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts ); // @codingStandardsIgnoreLine WordPress.Functions.DontExtract.extract
$custom_class			 = sprintf( 'av5_custom_%s_%s', time(), mt_rand( 0, time() ) );


$class_to_filter = 'wpb_text_column wpb_content_element ' . $this->getCSSAnimation( $css_animation );
$class_to_filter .= vc_shortcode_custom_css_class( $css, ' ' ) . $this->getExtraClass( $el_class );
$class_to_filter .= vc_shortcode_custom_css_class( $css, ' ' ) . $this->getExtraClass( $custom_class );

if ( $max_width ) {
	$theme_options_styles .= '.wpb_text_column.' . $custom_class . ' .wpb_wrapper { max-width: ' . $max_width . ';}';
	if ( $max_width_align ) {
		$max_width_align_class = 'max-width-' . $max_width_align;
	}
}
if ( $indent_position ) {
	if ( $indent ) {
		$theme_options_styles .= '.wpb_text_column.' . $custom_class . ' .wpb_wrapper { margin-' . $indent_position . ': ' . $indent . ';}';
	}
	if ( $indent_tablet ) {
		$theme_options_styles .= '@media screen and (max-width: 1024px) {';
		$theme_options_styles .= '.wpb_text_column.' . $custom_class . ' .wpb_wrapper { margin-' . $indent_position . ': ' . $indent_tablet . ';} }';
	}
	if ( $indent_mobile ) {
		$theme_options_styles .= '@media screen and (max-width: 768px) {';
		$theme_options_styles .= '.wpb_text_column.' . $custom_class . ' .wpb_wrapper { margin-' . $indent_position . ': ' . $indent_mobile . ';} }';
	}
	if ( $indent_mobile_small ) {
		$theme_options_styles .= '@media screen and (max-width: 480px) {';
		$theme_options_styles .= '.wpb_text_column.' . $custom_class . ' .wpb_wrapper { margin-' . $indent_position . ': ' . $indent_mobile_small . ';} }';
	}
}
if ( $anim_delay ) {
	$theme_options_styles .= '.wpb_text_column.' . $custom_class . ' { animation-delay: ' . $anim_delay . 'ms;}';
}
$css_class			 = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class_to_filter, $this->settings['base'], $atts );
$wrapper_attributes	 = array();

if ( ! empty( $el_id ) ) {
	$wrapper_attributes[] = 'id="' . esc_attr( $el_id ) . '"';
}

$output .= $theme_options_styles = ! empty( $theme_options_styles ) ? '<style>' . $theme_options_styles . '</style>' : '';
$output .= '
	<div class="' . esc_attr( $css_class ) . '" ' . implode( ' ', $wrapper_attributes ) . '>
		<div class="wpb_wrapper ' . $max_width_align_class . '">
			' . wpb_js_remove_wpautop( $content, true ) . '
		</div>
	</div>
';

echo apply_filters( 'vc_shotcode_output_vc_column_text', $output ); // WPCS: xss ok.
