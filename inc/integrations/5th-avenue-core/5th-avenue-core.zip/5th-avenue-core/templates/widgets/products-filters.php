<?php
/**
 * 5th-Avenue WooCommerce product filters widget
 *
 * @package 5th-Avenue
 * @version 1.0.0
 * @author lifeis.design
 */

defined( 'ABSPATH' ) || exit;

global $widget_instance;
?>
<div class="av5-products-filter-widget-wrap">
	<?php
	do_action( 'av5_products_before_filter_widget', $widget_instance );
	av5c_get_template( 'woocommerce/loop/products-filter-content.php', $widget_instance );
	do_action( 'av5_products_after_filter_widget', $widget_instance );
	?>
</div>
