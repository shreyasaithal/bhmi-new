<?php
/**
 * 5th-Avenue recent posts widget
 *
 * @package 5th-Avenue
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

global $widget_instance;
?>
<li>
	<?php
	if ( $widget_instance['post_thumb'] ) {
		?><a href="<?php echo esc_url( get_permalink( get_the_ID() ) ); ?>" title="<?php the_title(); ?>">
			<?php
			if ( has_post_thumbnail( get_the_ID() ) ) {
				echo '<div class="widget-img-wrap">';
				the_post_thumbnail( array( $widget_instance['post_thumb_width'], $widget_instance['post_thumb_height'] ) );
				echo '</div>';
			} else {
				echo '<div class="widget-img-wrap"><span class="placeholder"></span></div>';
			}
			?>
		</a><?php
	}
	?>
	<div class="content">
		<?php
		if ( $widget_instance['post_cat'] ) {
			$categories_list = get_the_category_list( '' );
			if ( $categories_list ) {
				?>
				<div class="widget-post-cats">
					<?php echo wp_kses_post( $categories_list ); ?>
				</div>
				<?php
			}
		}
		?>
		<a class="title" href="<?php the_permalink() ?>" title="<?php echo esc_attr( get_the_title() ); ?>">
			<?php the_title(); ?>
		</a>
		<?php
		if ( $widget_instance['post_date'] ) {
			$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
			if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
				$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
			}

			printf( $time_string, get_the_date( DATE_W3C ), get_the_date(), get_the_modified_date( DATE_W3C ), get_the_modified_date() ); // WPCS: xss ok.
		}
		?>
	</div>
</li>
